<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Incoming
 * @author     Meichun <qa.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Layout\LayoutHelper;
use \Joomla\CMS\Session\Session;
use \Joomla\CMS\User\UserFactoryInterface;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');

$user       = Factory::getApplication()->getIdentity();
$userId     = $user->get('id');
$listOrder  = $this->state->get('list.ordering');
$listDirn   = $this->state->get('list.direction');
$canCreate  = $user->authorise('core.create', 'com_incoming') && file_exists(JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'incomingorderform.xml');
$canEdit    = $user->authorise('core.edit', 'com_incoming') && file_exists(JPATH_COMPONENT .  DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'incomingorderform.xml');
$canCheckin = $user->authorise('core.manage', 'com_incoming');
$canChange  = $user->authorise('core.edit.state', 'com_incoming');
$canDelete  = $user->authorise('core.delete', 'com_incoming');

// Import CSS
// $wa = $this->document->getWebAssetManager();
// $wa->useStyle('com_incoming.list');

$wa = $this->document->getWebAssetManager();

$cssFile = JPATH_ROOT . '/media/com_incoming/css/list.css';
$wa->registerAndUseStyle(
	'com_incoming.list',
	Uri::root() . 'media/com_incoming/css/list.css',
	['version' => (string) @filemtime($cssFile)]
);
?>

<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
	</div>
<?php endif; ?>
<form action="<?php echo htmlspecialchars(Uri::getInstance()->toString()); ?>" method="post"
	name="adminForm" id="adminForm">

	<div class="header mb-4">
		<h1 class="header__title"><?php echo Text::_('COM_INCOMING_TITLE'); ?></h1>
		<p class="header__subtitle"><?php echo Text::_('COM_INCOMING_SUBTITLE'); ?></p>
	</div>

	<?php if (!empty($this->filterForm)) {
		echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this));
	} ?>

	<div class="button d-flex justify-content-end w-100 mb-3 " style="padding: 10px 28px; gap: 8px" ;>

		<!-- Update Part & Model Button -->
		<div class="update-button">
			<a href="#" class="btn btn-outline-success btn-small button-update-partmodel">
				<i class="icon-refresh"></i>
				<?php echo Text::_('COM_INCOMING_UPDATE_PART_MODEL'); ?>
			</a>
		</div>

		<!-- Export Button -->
		<div class="export-button">
			<a href="#" class="btn btn-outline-secondary btn-small button-export">
				<i class="icon-upload"></i>
				<?php echo Text::_('COM_INCOMING_EXPORT_ITEM'); ?>
			</a>
		</div>

		<!-- Import Button -->
		<div class="import-button">
			<a href="#"
				class="btn btn-outline-primary btn-small button-import-incoming"
				data-bs-toggle="tooltip"
				data-bs-html="true"
				data-bs-placement="bottom"
				title="<?php echo htmlspecialchars(Text::_('COM_INCOMING_IMPORT_HINT'), ENT_QUOTES, 'UTF-8'); ?>">
				<i class="icon-download"></i>
				<?php echo Text::_('COM_INCOMING_IMPORT_ITEM'); ?>
			</a>
		</div>

		<!-- Add Button -->
		<?php if ($canCreate) : ?>
			<a href="<?php echo Route::_('index.php?option=com_incoming&task=incomingorderform.edit&id=0', false, 0); ?>"
				class="btn btn-success btn-small"><i
					class="icon-plus"></i>
				<?php echo Text::_('COM_INCOMING_ADD_ITEM'); ?></a>
		<?php endif; ?>
	</div>

	<div class="table-responsive">
		<table class="table table-striped" id="incomingorderList">
			<thead>
				<tr>

					<!-- <th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_INCOMING_INCOMINGORDERS_ID', 'a.id', $listDirn, $listOrder); ?>
					</th> -->

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_INCOMING_INCOMINGORDERS_DOC_NO', 'a.doc_no', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_INCOMING_INCOMINGORDERS_DATE', 'a.date', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_INCOMING_INCOMINGORDERS_RAW_MODEL', 'a.raw_model', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_INCOMING_INCOMINGORDERS_PART', 'a.part', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_INCOMING_INCOMINGORDERS_MODEL', 'a.model', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_INCOMING_INCOMINGORDERS_QUANTITY', 'a.quantity', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_INCOMING_INCOMINGORDERS_REMARK', 'a.remark', $listDirn, $listOrder); ?>
					</th>

					<!-- <th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_INCOMING_INCOMINGORDERS_TERMS', 'a.terms', $listDirn, $listOrder); ?>
					</th> -->


					<!-- <?php if ($canEdit || $canDelete): ?>
						<th class="center">
							<?php echo Text::_('COM_INCOMING_INCOMINGORDERS_ACTIONS'); ?>
						</th>
					<?php endif; ?> -->

				</tr>
			</thead>
			<tfoot>
				<tr>
					<td colspan="<?php echo isset($this->items[0]) ? count(get_object_vars($this->items[0])) : 10; ?>">
						<div class="pagination">
							<?php echo $this->pagination->getPagesLinks(); ?>
						</div>
					</td>
				</tr>
			</tfoot>
			<tbody>
				<?php foreach ($this->items as $i => $item) : ?>
					<?php $canEdit = $user->authorise('core.edit', 'com_incoming'); ?>
					<?php if (!$canEdit && $user->authorise('core.edit.own', 'com_incoming')): ?>
						<?php $canEdit = Factory::getApplication()->getIdentity()->id == $item->created_by; ?>
					<?php endif; ?>

					<tr class="row<?php echo $i % 2; ?>">

						<!-- <td>
						<?php echo $item->id; ?>
					</td> -->

						<td>
							<?php $canCheckin = Factory::getApplication()->getIdentity()->authorise('core.manage', 'com_incoming.' . $item->id) || $item->checked_out == Factory::getApplication()->getIdentity()->id; ?>
							<?php if ($canCheckin && $item->checked_out > 0) : ?>
								<a href="<?php echo Route::_('index.php?option=com_incoming&task=incomingorder.checkin&id=' . $item->id . '&' . Session::getFormToken() . '=1'); ?>">
									<?php echo HTMLHelper::_('jgrid.checkedout', $i, $item->uEditor, $item->checked_out_time, 'incomingorder.', false); ?></a>
							<?php endif; ?>
							<a href="<?php echo Route::_('index.php?option=com_incoming&view=incomingorder&id=' . (int) $item->id); ?>">
								<?php echo $this->escape($item->doc_no); ?></a>
						</td>
						<td>
							<?php echo $item->date; ?>
						</td>
						<td>
							<?php echo $item->raw_model; ?>
						</td>
						<td>
							<!-- <?php echo $item->part; ?> -->
							<?php echo $item->part_name; ?>
						</td>
						<td>
							<!-- <?php echo $item->model; ?> -->
							<?php echo $item->model_name; ?>
						</td>
						<td>
							<?php echo $item->quantity; ?>
						</td>
						<td>
							<!-- <?php echo $item->remark; ?> -->
							<?php echo $item->remark_name; ?>
						</td>
						<!-- <td>
							<?php echo $item->terms; ?>
						</td> -->

						<!-- <?php if ($canEdit || $canDelete): ?>
							<td class="center">
								<?php $canCheckin = Factory::getApplication()->getIdentity()->authorise('core.manage', 'com_incoming.' . $item->id) || $item->checked_out == Factory::getApplication()->getIdentity()->id; ?>

								<?php if ($canEdit && $item->checked_out == 0): ?>
									<a href="<?php echo Route::_('index.php?option=com_incoming&task=incomingorder.edit&id=' . $item->id, false, 2); ?>" class="btn btn-mini" type="button"><i class="icon-edit"></i></a>
								<?php endif; ?>
								<?php if ($canDelete): ?>
									<a href="<?php echo Route::_('index.php?option=com_incoming&task=incomingorderform.remove&id=' . $item->id, false, 2); ?>" class="btn btn-mini delete-button" type="button"><i class="icon-trash"></i></a>
								<?php endif; ?>
							</td>
						<?php endif; ?> -->

					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<?php
	// Distinct (year, month) pairs that exist in the data, newest first
	$db    = Factory::getContainer()->get('DatabaseDriver');
	$query = $db->getQuery(true)
		->select('DISTINCT YEAR(' . $db->quoteName('date') . ') AS yr, MONTH(' . $db->quoteName('date') . ') AS mo')
		->from($db->quoteName('#__production_summary'))
		->where($db->quoteName('date') . ' IS NOT NULL')
		->order('yr DESC, mo DESC');

	$monthsByYear = array();

	foreach ($db->setQuery($query)->loadObjectList() ?: array() as $r) {
		$monthsByYear[(int) $r->yr][] = (int) $r->mo;
	}

	if (empty($monthsByYear)) {
		$monthsByYear[(int) Factory::getDate()->format('Y')] = array((int) Factory::getDate()->format('n'));
	}

	$existingYears = array_keys($monthsByYear);   // same order: newest first

	$monthNames = array(
		1 => 'January',
		2 => 'February',
		3 => 'March',
		4 => 'April',
		5 => 'May',
		6 => 'June',
		7 => 'July',
		8 => 'August',
		9 => 'September',
		10 => 'October',
		11 => 'November',
		12 => 'December',
	);

	$initYear     = (int) $existingYears[0];
	$initMonths   = $monthsByYear[$initYear] ?? array();
	$currentMonth = (int) Factory::getDate()->format('n');
	$defaultMonth = in_array($currentMonth, $initMonths, true) ? $currentMonth : (int) ($initMonths[0] ?? 0);
	?>

	<div id="ExportReportModal" class="modal" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header" style="position: static; display: flex; justify-content: center; align-items: center;">
					<h5 class="modal-title">Select Year &amp; Month</h5>
				</div>

				<div class="modal-body" style="display: flex; justify-content: center; align-items: center; flex-direction: column; padding: 20px; gap: 15px;">

					<div class="form-group" style="width: 100%; max-width: 300px; text-align: center;">
						<label for="ExportYear" style="margin-bottom: 8px; display: block;">Year:</label>
						<select id="ExportYear" name="year" class="form-control"
							style="width: 100%; padding: 8px; font-size: 16px; text-align: center; border: 1px solid #ccc; border-radius: 4px;">
							<?php foreach ($existingYears as $y) : ?>
								<option value="<?php echo (int) $y; ?>"><?php echo (int) $y; ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="form-group" style="width: 100%; max-width: 300px; text-align: center;">
						<label for="ExportMonth" style="margin-bottom: 8px; display: block;">Month:</label>
						<select id="ExportMonth" name="month" class="form-control"
							style="width: 100%; padding: 8px; font-size: 16px; text-align: center; border: 1px solid #ccc; border-radius: 4px; margin-bottom: 10px;">
							<option value="">All Months</option>
							<?php foreach ($initMonths as $m) : ?>
								<option value="<?php echo $m; ?>" <?php echo $m === $defaultMonth ? 'selected' : ''; ?>>
									<?php echo $monthNames[$m]; ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>

				</div>

				<div class="modal-footer">
					<button type="button" class="btn btn-primary" onclick="exportReport()">Export</button>
					<button type="button" class="btn btn-secondary" onclick="closeExportReportModal()">Close</button>
				</div>
			</div>
		</div>
	</div>

	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="filter_order" value="" />
	<input type="hidden" name="filter_order_Dir" value="" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>

<?php
if ($canDelete) {
	$wa->addInlineScript("
			jQuery(document).ready(function () {
				jQuery('.delete-button').click(deleteItem);
			});

			function deleteItem() {

				if (!confirm(\"" . Text::_('COM_INCOMING_DELETE_MESSAGE') . "\")) {
					return false;
				}
			}
		", [], [], ["jquery"]);
}
?>

<script>
	jQuery(".button-import-incoming").click(function(event) {
		event.preventDefault();

		console.log('import test');
		importOrder();

	});

	function importOrder() {

		var newInput = jQuery('<input type="file" name="csvFile" id="csvFile" style="display:none" />');
		jQuery(".button-import-incoming").after(newInput);

		// Add an additional input for 'Incoming'
		var incomingInput = jQuery('<input type="hidden" name="type" value="Incoming" />');
		jQuery(".button-import-incoming").after(incomingInput);

		jQuery("#csvFile").change(function() {
			var file = jQuery("#csvFile").prop("files")[0];
			var maxFileSizeMB = 5; // Set your file size limit here
			var maxFileSizeBytes = maxFileSizeMB * 1024 * 1024;

			console.log(file);
			console.log(newInput);

			if (file) {
				var formData = new FormData();
				formData.append('csvFile', file);
				formData.append('type', 'Incoming');

				// Add loader animation before reload
				jQuery(".button-import-incoming")
					.attr("style", "display:-webkit-box;")
					.append(
						"<style>" +
						".loader {" +
						"border: 5px solid #f3f3f3;" + // Light grey
						"border-top: 5px solid #3498db;" + // Blue
						"border-radius: 50%;" +
						"width: 20px;" +
						"height: 20px;" +
						"animation: spin 2s linear infinite;" +
						"margin-left: 3px;" +
						"}" +
						"@keyframes spin {" +
						"0% { transform: rotate(0deg); }" +
						"100% { transform: rotate(360deg); }" +
						"}" +
						"</style>" +
						'<div class="loader"></div>'
					);

				jQuery.ajax({
						url: '/index.php?option=com_ajax&group=ajax&plugin=importorders&format=raw',
						type: 'POST',
						data: formData,
						processData: false,
						contentType: false,
						success: function(data) {
							console.log("data = " + data);
						},
						error: function(xhr, status, error) {
							console.error('Error:', error, xhr.responseText);
							jQuery("#message-container").html('<p>Error: ' + xhr.responseText + '</p>');
						}
					})
					.done(function(result, textStatus, jqXHR) {
						console.log("result = " + result);
						console.log("textStatus = " + textStatus);
						console.log(jqXHR);

						// Optional: Allow the loader to display briefly before reload
						setTimeout(function() {
							window.location.reload();
							// alert("Data Import Successfully");
						}, 500); // Short delay for user experience

					});
			}
		});

		jQuery("#csvFile").click();
	}

	jQuery(".button-update-partmodel").click(function(event) {
		event.preventDefault();

		var $btn = jQuery(this);

		if ($btn.hasClass('disabled') || !confirm('<?php echo Text::_('COM_INCOMING_UPDATE_PART_MODEL_CONFIRM', true); ?>')) {
			return;
		}

		$btn.addClass('disabled').find('i').addClass('icon-spin');

		jQuery.ajax({
			url: '<?php echo Uri::root(true); ?>/index.php?option=com_ajax&group=ajax&plugin=Updatepartmodel&format=json',
			type: 'POST',
			dataType: 'json',
			data: {
				type: 'Incoming',
				'<?php echo Session::getFormToken(); ?>': 1
			}
		}).done(function(result) {
			// com_ajax wraps the plugin's return value: { success, message, data: [ ... ] }
			var info = result && result.data && result.data[0] ? result.data[0] : {};

			alert(info.message || result.message || 'Done');
			window.location.reload();
		}).fail(function(xhr) {
			alert('Error: ' + xhr.responseText);
			$btn.removeClass('disabled').find('i').removeClass('icon-spin');
		});
	});

	document.addEventListener('DOMContentLoaded', function() {
		var modal = document.getElementById('ExportReportModal');
		var yearSel = document.getElementById('ExportYear');
		var monthSel = document.getElementById('ExportMonth');

		if (!modal || !yearSel || !monthSel) {
			console.warn('Export modal elements not found');
			return;
		}

		// Escape any parent that clips or transforms fixed elements
		document.body.appendChild(modal);

		var monthsByYear = <?php echo json_encode($monthsByYear, JSON_HEX_TAG | JSON_HEX_AMP); ?>;
		var names = <?php echo json_encode(array_values($monthNames), JSON_HEX_TAG | JSON_HEX_AMP); ?>;

		yearSel.addEventListener('change', function() {
			var months = monthsByYear[yearSel.value] || [];
			var keep = monthSel.value;

			monthSel.innerHTML = '';
			monthSel.add(new Option('All Months', ''));
			months.forEach(function(m) {
				monthSel.add(new Option(names[m - 1], m));
			});
			monthSel.value = months.indexOf(parseInt(keep, 10)) !== -1 ? keep : '';
		});

		// Delegated + capture: works even if the button is rendered late or Joomla handles the click itself
		document.addEventListener('click', function(event) {
			if (event.target.closest('.button-export')) {
				event.preventDefault();
				event.stopPropagation();
				window.openExportReportModal();
			}
		}, true);

		modal.addEventListener('click', function(event) {
			if (event.target === modal) {
				window.closeExportReportModal();
			}
		});

		document.addEventListener('keydown', function(event) {
			if (event.key === 'Escape') {
				window.closeExportReportModal();
			}
		});
	});

	window.openExportReportModal = function() {
		document.getElementById('ExportReportModal').classList.add('is-open');
	};

	window.closeExportReportModal = function() {
		document.getElementById('ExportReportModal').classList.remove('is-open');
	};

	window.exportReport = function() {
		var month = document.getElementById('ExportMonth').value;
		var year = document.getElementById('ExportYear').value;
		var type = 'Incoming';

		window.closeExportReportModal();
		window.location.href = 'index.php?option=com_ajax&plugin=export&group=ajax&format=raw' +
			'&month=' + encodeURIComponent(month) +
			'&year=' + encodeURIComponent(year) +
			'&type=' + encodeURIComponent(type);
	};
</script>