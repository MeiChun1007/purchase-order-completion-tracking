DROP TABLE IF EXISTS `#__incoming_orders`;

DROP TABLE IF EXISTS `#__incoming_remarks`;

DELETE FROM `#__action_log_config` WHERE (type_alias LIKE 'com_incoming.%');
DELETE FROM `#__action_logs_extensions` WHERE (extension = 'com_incoming');