CREATE TABLE IF NOT EXISTS `#__incoming_remarks` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`remark` VARCHAR(255)  NULL  DEFAULT "",
`note` TEXT NULL ,
PRIMARY KEY (`id`)
,KEY `idx_state` (`state`)
,KEY `idx_checked_out` (`checked_out`)
,KEY `idx_created_by` (`created_by`)
,KEY `idx_modified_by` (`modified_by`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

INSERT INTO `#__action_log_config` (`type_title`, `type_alias`, `id_holder`, `title_holder`, `table_name`, `text_prefix`)
SELECT * FROM ( SELECT 'incomingremark' AS type_title,'com_incoming.incomingremark' AS type_alias,'id' AS id_holder,'remark' AS title_holder,'#__incoming_remarks' AS table_name,'PLG_ACTIONLOG_INCOMING' AS text_prefix ) AS tmp
WHERE NOT EXISTS (
	SELECT type_alias FROM `#__action_log_config` WHERE (`type_alias` = 'com_incoming.incomingremark')
) LIMIT 1;
