CREATE TABLE IF NOT EXISTS `#__incoming_orders` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`doc_no` VARCHAR(255)  NULL  DEFAULT "",
`date` DATE NULL  DEFAULT NULL,
`raw_model` VARCHAR(255)  NULL  DEFAULT "",
`model` VARCHAR(255)  NULL  DEFAULT "",
`remark` VARCHAR(255)  NULL  DEFAULT "",
`quantity` INT NULL  DEFAULT 0,
`custom_field_1` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_2` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_3` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_4` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_5` VARCHAR(255)  NULL  DEFAULT "",
`terms` VARCHAR(255)  NULL  DEFAULT "",
`description` TEXT NULL ,
PRIMARY KEY (`id`)
,KEY `idx_state` (`state`)
,KEY `idx_checked_out` (`checked_out`)
,KEY `idx_created_by` (`created_by`)
,KEY `idx_modified_by` (`modified_by`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `#__incoming_orders_date` ON `#__incoming_orders`(`date`);

CREATE INDEX `#__incoming_orders_quantity` ON `#__incoming_orders`(`quantity`);


CREATE TABLE IF NOT EXISTS `#__incoming_remarks` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`remark` VARCHAR(255)  NULL  DEFAULT "",
`note` TEXT NULL ,
PRIMARY KEY (`id`)
,KEY `idx_state` (`state`)
,KEY `idx_checked_out` (`checked_out`)
,KEY `idx_created_by` (`created_by`)
,KEY `idx_modified_by` (`modified_by`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;


INSERT INTO `#__action_log_config` (`type_title`, `type_alias`, `id_holder`, `title_holder`, `table_name`, `text_prefix`)
SELECT * FROM ( SELECT 'incomingorder' AS type_title,'com_incoming.incomingorder' AS type_alias,'id' AS id_holder,'doc_no' AS title_holder,'#__incoming_orders' AS table_name,'PLG_ACTIONLOG_INCOMING' AS text_prefix ) AS tmp
WHERE NOT EXISTS (
	SELECT type_alias FROM `#__action_log_config` WHERE (`type_alias` = 'com_incoming.incomingorder')
) LIMIT 1;

INSERT INTO `#__action_log_config` (`type_title`, `type_alias`, `id_holder`, `title_holder`, `table_name`, `text_prefix`)
SELECT * FROM ( SELECT 'incomingremark' AS type_title,'com_incoming.incomingremark' AS type_alias,'id' AS id_holder,'remark' AS title_holder,'#__incoming_remarks' AS table_name,'PLG_ACTIONLOG_INCOMING' AS text_prefix ) AS tmp
WHERE NOT EXISTS (
	SELECT type_alias FROM `#__action_log_config` WHERE (`type_alias` = 'com_incoming.incomingremark')
) LIMIT 1;

INSERT INTO `#__action_logs_extensions` (`extension`)
SELECT * FROM ( SELECT 'com_incoming' ) AS tmp
WHERE NOT EXISTS (
	SELECT extension FROM `#__action_logs_extensions` WHERE (`extension` = 'com_incoming')
) LIMIT 1;
