1. Install plg_ajax_importorders
2. move PhpSpreadsheet and Psr folder into site/plugins/ajax/importorders