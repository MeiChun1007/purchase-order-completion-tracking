<?php

/**
 * PSR-16 (Simple Cache) interface, version 1.0 - copied so the bundled PhpSpreadsheet
 * (which loads files with require_once and has no Composer autoloader) can find it.
 * Source: https://github.com/php-fig/simple-cache  (MIT License)
 *
 * Deliberately untyped: the bundled PhpSpreadsheet Memory class implements these
 * methods without parameter/return types.
 */

namespace Psr\SimpleCache;

interface CacheInterface
{
	public function get($key, $default = null);

	public function set($key, $value, $ttl = null);

	public function delete($key);

	public function clear();

	public function getMultiple($keys, $default = null);

	public function setMultiple($values, $ttl = null);

	public function deleteMultiple($keys);

	public function has($key);
}
