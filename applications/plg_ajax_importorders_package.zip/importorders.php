<?php

/**
 * @copyright	Copyright (c) 2026 importorders. All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// no direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;

jimport('joomla.plugin.plugin');

/**
 * Ajax - Import Orders Plugin
 *
 * @package		Joomla.Plugin
 * @subpakage	importorders.ImportOrders
 */
class plgAjaxImportOrders extends JPlugin
{

	/**
	 * Constructor.
	 *
	 * @param 	$subject
	 * @param	array $config
	 */
	function __construct(&$subject, $config = array())
	{
		// call parent constructor
		parent::__construct($subject, $config);
	}

	function onAjaxImportorders($data = [])
	{
		$importFile = $_FILES["csvFile"];

		// PSR-16 interface needed by PhpSpreadsheet's Settings / Collection classes
		require_once(__DIR__ . '/Psr/SimpleCache/CacheInterface.php');

		// Autoloader: loads any PhpSpreadsheet class from ./PhpSpreadsheet the moment it is
		// first used (replaces the old hand-written list of ~60 require_once lines, which
		// was missing files such as Calculation/Token/Stack.php).
		static $autoloaderRegistered = false;

		if (!$autoloaderRegistered) {
			spl_autoload_register(function ($class) {
				$prefix = 'PhpOffice\\PhpSpreadsheet\\';

				if (strpos($class, $prefix) !== 0) {
					return;
				}

				$file = __DIR__ . '/PhpSpreadsheet/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';

				if (is_file($file)) {
					require_once $file;
				}
			});

			$autoloaderRegistered = true;
		}


		$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
		$reader->setReadDataOnly(TRUE);
		$spreadsheet = $reader->load($importFile['tmp_name']);
		$worksheet = $spreadsheet->getActiveSheet();
		$worksheet_arr = $this->sheetToArray($worksheet);

		// Get the input object
		$input = Factory::getApplication()->input;

		// Get the 'type' parameter
		$type = $input->get('type', '', 'string');

		if (empty($type)) {
			$type = isset($data['type']) ? $data['type'] : '';
		}

		// Get the current user ID
		$user = Factory::getUser();
		$userId = $user->id;

		$response = [];

		if ($type == 'Incoming') {
			$response['messages'] = $this->import_incoming($worksheet_arr, $userId);
		} else if ($type == 'Outgoing') {
			$response['messages'] = $this->import_outgoing($worksheet_arr, $userId);
		}

		$app = Factory::getApplication();
		$app->enqueueMessage($response['messages'], 'success');

		$session = Factory::getSession();
		$session->set('application.queue', $app->getMessageQueue());
	}

	/**
	 * ===========================================================================
	 * Import Incoming - to extract data from excel and check if the data exists
	 * ===========================================================================
	 */
	function import_incoming($worksheet_arr, $userId)
	{
		$requiredFields = ["Doc No.", "Date", "Model", "Quantity", "Remark"];

		// Header row -> canonical names
		$headerMap = $this->mapHeaders($worksheet_arr[0] ?? []);

		// Check required columns exist (once, before importing anything)
		$missing = array_diff($requiredFields, $headerMap);
		if (!empty($missing)) {
			return "Error: Missing required column(s): " . implode(', ', $missing);
		}

		foreach ($worksheet_arr as $i => $line) {
			if ($i == 0) continue;
			$docNo = '';
			foreach ($headerMap as $index => $name) {
				if ($name === 'Doc No.') {
					$docNo = trim((string) ($line[$index] ?? ''));
				}
			}
			if (stripos($docNo, 'YT') === 0) {
				return "Error: Row " . ($i + 1) . " Doc No. '$docNo' starts with YT, this is an Outgoing order. Please upload it under Outgoing.";
			}
		}

		$db = Factory::getDbo();
		$imported = 0;
		$skipped  = 0;
		$existing = [];   // <-- new
		$errors   = [];

		foreach ($worksheet_arr as $line_number => $line) {
			if ($line_number == 0) {
				continue;
			}

			// Skip empty rows
			if (empty(array_filter($line, function ($v) {
				return trim((string) $v) !== '';
			}))) {
				continue;
			}

			// Build the row with canonical keys
			$value = [];
			foreach ($headerMap as $index => $name) {
				$value[$name] = isset($line[$index]) ? trim((string) $line[$index]) : '';
			}

			$excelRow = $line_number + 1; // 1-based, matches Excel

			// 1. Check required values
			$rowOk = true;
			foreach ($requiredFields as $field) {
				if ($value[$field] === '') {
					$errors[] = "Row $excelRow: '$field' is empty.";
					$rowOk = false;
					break;
				}
			}
			if (!$rowOk) {
				continue;
			}

			// 2. Check Doc No. prefix  <-- HERE
			if ($err = $this->checkDocNoPrefix($value["Doc No."], 'Incoming')) {
				$errors[] = "Row $excelRow: Doc No. '{$value["Doc No."]}' $err.";
				continue;
			}

			// 3. Check existing orders
			$query = $db->getQuery(true)
				->select($db->quoteName('doc_no'))
				->from($db->quoteName('#__incoming_orders'))
				->where($db->quoteName('doc_no') . ' = ' . $db->quote($value["Doc No."]))
				->where($db->quoteName('state') . ' = 1');
			$db->setQuery($query);

			if ($db->loadResult()) {
				$skipped++;
				$existing[] = $value["Doc No."];   // <-- new
				continue;
			}

			$this->import_incoming_order_records($value, $userId);
			$imported++;
		}

		$message = "$imported imported, $skipped already existed.";
		if ($existing) {
			$unique = array_unique($existing);
			$shown  = array_slice($unique, 0, 50);
			$more   = count($unique) - count($shown);

			$message .= " Existing Doc No.: " . implode(', ', $shown)
				. ($more > 0 ? " and $more more" : "") . ".";
		}

		if ($errors) {
			$message .= " Errors: " . implode(' ', $errors);
		}

		return $message;
	}

	/**
	 * ===========================================================================
	 * Import Incoming Order Records - to insert incoming order records
	 * ===========================================================================
	 */
	function import_incoming_order_records($value, $userId)
	{
		//Date
		$date = $value["Date"];

		if (is_numeric($date)) {
			$dt = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($date);
		} else {
			$dt = DateTime::createFromFormat('j/n/Y', trim($date)); // in case the cell is text
		}

		$formattedDate = $dt ? $dt->format('Y-m-d') : null;

		//Remark
		$remark = $value["Remark"];
		$remarkId = $this->incoming_remark_mapping($remark);
		if (empty($remarkId)) {
			$remarkId = $this->insert_new_incoming_remark($remark);
		}

		//Model
		$raw_model = $value["Model"];
		$matched_model = $this->models_mapping($raw_model);

		$model = '';
		$part = '';

		if ($matched_model) {
			$model = $matched_model->id;
			$part = $matched_model->component;
		}

		//Insert Incoming Orders
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$columns = array(
			'created_by',
			'doc_no',
			'date',
			'raw_model',
			'part',
			'model',
			'quantity',
			'remark'
		);
		$values = array(
			$db->quote($userId),
			$db->quote($value["Doc No."]),
			$db->quote($formattedDate),
			$db->quote($value["Model"]),
			$db->quote($part),
			$db->quote($model),
			$db->quote($value["Quantity"]),
			$db->quote($remarkId)
		);
		// Optional fields: only insert when the column exists in Excel and has a value
		if (!empty($value["Terms"])) {
			$columns[] = 'terms';
			$values[]  = $db->quote($value["Terms"]);
		}
		if (!empty($value["Description"])) {
			$columns[] = 'description';
			$values[]  = $db->quote($value["Description"]);
		}
		$query
			->insert($db->quoteName('#__incoming_orders'))
			->columns($db->quoteName($columns))
			->values(implode(',', $values));
		$db->setQuery($query);

		$db->execute();

		return $db->insertid();
	}

	/**
	 * ===========================================================================
	 * Incoming Remark Mapping - to get the id of remark from #__incoming_remarks
	 * ===========================================================================
	 */
	function incoming_remark_mapping($remark)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query
			->select($db->quoteName('id'))
			->from($db->quoteName('#__incoming_remarks'))
			->where($db->quoteName('remark') . '=' . $db->quote($remark))
			->where($db->quoteName('state') . '=' . $db->quote(1));
		$db->setQuery($query);

		return $db->loadResult();
	}

	/**
	 * ===========================================================================
	 * Insert Incoming Remark - to create a new remark in #__incoming_remarks
	 * ===========================================================================
	 */
	function insert_new_incoming_remark($remark)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$columns = array(
			'remark'
		);
		$values = array(
			$db->quote($remark)
		);
		$query
			->insert($db->quoteName('#__incoming_remarks'))
			->columns($db->quoteName($columns))
			->values(implode(',', $values));
		$db->setQuery($query);
		$db->execute();

		return $db->insertid();
	}

	/**
	 * ===========================================================================
	 * Import Outgoing - to extract data from excel and check if the data exists
	 * ===========================================================================
	 */
	function import_outgoing($worksheet_arr, $userId)
	{
		$requiredFields = ["Doc No.", "Date", "Model", "Quantity", "Remark"];

		// Header row -> canonical names
		$headerMap = $this->mapHeaders($worksheet_arr[0] ?? []);

		$missing = array_diff($requiredFields, $headerMap);
		if (!empty($missing)) {
			return "Error: Missing required column(s): " . implode(', ', $missing);
		}

		$db = Factory::getDbo();
		$imported = 0;
		$skipped  = 0;
		$existing = [];
		$errors   = [];

		// 1. Collect the Doc Nos in this file
		$docNosInFile = [];
		foreach ($worksheet_arr as $i => $line) {
			if ($i == 0) {
				continue;
			}
			foreach ($headerMap as $index => $name) {
				if ($name === 'Doc No.') {
					$d = trim((string) ($line[$index] ?? ''));
					if ($d !== '') {
						$docNosInFile[$d] = true;
					}
				}
			}
		}

		// 2. Count the lines already in the database for those Doc Nos
		//    key = DOCNO|MODEL|QTY  =>  how many such lines exist
		$dbCounts = [];
		if ($docNosInFile) {
			$quoted = array_map([$db, 'quote'], array_keys($docNosInFile));
			$query = $db->getQuery(true)
				->select([
					$db->quoteName('doc_no'),
					$db->quoteName('raw_model'),
					$db->quoteName('quantity'),
					'COUNT(*) AS cnt',
				])
				->from($db->quoteName('#__outgoing_orders'))
				->where($db->quoteName('doc_no') . ' IN (' . implode(',', $quoted) . ')')
				->where($db->quoteName('state') . ' = 1')
				->group([
					$db->quoteName('doc_no'),
					$db->quoteName('raw_model'),
					$db->quoteName('quantity'),
				]);
			$db->setQuery($query);

			foreach ($db->loadObjectList() as $r) {
				$dbCounts[$this->lineKey($r->doc_no, $r->raw_model, $r->quantity)] = (int) $r->cnt;
			}
		}

		$seenInFile = [];

		try {
			$db->transactionStart();

			foreach ($worksheet_arr as $line_number => $line) {
				if ($line_number == 0) {
					continue;
				}

				// Skip empty rows
				if (empty(array_filter($line, function ($v) {
					return trim((string) $v) !== '';
				}))) {
					continue;
				}

				// Build the row with canonical keys
				$value = [];
				foreach ($headerMap as $index => $name) {
					$value[$name] = isset($line[$index]) ? trim((string) $line[$index]) : '';
				}

				$excelRow = $line_number + 1;

				// 3. Required values
				$rowOk = true;
				foreach ($requiredFields as $field) {
					if ($value[$field] === '') {
						$errors[] = "Row $excelRow: '$field' is empty.";
						$rowOk = false;
						break;
					}
				}
				if (!$rowOk) {
					continue;
				}

				// 4. Doc No. prefix
				if ($err = $this->checkDocNoPrefix($value["Doc No."], 'Outgoing')) {
					$errors[] = "Row $excelRow: Doc No. '{$value["Doc No."]}' $err.";
					continue;
				}

				// 5. Line-level duplicate check
				$key = $this->lineKey($value["Doc No."], $value["Model"], $value["Quantity"]);
				$seenInFile[$key] = ($seenInFile[$key] ?? 0) + 1;

				if ($seenInFile[$key] <= ($dbCounts[$key] ?? 0)) {
					$skipped++;
					$existing[] = $value["Doc No."];
					continue;
				}

				// 6. Insert
				$this->import_outgoing_order_records($value, $userId);
				$imported++;
			}

			$db->transactionCommit();
		} catch (\Exception $e) {
			Factory::getApplication()->enqueueMessage('Import failed: ' . $e->getMessage(), 'error');
			Factory::getSession()->set('application.queue', Factory::getApplication()->getMessageQueue());
			return;
		}

		$message = "$imported lines imported, $skipped lines already existed.";

		if ($existing) {
			$unique = array_unique($existing);
			$shown  = array_slice($unique, 0, 50);
			$more   = count($unique) - count($shown);

			$message .= " Skipped Doc No.: " . implode(', ', $shown)
				. ($more > 0 ? " and $more more" : "") . ".";
		}
		if ($errors) {
			$message .= " Errors: " . implode(' ', $errors);
		}

		return $message;
	}
	/**
	 * ===========================================================================
	 * Import Outgoing Order Records - to insert outgoing order records
	 * ===========================================================================
	 */
	function import_outgoing_order_records($value, $userId)
	{
		//Date
		$date = $value["Date"];

		if (is_numeric($date)) {
			$dt = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($date);
		} else {
			$dt = DateTime::createFromFormat('j/n/Y', trim($date)); // in case the cell is text
		}

		$formattedDate = $dt ? $dt->format('Y-m-d') : null;

		//Remark
		$remark = $value["Remark"];
		$remarkId = $this->outgoing_remark_mapping($remark);
		if (empty($remarkId)) {
			$remarkId = $this->insert_new_outgoing_remark($remark);
		}

		//Model
		$raw_model = $value["Model"];
		$matched_model = $this->models_mapping($raw_model);

		$model = '';
		$part = '';

		if ($matched_model) {
			$model = $matched_model->id;
			$part = $matched_model->component;
		}

		//Insert Outgoing Orders
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$columns = array(
			'created_by',
			'doc_no',
			'date',
			'raw_model',
			'part',
			'model',
			'quantity',
			'remark',
			'terms'
		);
		$values = array(
			$db->quote($userId),
			$db->quote($value["Doc No."]),
			$db->quote($formattedDate),
			$db->quote($value["Model"]),
			$db->quote($part),
			$db->quote($model),
			$db->quote($value["Quantity"]),
			$db->quote($remarkId),
			$db->quote($value["Terms"])
		);
		// Optional fields: only insert when the column exists in Excel and has a value
		if (!empty($value["Description"])) {
			$columns[] = 'description';
			$values[]  = $db->quote($value["Description"]);
		}
		$query
			->insert($db->quoteName('#__outgoing_orders'))
			->columns($db->quoteName($columns))
			->values(implode(',', $values));
		$db->setQuery($query);
		$db->execute();

		return $db->insertid();
	}

	/**
	 * ===========================================================================
	 * Outgoing Remark Mapping - to get the id of remark from #__outgoing_remarks
	 * ===========================================================================
	 */
	function outgoing_remark_mapping($remark)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query
			->select($db->quoteName('id'))
			->from($db->quoteName('#__outgoing_remarks'))
			->where($db->quoteName('remark') . '=' . $db->quote($remark))
			->where($db->quoteName('state') . '=' . $db->quote(1));
		$db->setQuery($query);

		return $db->loadResult();
	}

	/**
	 * ===========================================================================
	 * Insert Outgoing Remark - to create a new remark in #__outgoing_remarks
	 * ===========================================================================
	 */
	function insert_new_outgoing_remark($remark)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$columns = array(
			'remark'
		);
		$values = array(
			$db->quote($remark)
		);
		$query
			->insert($db->quoteName('#__outgoing_remarks'))
			->columns($db->quoteName($columns))
			->values(implode(',', $values));
		$db->setQuery($query);
		$db->execute();

		return $db->insertid();
	}

	/**
	 * ===========================================================================
	 * Models & Part Mapping - to get the id of part & model from #__product_catalogs 
	 * ===========================================================================
	 */
	function models_mapping($raw_model)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query
			->select($db->quoteName(['id', 'component']))
			->from($db->quoteName('#__product_catalogs'))
			->where($db->quoteName('custom_field_1') . '=' . $db->quote($raw_model))
			->where($db->quoteName('state') . '=' . $db->quote(1));
		$db->setQuery($query);
		$result =  $db->loadObject();

		if (empty($result)) {
			$query = $db->getQuery(true);
			$query
				->select($db->quoteName(['id', 'component']))
				->from($db->quoteName('#__product_catalogs'))
				->where($db->quoteName('custom_field_2') . '=' . $db->quote($raw_model))
				->where($db->quoteName('state') . '=' . $db->quote(1));
			$db->setQuery($query);
			$result =  $db->loadObject();
		}

		return $result; // object with ->id and ->component, or null if no match
	}

	/**
	 * Accepted header names for each field. Write them in normalised form:
	 * lowercase, letters and digits only ("Doc No." -> "docno").
	 */
	private function getHeaderAliases()
	{
		return [
			'Doc No.'     => ['docno', 'docnumber', 'documentno', 'documentnumber', 'doc'],
			'Date'        => ['date', 'dates', 'orderdate', 'docdate'],
			'Model'       => ['model', 'models', 'modelname', 'partno'],
			'Quantity'    => ['quantity', 'quantities', 'qty', 'qtys'],
			'Remark'      => ['remark', 'remarks', 'rmk', 'rmks'],
			'Terms'       => ['terms', 'term'],
			'Description' => ['description', 'descriptions', 'desc'],
		];
	}

	private function normalizeHeader($text)
	{
		return preg_replace('/[^a-z0-9]/', '', strtolower(trim((string) $text)));
	}

	private function lineKey($docNo, $model, $qty)
	{
		return strtoupper(trim((string) $docNo)) . '|'
			. strtoupper(trim((string) $model)) . '|'
			. (float) $qty;
	}

	/**
	 * Turn the Excel header row into [columnIndex => canonicalName].
	 * Unknown columns are ignored.
	 */
	private function mapHeaders(array $headerRow)
	{
		$lookup = [];
		foreach ($this->getHeaderAliases() as $canonical => $aliases) {
			foreach ($aliases as $alias) {
				$lookup[$alias] = $canonical;
			}
		}

		$map = [];
		foreach ($headerRow as $index => $header) {
			$key = $this->normalizeHeader($header);
			if ($key !== '' && isset($lookup[$key]) && !in_array($lookup[$key], $map, true)) {
				$map[$index] = $lookup[$key];
			}
		}

		return $map;
	}

	/**
	 * Like Worksheet::toArray(), but never recalculates formulas:
	 * for a formula cell it returns the value Excel saved in the file.
	 */
	private function sheetToArray($worksheet)
	{
		$rows = [];

		foreach ($worksheet->getRowIterator() as $row) {
			$cells = $row->getCellIterator();
			$cells->setIterateOnlyExistingCells(false);

			$line = [];

			foreach ($cells as $cell) {
				$line[] = $cell->isFormula() ? $cell->getOldCalculatedValue() : $cell->getValue();
			}

			$rows[] = $line;
		}

		return $rows;
	}

	private function checkDocNoPrefix($docNo, $type)
	{
		$isOutgoing = (bool) preg_match('/^YT/i', $docNo);
		$isIncoming = (bool) preg_match('/^(WO|PR)/i', $docNo);

		if ($type === 'Incoming' && $isOutgoing) {
			return "starts with YT, this is an Outgoing order";
		}
		if ($type === 'Outgoing' && $isIncoming) {
			return "starts with WO/PR, this is an Incoming order";
		}

		return null;
	}
}
