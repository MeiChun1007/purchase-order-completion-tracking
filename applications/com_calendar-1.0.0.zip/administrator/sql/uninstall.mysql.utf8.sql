DROP TABLE IF EXISTS `#__calendar_holidays`;

DELETE FROM `#__action_log_config` WHERE (type_alias LIKE 'com_calendar.%');
DELETE FROM `#__action_logs_extensions` WHERE (extension = 'com_calendar');