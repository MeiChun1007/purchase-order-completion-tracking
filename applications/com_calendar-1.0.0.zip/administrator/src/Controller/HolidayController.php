<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Calendar
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Calendar\Component\Calendar\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Versioning\VersionableControllerTrait;

/**
 * Holiday controller class.
 *
 * @since  1.0.0
 */
class HolidayController extends FormController
{
	use VersionableControllerTrait;

	protected $view_list = 'holidays';
}
