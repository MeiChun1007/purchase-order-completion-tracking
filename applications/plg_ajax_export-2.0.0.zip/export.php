<?php

/**
 * @copyright	Copyright (c) 2026 exportdata. All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Database\DatabaseInterface;

require_once __DIR__ . '/xlsxwriter.php';

/**
 * ajax - export Plugin.
 *
 * Exposes com_data's "Total Data Entry" + "NC Data Entry" records as a
 * downloadable .xlsx file via Joomla's core com_ajax dispatcher:
 *
 *   index.php?option=com_ajax&plugin=export&group=ajax&format=raw
 *
 * Optional query filters (all optional - omit any of them to widen the export):
 *   &month=<1-12>             Only entries whose date falls in this calendar month
 *   &year=<YYYY>              Only entries whose date falls in this year (defaults to the current year if &month is given without &year)
 *   &state=<0|1|all>          Published (1, default), unpublished (0), or both ("all")
 *
 * @package     Joomla.Plugin
 * @subpackage  ajax.export
 *
 * @since       1.0.0
 */
class plgajaxexport extends CMSPlugin
{
	/**
	 * @var  bool
	 * @since  1.0.0
	 */
	protected $autoloadLanguage = true;

	/**
	 * Constructor. Loads the plugin's language file explicitly, in addition
	 * to the $autoloadLanguage flag above - belt and suspenders, since this
	 * plugin's event can fire from either the site or the administrator
	 * application depending on where the export link is placed.
	 *
	 * @param   object  $subject  The object to observe.
	 * @param   array   $config   An optional associative array of configuration settings.
	 *
	 * @since   1.0.0
	 */
	public function __construct(&$subject, $config = array())
	{
		parent::__construct($subject, $config);

		$this->loadLanguage();
		$this->loadComponentLanguage();
	}

	/**
	 * Load com_data's own language file(s). Joomla only auto-loads a
	 * component's language strings when a request actually goes through
	 * that component (option=com_data); since this plugin is reached via
	 * option=com_ajax instead, every Text::_('COM_DATA_...') call below
	 * would otherwise just print the raw key. Tries the admin path first
	 * (most likely to have it installed), falling back to the site path.
	 *
	 * @return  void
	 *
	 * @since   1.2.0
	 */
	protected function loadComponentLanguage()
	{
		$lang = Factory::getApplication()->getLanguage();

		$lang->load('com_incoming', JPATH_ADMINISTRATOR, null, false, true)
			|| $lang->load('com_incoming', JPATH_SITE, null, false, true);
		$lang->load('com_outgoing', JPATH_ADMINISTRATOR, null, false, true)
			|| $lang->load('com_outgoing', JPATH_SITE, null, false, true);
	}

	/**
	 * Handles the "export" ajax plugin request and streams a .xlsx file
	 * containing every com_data entry (one row per NC row; entries
	 * without any NC row still appear once, with blank NC columns).
	 * Every foreign key (component, model, vendor, remark, nc_category,
	 * nc_type) is resolved to its display label - see getExportRows().
	 *
	 * @return  void  Sends the file directly and terminates the request.
	 *
	 * @throws  \Exception  If the current user is not allowed to export.
	 *
	 * @since   1.0.0
	 */
	public function onAjaxExport()
	{
		$app  = Factory::getApplication();
		$user = $app->getIdentity();

		$input = $app->getInput();

		$month = $input->getString('month', '');
		$year  = $input->getString('year', '');
		$type  = $input->getString('type', '');
		$state = $input->getString('state', (string) $this->params->get('default_state', '1'));

		if ($type === 'SotSummary' || $type === 'SotDaily') {
			$this->exportSot($type);
			$app->close();
			return;
		}

		$monthNames = array(
			1 => 'Jan',
			2 => 'Feb',
			3 => 'Mar',
			4 => 'Apr',
			5 => 'May',
			6 => 'Jun',
			7 => 'Jul',
			8 => 'Aug',
			9 => 'Sep',
			10 => 'Oct',
			11 => 'Nov',
			12 => 'Dec',
		);

		// If a month was given without a year, default to the current year
		// rather than matching that month across every year in the data.
		if ($month == '') {
			$month = Factory::getDate()->format('n');
		}
		if ($month !== '' && $year === '') {
			$year = Factory::getDate()->format('Y');
		}

		if ($type == "Incoming") {
			$rows = $this->getExportIncomingRows($month, $year, $state);
			$this->exportIncoming($monthNames[$month], $year, $rows);
		} elseif ($type == "Outgoing") {
			$rows = $this->getExportOutgoingRows($month, $year, $state);
			$this->exportOutgoing($monthNames[$month], $year, $rows);
		}

		$app->close();
	}

	/**
	 * Incoming
	 * Load every com_data entry, one row per NC row (LEFT JOIN, so entries
	 * with no NC row yet still appear once with blank NC columns).
	 *
	 * component, model, vendor, remark, nc_category and nc_type are all
	 * stored as foreign keys, so every one of them is resolved here to its
	 * display label rather than exporting the raw id:
	 *   - a.model        -> #__product_catalogs.model_name
	 *   - a.component    -> #__product_components.component_name
	 *   - a.remark       -> #__incoming_remarks.remark
	 *
	 * @param   string  $month  Optional month filter (1-12).
	 * @param   string  $year   Optional year filter (YYYY). Only applied if $month is also set.
	 * @param   string  $state  '1' (published, default), '0' (unpublished), or 'all'.
	 *
	 * @return  array
	 *
	 * @since   1.0.0
	 */
	protected function getExportIncomingRows($month, $year, $state)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				$db->quoteName('a.doc_no', 'doc_no') . ', ' .
					$db->quoteName('a.date', 'date') . ', ' .
					$db->quoteName('a.raw_model', 'raw_model') . ', ' .
					$db->quoteName('pc.component_name', 'part_name') . ', ' .
					$db->quoteName('pm.model_name', 'model_name') . ', ' .
					$db->quoteName('ir.remark', 'remark_name') . ', ' .
					$db->quoteName('a.quantity', 'quantity') . ', ' .
					$db->quoteName('a.terms', 'terms') . ', ' .
					$db->quoteName('a.description', 'description')
			)
			->from($db->quoteName('#__incoming_orders', 'a'))
			->join('LEFT', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'))
			->join('LEFT', $db->quoteName('#__product_components', 'pc') . ' ON ' . $db->quoteName('pc.id') . ' = ' . $db->quoteName('pm.component'))
			->join('LEFT', $db->quoteName('#__incoming_remarks', 'ir') . ' ON ' . $db->quoteName('ir.id') . ' = ' . $db->quoteName('a.remark'))
			->order($db->quoteName('a.date') . ' DESC, ' . $db->quoteName('a.id') . ' DESC');

		if ($month !== '') {
			$query->where('MONTH(' . $db->quoteName('a.date') . ') = ' . (int) $month);
		}

		if ($year !== '') {
			$query->where('YEAR(' . $db->quoteName('a.date') . ') = ' . (int) $year);
		}

		if ($state !== 'all') {
			$query->where($db->quoteName('a.state') . ' = ' . (int) $state);
		}

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	function exportIncoming($month, $year, $rows)
	{
		$sheetRows   = array();
		$sheetRows[] = array(
			Text::_('COM_INCOMING_INCOMINGORDERS_DOC_NO'),
			Text::_('COM_INCOMING_INCOMINGORDERS_DATE'),
			Text::_('COM_INCOMING_INCOMINGORDERS_RAW_MODEL'),
			Text::_('COM_INCOMING_INCOMINGORDERS_PART'),
			Text::_('COM_INCOMING_INCOMINGORDERS_MODEL'),
			Text::_('COM_INCOMING_INCOMINGORDERS_QUANTITY'),
			Text::_('COM_INCOMING_INCOMINGORDERS_REMARK'),
			Text::_('COM_INCOMING_INCOMINGORDERS_TERMS'),
			Text::_('COM_INCOMING_INCOMINGORDERS_DESCRIPTION'),
		);

		foreach ($rows as $row) {
			// Reformat the date to Ymd (e.g. "20260716") rather than the raw
			// stored datetime string.
			$formattedDate = '';

			if (!empty($row->date)) {
				try {
					$formattedDate = Factory::getDate($row->date)->format('Y-m-d');
				} catch (\Exception $e) {
					// Fall back to the raw value if it somehow isn't parseable,
					// rather than losing the row's date entirely.
					$formattedDate = $row->date;
				}
			}

			$sheetRows[] = array(
				$row->doc_no,
				$formattedDate,
				$row->raw_model,
				$row->part_name,
				$row->model_name,
				$row->quantity,
				$row->remark_name,
				$row->terms,
				$row->description,
			);
		}

		$filename = $year . '_' . $month . '_' . 'Incoming_Orders_' . Factory::getDate('now', 'Asia/Kuala_Lumpur')->format('Ymd', true) . '.xlsx';

		PlgAjaxExportXlsxWriter::output($sheetRows, $filename, 'Incoming Orders');
	}


	/**
	 * Outgoing
	 * Load every com_data entry, one row per NC row (LEFT JOIN, so entries
	 * with no NC row yet still appear once with blank NC columns).
	 *
	 * component, model, vendor, remark, nc_category and nc_type are all
	 * stored as foreign keys, so every one of them is resolved here to its
	 * display label rather than exporting the raw id:
	 *   - a.model        -> #__product_catalogs.model_name
	 *   - a.component    -> #__product_components.component_name
	 *   - a.remark       -> #__outgoing_remarks.remark
	 *
	 * @param   string  $month  Optional month filter (1-12).
	 * @param   string  $year   Optional year filter (YYYY). Only applied if $month is also set.
	 * @param   string  $state  '1' (published, default), '0' (unpublished), or 'all'.
	 *
	 * @return  array
	 *
	 * @since   1.0.0
	 */
	protected function getExportOutgoingRows($month, $year, $state)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				$db->quoteName('a.doc_no', 'doc_no') . ', ' .
					$db->quoteName('a.date', 'date') . ', ' .
					$db->quoteName('a.raw_model', 'raw_model') . ', ' .
					$db->quoteName('pc.component_name', 'part_name') . ', ' .
					$db->quoteName('pm.model_name', 'model_name') . ', ' .
					$db->quoteName('ir.remark', 'remark_name') . ', ' .
					$db->quoteName('a.quantity', 'quantity') . ', ' .
					$db->quoteName('a.terms', 'terms') . ', ' .
					$db->quoteName('a.description', 'description')
			)
			->from($db->quoteName('#__outgoing_orders', 'a'))
			->join('LEFT', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'))
			->join('LEFT', $db->quoteName('#__product_components', 'pc') . ' ON ' . $db->quoteName('pc.id') . ' = ' . $db->quoteName('pm.component'))
			->join('LEFT', $db->quoteName('#__outgoing_remarks', 'ir') . ' ON ' . $db->quoteName('ir.id') . ' = ' . $db->quoteName('a.remark'))
			->order($db->quoteName('a.date') . ' DESC, ' . $db->quoteName('a.id') . ' DESC');

		if ($month !== '') {
			$query->where('MONTH(' . $db->quoteName('a.date') . ') = ' . (int) $month);
		}

		if ($year !== '') {
			$query->where('YEAR(' . $db->quoteName('a.date') . ') = ' . (int) $year);
		}

		if ($state !== 'all') {
			$query->where($db->quoteName('a.state') . ' = ' . (int) $state);
		}

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	function exportOutgoing($month, $year, $rows)
	{
		$sheetRows   = array();
		$sheetRows[] = array(
			Text::_('COM_OUTGOING_OUTGOINGORDERS_DOC_NO'),
			Text::_('COM_OUTGOING_OUTGOINGORDERS_DATE'),
			Text::_('COM_OUTGOING_OUTGOINGORDERS_RAW_MODEL'),
			Text::_('COM_OUTGOING_OUTGOINGORDERS_PART'),
			Text::_('COM_OUTGOING_OUTGOINGORDERS_MODEL'),
			Text::_('COM_OUTGOING_OUTGOINGORDERS_QUANTITY'),
			Text::_('COM_OUTGOING_OUTGOINGORDERS_REMARK'),
			Text::_('COM_OUTGOING_OUTGOINGORDERS_TERMS'),
			Text::_('COM_OUTGOING_OUTGOINGORDERS_DESCRIPTION'),
		);

		foreach ($rows as $row) {
			// Reformat the date to Ymd (e.g. "20260716") rather than the raw
			// stored datetime string.
			$formattedDate = '';

			if (!empty($row->date)) {
				try {
					$formattedDate = Factory::getDate($row->date)->format('Y-m-d');
				} catch (\Exception $e) {
					// Fall back to the raw value if it somehow isn't parseable,
					// rather than losing the row's date entirely.
					$formattedDate = $row->date;
				}
			}

			$sheetRows[] = array(
				$row->doc_no,
				$formattedDate,
				$row->raw_model,
				$row->part_name,
				$row->model_name,
				$row->quantity,
				$row->remark_name,
				$row->terms,
				$row->description,
			);
		}

		$filename = $year . '_' . $month . '_' . 'Outgoing_Orders_' . Factory::getDate('now', 'Asia/Kuala_Lumpur')->format('Ymd', true) . '.xlsx';

		PlgAjaxExportXlsxWriter::output($sheetRows, $filename, 'Outgoing Orders');
	}

	/**
	 * SOT Summary / SOT Daily Tracker export.
	 *
	 * Uses the same models as the two pages (com_sot), so the spreadsheet always matches the screen,
	 * and takes the same filters from the URL:
	 *   &type=SotSummary&year=2026&month=10&as_of=2026-10-27&part=0&model=0
	 *   &type=SotDaily&period=date&from=2026-10-01&to=2026-10-27&part=0&model=0
	 */
	protected function exportSot($type)
	{
		$app = Factory::getApplication();

		if ($app->getIdentity()->guest) {
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), 403);
		}

		// com_sot's own strings (column names, statuses): this request goes through com_ajax, not com_sot
		$app->getLanguage()->load('com_sot', JPATH_SITE, null, false, true);

		$factory = $app->bootComponent('com_sot')->getMVCFactory();

		if ($type === 'SotSummary') {
			$report = $factory->createModel('Sotsummary', 'Site')->getReport();
			$rows   = $this->sotSummaryRows($report);
			$name   = 'SOT_Summary_' . $report['year'] . '-' . sprintf('%02d', $report['month'])
				. '_asof_' . str_replace('-', '', $report['as_of']) . '.xlsx';

			PlgAjaxExportXlsxWriter::output($rows, $name, 'SOT Summary');

			return;
		}

		$report = $factory->createModel('Sotdaily', 'Site')->getReport();
		$rows   = $this->sotDailyRows($report);
		$name   = 'SOT_Daily_' . str_replace('-', '', $report['from']) . '_' . str_replace('-', '', $report['to']) . '.xlsx';

		PlgAjaxExportXlsxWriter::output($rows, $name, 'SOT Daily');
	}

	/**
	 * One row per model. Month and As-of are repeated on every row so a saved file explains itself.
	 */
	protected function sotSummaryRows(array $r)
	{
		$status = array(
			'behind'   => Text::_('COM_SOT_REPORT_STATUS_BEHIND'),
			'on_track' => Text::_('COM_SOT_REPORT_STATUS_ON_TRACK'),
			'closed'   => Text::_('COM_SOT_REPORT_STATUS_CLOSED'),
			'no_po'    => Text::_('COM_SOT_REPORT_STATUS_NO_PO'),
		);

		$sheet   = array();
		$sheet[] = array(
			'PO No',
			Text::_('COM_SOT_REPORT_FILTER_MONTH'),
			Text::_('COM_SOT_REPORT_ASOF_LABEL'),
			Text::_('COM_SOT_REPORT_FILTER_PART'),
			Text::_('COM_SOT_REPORT_COL_MODEL'),
			Text::_('COM_SOT_REPORT_COL_TOTAL_PO'),
			Text::_('COM_SOT_REPORT_COL_PLAN_TO_DATE'),
			Text::_('COM_SOT_REPORT_COL_INCOMING'),
			Text::_('COM_SOT_REPORT_COL_OUTGOING_FG'),
			Text::_('COM_SOT_REPORT_COL_SUBCON_DIFF'),
			Text::_('COM_SOT_REPORT_COL_BAL_PO'),
			Text::_('COM_SOT_REPORT_COL_BAL_WIP'),
			Text::_('COM_SOT_REPORT_COL_BAL_FG'),
			Text::_('COM_SOT_REPORT_COL_BAL_NC'),
			Text::_('COM_SOT_REPORT_COL_STATUS'),
		);

		$month = $r['year'] . '-' . sprintf('%02d', $r['month']);

		foreach ($r['groups'] as $g) {
			foreach ($g['rows'] as $row) {
				$sheet[] = array(
					$row['po_no'],
					$month,
					$r['as_of'],
					$g['part'],
					$row['model'],
					(int) $row['total_po'],
					(int) $row['plan_to_date'],
					(int) $row['incoming'],
					(int) $row['fg'],
					(int) $row['subcon_diff'],
					(int) $row['balance'],
					(int) $row['bal_wip'],
					(int) $row['bal_fg'],
					(int) $row['bal_nc'],
					$status[$row['status']] ?? $row['status'],
				);
			}
		}

		return $sheet;
	}

	/**
	 * One row per model per day (per month when the period is Year). A flat table like this
	 * filters and pivots well in Excel, and holds everything the cards show.
	 */
	protected function sotDailyRows(array $r)
	{
		$metrics = array('plan', 'in_vs', 'fg_vs', 'sort_vs', 'wo', 'pr', 'fg', 'nc', 'scrap', 'sort', 'pnc', 'accepted', 'bal_wip', 'bal_fg', 'bal_nc');

		$header = array(
			'PO No',
			Text::_('COM_SOT_REPORT_FILTER_PART'),
			Text::_('COM_SOT_REPORT_COL_MODEL'),
			Text::_('COM_SOT_REPORT_COL_TOTAL_PO'),
			Text::_('COM_SOT_REPORT_COL_DATE'),
			Text::_('COM_SOT_REPORT_COL_DAYTYPE'),
		);

		foreach ($metrics as $m) {
			$label    = Text::_('COM_SOT_REPORT_METRIC_' . strtoupper($m));
			$header[] = strpos($m, 'bal_') === 0 ? Text::_('COM_SOT_REPORT_GROUP_BALANCE') . ' ' . $label : $label;
		}

		$sheet = array($header);

		foreach ($r['cards'] as $card) {
			$line = array($card['part'], $card['model'], $card['po_no'], (int) $card['total_po'], Text::_('COM_SOT_REPORT_COL_CARRIED_OVER'), '');

			foreach ($metrics as $m) {
				$v      = $card['carry'][$m] ?? null;
				$line[] = $v === null ? '' : (int) $v;
			}

			$sheet[] = $line;
			foreach ($r['buckets'] as $b) {
				$line = array(
					$card['po_no'],
					$card['part'],
					$card['model'],
					(int) $card['total_po'],
					$r['gran'] === 'month' ? substr($b['start'], 0, 7) : $b['start'],
					$r['gran'] === 'month' ? '' : ($b['off'] ? Text::_('COM_SOT_REPORT_OFF') : Text::_('COM_SOT_REPORT_DAYTYPE_WORKING')),
				);

				foreach ($metrics as $m) {
					$v      = $card['series'][$m][$b['key']] ?? null;
					$line[] = $v === null ? '' : (int) $v;   // "vs plan" is blank for days still to come
				}

				$sheet[] = $line;
			}
		}

		return $sheet;
	}
}
