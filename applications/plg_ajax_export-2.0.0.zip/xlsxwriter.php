<?php
/**
 * @copyright	Copyright (c) 2026 exportdata. All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// No direct access
defined('_JEXEC') or die;

/**
 * Writes a genuine .xlsx workbook (single sheet) with no external
 * dependencies beyond the ZipArchive extension that ships with PHP.
 *
 * Kept intentionally simple: one worksheet, inline strings (no shared
 * strings table), no styling beyond Excel's own defaults. That's enough
 * for a data export and avoids depending on a Composer library such as
 * PhpSpreadsheet being present.
 *
 * @since  1.0.0
 */
class PlgAjaxExportXlsxWriter
{
	/**
	 * Build the workbook and stream it to the browser as a file download.
	 *
	 * @param   array   $rows       Array of rows; each row is an array of scalar cell values.
	 *                              The first row is treated as the header row.
	 * @param   string  $filename   Download filename, e.g. "com_data_export_20260723.xlsx".
	 * @param   string  $sheetName  Worksheet tab name.
	 *
	 * @return  void  Sends headers + file content directly; does not return control to the caller.
	 *
	 * @since   1.0.0
	 */
	public static function output(array $rows, $filename, $sheetName = 'Export')
	{
		if (!class_exists('ZipArchive'))
		{
			throw new \RuntimeException('The PHP ZipArchive extension is required to export to .xlsx.');
		}

		$tmpFile = tempnam(sys_get_temp_dir(), 'xlsx');

		$zip = new \ZipArchive();
		$zip->open($tmpFile, \ZipArchive::OVERWRITE);

		$zip->addFromString('[Content_Types].xml', self::contentTypesXml());
		$zip->addFromString('_rels/.rels', self::rootRelsXml());
		$zip->addFromString('xl/_rels/workbook.xml.rels', self::workbookRelsXml());
		$zip->addFromString('xl/workbook.xml', self::workbookXml($sheetName));
		$zip->addFromString('xl/styles.xml', self::stylesXml());
		$zip->addFromString('xl/worksheets/sheet1.xml', self::sheetXml($rows));

		$zip->close();

		while (ob_get_level() > 0)
		{
			ob_end_clean();
		}

		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		header('Content-Length: ' . filesize($tmpFile));
		header('Cache-Control: max-age=0, must-revalidate');
		header('Pragma: public');

		readfile($tmpFile);
		unlink($tmpFile);
	}

	/**
	 * @return  string
	 * @since   1.0.0
	 */
	protected static function contentTypesXml()
	{
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
			. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
			. '<Default Extension="xml" ContentType="application/xml"/>'
			. '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
			. '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
			. '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
			. '</Types>';
	}

	/**
	 * @return  string
	 * @since   1.0.0
	 */
	protected static function rootRelsXml()
	{
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
			. '</Relationships>';
	}

	/**
	 * @return  string
	 * @since   1.0.0
	 */
	protected static function workbookRelsXml()
	{
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
			. '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
			. '</Relationships>';
	}

	/**
	 * @param   string  $sheetName  Worksheet tab name.
	 *
	 * @return  string
	 * @since   1.0.0
	 */
	protected static function workbookXml($sheetName)
	{
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
			. 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
			. '<sheets><sheet name="' . htmlspecialchars($sheetName, ENT_XML1, 'UTF-8') . '" sheetId="1" r:id="rId1"/></sheets>'
			. '</workbook>';
	}

	/**
	 * @return  string
	 * @since   1.0.0
	 */
	protected static function stylesXml()
	{
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
			. '<fonts count="2">'
			. '<font><sz val="11"/><name val="Calibri"/></font>'
			. '<font><b/><sz val="11"/><name val="Calibri"/></font>'
			. '</fonts>'
			. '<fills count="1"><fill><patternFill patternType="none"/></fill></fills>'
			. '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
			. '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
			. '<cellXfs count="2">'
			. '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
			. '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
			. '</cellXfs>'
			. '</styleSheet>';
	}

	/**
	 * @param   array  $rows  Array of rows; each row is an array of scalar cell values.
	 *
	 * @return  string
	 * @since   1.0.0
	 */
	protected static function sheetXml(array $rows)
	{
		$xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
			. '<sheetData>';

		$rowIndex = 1;

		foreach ($rows as $row)
		{
			$xml .= '<row r="' . $rowIndex . '">';

			$colIndex   = 0;
			$isHeader   = ($rowIndex === 1);
			$styleIndex = $isHeader ? 1 : 0;

			foreach ($row as $value)
			{
				$ref = self::columnLetter($colIndex) . $rowIndex;

				if ($value === null || $value === '')
				{
					$xml .= '<c r="' . $ref . '" s="' . $styleIndex . '"/>';
				}
				elseif (is_int($value) || is_float($value) || (is_string($value) && is_numeric($value) && (string) (float) $value === $value))
				{
					$xml .= '<c r="' . $ref . '" s="' . $styleIndex . '"><v>' . self::escapeXml((string) $value) . '</v></c>';
				}
				else
				{
					$escaped = self::escapeXml((string) $value);
					$xml    .= '<c r="' . $ref . '" s="' . $styleIndex . '" t="inlineStr"><is><t xml:space="preserve">' . $escaped . '</t></is></c>';
				}

				$colIndex++;
			}

			$xml .= '</row>';
			$rowIndex++;
		}

		$xml .= '</sheetData></worksheet>';

		return $xml;
	}

	/**
	 * @param   string  $value  Raw text to make XML-safe.
	 *
	 * @return  string
	 * @since   1.0.0
	 */
	protected static function escapeXml($value)
	{
		return htmlspecialchars($value, ENT_QUOTES | ENT_XML1, 'UTF-8');
	}

	/**
	 * Convert a zero-based column index into its spreadsheet letter (0 => A, 26 => AA, ...).
	 *
	 * @param   int  $index  Zero-based column index.
	 *
	 * @return  string
	 * @since   1.0.0
	 */
	protected static function columnLetter($index)
	{
		$letter = '';
		$index++;

		while ($index > 0)
		{
			$mod    = ($index - 1) % 26;
			$letter = chr(65 + $mod) . $letter;
			$index  = (int) (($index - $mod) / 26);
		}

		return $letter;
	}
}
