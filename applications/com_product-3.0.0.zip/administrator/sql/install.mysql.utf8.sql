CREATE TABLE IF NOT EXISTS `#__product_components` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',

`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`component_name` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_1` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_2` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_3` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_4` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_5` VARCHAR(255)  NULL  DEFAULT "",
PRIMARY KEY (`id`)
,KEY `idx_state` (`state`)
,KEY `idx_checked_out` (`checked_out`)
,KEY `idx_created_by` (`created_by`)
,KEY `idx_modified_by` (`modified_by`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__product_catalogs` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`component` VARCHAR(255)  NULL  DEFAULT "",
`model_name` VARCHAR(255)  NULL  DEFAULT "",
`vendor` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_1` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_2` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_3` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_4` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_5` VARCHAR(255)  NULL  DEFAULT "",
PRIMARY KEY (`id`)
,KEY `idx_state` (`state`)
,KEY `idx_checked_out` (`checked_out`)
,KEY `idx_created_by` (`created_by`)
,KEY `idx_modified_by` (`modified_by`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

