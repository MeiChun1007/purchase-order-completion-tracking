<?php
/**
 * @package    Com_Product
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Product\Component\Product\Administrator\Helper;

\defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Http\HttpFactory;
use Joomla\Database\DatabaseInterface;

/**
 * Pulls the product master data from the Data site's API, keeping the same ids:
 *  - #__product_components : state, component_name
 *  - #__product_catalogs   : state, component, model_name
 *
 * Only active on a site where Options > Data Sync (endpoint + token) is filled in,
 * i.e. on SOT. On the Data site those are empty, so the button stays hidden.
 */
class SyncHelper
{
	public static function isConfigured(): bool
	{
		$params = ComponentHelper::getParams('com_product');

		return trim((string) $params->get('sync_endpoint', '')) !== ''
			&& trim((string) $params->get('sync_token', '')) !== '';
	}

	/**
	 * @return  array  ['components' => ['inserted' => n, 'updated' => n], 'catalogs' => [...]]
	 *
	 * @throws  \RuntimeException
	 */
	public static function run(): array
	{
		@set_time_limit(300);

		$params   = ComponentHelper::getParams('com_product');
		$endpoint = trim((string) $params->get('sync_endpoint', ''));
		$token    = trim((string) $params->get('sync_token', ''));

		if ($endpoint === '' || $token === '') {
			throw new \RuntimeException('Sync endpoint or token is not configured (Product > Options > Data Sync).');
		}

		try {
			$response = HttpFactory::getHttp()->get($endpoint, ['X-Joomla-Token' => $token, 'Accept' => 'application/vnd.api+json'], 120);
		} catch (\Throwable $e) {
			throw new \RuntimeException('Request to the Data site failed: ' . $e->getMessage());
		}

		if ((int) $response->code !== 200) {
			$snippet = mb_substr(trim(preg_replace('/\s+/', ' ', strip_tags((string) $response->body))), 0, 200);

			throw new \RuntimeException(
				'The Data site API returned HTTP ' . $response->code . ($snippet !== '' ? ': ' . $snippet : '') . ' (' . $endpoint . ')'
			);
		}

		$json = json_decode((string) $response->body, true);

		if (!isset($json['data']['components'], $json['data']['catalogs']) || !is_array($json['data']['components']) || !is_array($json['data']['catalogs'])) {
			throw new \RuntimeException('Unexpected response from the Data site products API.');
		}

		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$db->transactionStart();

		try {
			// Only these fields are synced; every other column is left as it is on this site.
			$components = self::mirrorTable($db, '#__product_components', $json['data']['components'], ['state', 'component_name']);
			$catalogs   = self::mirrorTable($db, '#__product_catalogs', $json['data']['catalogs'], ['state', 'component', 'model_name']);

			$db->transactionCommit();
		} catch (\Throwable $e) {
			$db->transactionRollback();

			throw new \RuntimeException($e->getMessage());
		}

		return ['components' => $components, 'catalogs' => $catalogs];
	}

	/**
	 * Match rows by id (same ids on both sites). Existing id -> UPDATE only $fields.
	 * Missing id -> INSERT id + $fields (all other columns take their table defaults).
	 *
	 * @param   array  $fields  The only columns to write (besides id).
	 */
	private static function mirrorTable(DatabaseInterface $db, string $table, array $rows, array $fields): array
	{
		try {
			$columns = array_keys($db->getTableColumns($table));
		} catch (\Throwable $e) {
			$columns = [];
		}

		if (empty($columns)) {
			throw new \RuntimeException("Table {$table} was not found on this site.");
		}

		foreach ($fields as $field) {
			if (!in_array($field, $columns, true)) {
				throw new \RuntimeException("Column {$field} does not exist in {$table} on this site.");
			}
		}

		$ids = $db->setQuery(
			$db->getQuery(true)->select($db->quoteName('id'))->from($db->quoteName($table))
		)->loadColumn() ?: [];

		$existing = array_flip(array_map('intval', $ids));

		$inserted = 0;
		$updated  = 0;

		foreach ($rows as $row) {
			$id = (int) ($row['id'] ?? 0);

			if ($id <= 0) {
				continue;
			}

			$values = [];

			foreach ($fields as $field) {
				if (array_key_exists($field, $row)) {
					$values[$field] = $row[$field] === null ? 'NULL' : $db->quote((string) $row[$field]);
				}
			}

			if (isset($existing[$id])) {
				$sets = [];

				foreach ($values as $col => $val) {
					$sets[] = $db->quoteName($col) . ' = ' . $val;
				}

				if ($sets) {
					$db->setQuery(
						'UPDATE ' . $db->quoteName($table) . ' SET ' . implode(', ', $sets)
						. ' WHERE ' . $db->quoteName('id') . ' = ' . $id
					)->execute();
				}

				$updated++;
			} else {
				$values = ['id' => (string) $id] + $values;

				$db->setQuery(
					'INSERT INTO ' . $db->quoteName($table)
					. ' (' . implode(', ', array_map(fn($c) => $db->quoteName($c), array_keys($values))) . ')'
					. ' VALUES (' . implode(', ', $values) . ')'
				)->execute();

				$existing[$id] = true;
				$inserted++;
			}
		}

		return ['inserted' => $inserted, 'updated' => $updated];
	}
}
