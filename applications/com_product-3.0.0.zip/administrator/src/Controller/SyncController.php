<?php
/**
 * @package    Com_Product
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Product\Component\Product\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Product\Component\Product\Administrator\Helper\SyncHelper;

/**
 * task=sync.products  (toolbar button "Sync Products" on the Components / Models lists)
 */
class SyncController extends BaseController
{
	public function products()
	{
		$this->checkToken();

		$app  = Factory::getApplication();
		$user = $app->getIdentity();

		$this->setRedirect($this->returnUrl());

		if (!$user->authorise('core.create', 'com_product') || !$user->authorise('core.edit', 'com_product'))
		{
			$app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');

			return;
		}

		try
		{
			$r = SyncHelper::run();

			$app->enqueueMessage(
				Text::sprintf(
					'COM_PRODUCT_SYNC_PRODUCTS_DONE',
					$r['components']['inserted'],
					$r['components']['updated'],
					$r['catalogs']['inserted'],
					$r['catalogs']['updated']
				),
				'message'
			);
		}
		catch (\Throwable $e)
		{
			$app->enqueueMessage(Text::_('COM_PRODUCT_SYNC_FAILED') . ' ' . $e->getMessage(), 'error');
		}
	}

	/** Back to the list the button was pressed on (same-site referers only). */
	private function returnUrl(): string
	{
		$referer = $this->input->server->getString('HTTP_REFERER', '');

		if ($referer !== '' && Uri::isInternal($referer))
		{
			return $referer;
		}

		return Route::_('index.php?option=com_product&view=components', false);
	}
}
