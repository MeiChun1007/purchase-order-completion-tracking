<?php

/**
 * @version    CVS: 1.0.3
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Sot\Component\Sot\Site\Helper;

defined('_JEXEC') or die;

use Joomla\Database\DatabaseInterface;
use Joomla\CMS\Component\ComponentHelper;

/**
 * Database access shared by the SOT Summary and SOT Daily Tracker models.
 *
 * Source tables:
 *   #__sot_purchase_orders(+_details)  total PO, daily plan, working days
 *   #__incoming_orders                 remark 1 = WO (normal), 2 = PR
 *   #__outgoing_orders                 remark 1 = Scrap, 2 = FG, 3 = NC
 *   #__production_summary              total_sort, total_nc (keyed by model_id)
 *   #__product_components / _catalogs  part and model names
 *   #__calendar_holidays               non-working days
 *
 * Movements are keyed by model id alone: a model always belongs to one part, so the
 * model id is enough and tolerates part ids that are missing on the order rows.
 *
 * @since  1.0.3
 */
class SotReportData
{
	/** @var DatabaseInterface */
	private $db;


	/** @var array|null  Cached result of modelMap() */
	private $mapCache = null;

	public function __construct(DatabaseInterface $db)
	{
		$this->db = $db;
	}

	/**
	 * Part and model lookups.
	 *
	 * @return  array  parts [id => name], models [id => [name, part_id]], partNames / modelNames [lowercase name => id]
	 */
	public function catalog(): array
	{
		$db = $this->db;

		$partRows = $db->setQuery(
			$db->getQuery(true)
				->select(array($db->quoteName('id'), $db->quoteName('component_name')))
				->from($db->quoteName('#__product_components'))
				->where($db->quoteName('state') . ' = 1')
				->order($db->quoteName('id') . ' ASC')
		)->loadObjectList();

		$modelRows = $db->setQuery(
			$db->getQuery(true)
				->select(array($db->quoteName('id'), $db->quoteName('model_name'), $db->quoteName('component')))
				->from($db->quoteName('#__product_catalogs'))
				->where($db->quoteName('state') . ' = 1')
				->order($db->quoteName('model_name') . ' ASC')
		)->loadObjectList();

		$catalog = array('parts' => array(), 'models' => array(), 'partNames' => array(), 'modelNames' => array());

		foreach ($partRows as $r) {
			$catalog['parts'][(int) $r->id] = (string) $r->component_name;

			$catalog['partNames'][self::norm($r->component_name)] = (int) $r->id;
		}

		foreach ($modelRows as $r) {
			// pm.component may hold the part id or the part name
			$partId = self::resolve($r->component, $catalog['parts'], $catalog['partNames']);

			$catalog['models'][(int) $r->id] = array('name' => (string) $r->model_name, 'part_id' => (int) $partId);

			$key = self::norm($r->model_name);

			if (!isset($catalog['modelNames'][$key])) {
				$catalog['modelNames'][$key] = (int) $r->id;
			}
		}

		return $catalog;
	}

	/**
	 * Years that have at least one purchase order.
	 *
	 * @return  int[]
	 */
	public function poYears(): array
	{
		$db = $this->db;

		$years = $db->setQuery(
			$db->getQuery(true)
				->select('DISTINCT ' . $db->quoteName('year'))
				->from($db->quoteName('#__sot_purchase_orders'))
				->where($db->quoteName('year') . ' IS NOT NULL')
				->where($db->quoteName('state') . ' = 1')
				->order($db->quoteName('year') . ' DESC')
		)->loadColumn();

		return array_map('intval', $years ?: array());
	}

	/**
	 * Holidays between two dates (inclusive).
	 *
	 * @return  array  'Y-m-d' => [type, note]
	 */
	public function holidays(string $from, string $to): array
	{
		$db  = $this->db;
		$col = 'DATE(' . $db->quoteName('cal_date') . ')';

		$query = $db->getQuery(true)
			->select(array($db->quoteName('cal_date'), $db->quoteName('type'), $db->quoteName('note')))
			->from($db->quoteName('#__calendar_holidays'))
			->where($db->quoteName('state') . ' = 1')
			->where($col . ' >= :hfrom')
			->where($col . ' <= :hto')
			->bind(':hfrom', $from)
			->bind(':hto', $to);

		$out = array();

		foreach ($db->setQuery($query)->loadObjectList() as $r) {
			$out[substr((string) $r->cal_date, 0, 10)] = array('type' => (string) $r->type, 'note' => (string) $r->note);
		}

		return $out;
	}

	/**
	 * PO lines of published purchase orders, merged per model, with their daily plan.
	 *
	 * @param   int       $fromYear    First month: year
	 * @param   int       $fromMonth   First month: month
	 * @param   int       $toYear      Last month: year
	 * @param   int       $toMonth     Last month: month
	 * @param   array     $catalog     From catalog()
	 * @param   array     $holidays    Holidays covering every month in range
	 * @param   int       $partFilter  0 = all
	 * @param   int       $modelFilter 0 = all
	 * @param   string[]  $unmatched   Receives a note for every PO line whose model is not in the catalog
	 *
	 * @return  array  Keyed by model id: model_id, part_id, part, model, po_nos[], total_po, plan[date => qty], po_wd, year, month, first_id
	 */
	public function poLines(int $fromYear, int $fromMonth, int $toYear, int $toMonth, array $catalog, array $holidays, int $partFilter, int $modelFilter, array &$unmatched): array
	{
		$db = $this->db;
		$lo = $fromYear * 12 + $fromMonth;
		$hi = $toYear * 12 + $toMonth;

		$periodExpr = '(' . $db->quoteName('d.year') . ' * 12 + ' . $db->quoteName('d.month') . ')';

		$query = $db->getQuery(true)
			->select(
				array(
					$db->quoteName('d.id', 'id'),
					$db->quoteName('d.po_no', 'po_no'),
					$db->quoteName('d.year', 'year'),
					$db->quoteName('d.month', 'month'),
					$db->quoteName('d.part', 'part'),
					$db->quoteName('d.model', 'model'),
					$db->quoteName('d.total_po', 'total_po'),
					$db->quoteName('d.daily_plan_qty', 'daily_plan_qty'),
					$db->quoteName('p.working_days', 'working_days'),
				)
			)
			->from($db->quoteName('#__sot_purchase_orders_details', 'd'))
			->join('INNER', $db->quoteName('#__sot_purchase_orders', 'p') . ' ON ' . $db->quoteName('p.id') . ' = ' . $db->quoteName('d.po_id'))
			->where($db->quoteName('p.state') . ' = 1')
			->where($periodExpr . ' >= :lo')
			->where($periodExpr . ' <= :hi')
			->order($db->quoteName('d.id') . ' ASC')
			->bind(':lo', $lo, \Joomla\Database\ParameterType::INTEGER)
			->bind(':hi', $hi, \Joomla\Database\ParameterType::INTEGER);

		$lines = array();

		foreach ($db->setQuery($query)->loadObjectList() as $r) {
			// part / model hold the catalog id (or, for older rows, the name)
			$modelId = self::resolve($r->model, $catalog['models'], $catalog['modelNames']);

			if ($modelId === null) {
				$unmatched[] = trim($r->po_no . ': ' . $r->part . ' / ' . $r->model);

				continue;
			}

			$partId = self::resolve($r->part, $catalog['parts'], $catalog['partNames']);

			if ($partId === null) {
				$partId = $catalog['models'][$modelId]['part_id'];
			}

			if (($partFilter && $partId !== $partFilter) || ($modelFilter && $modelId !== $modelFilter)) {
				continue;
			}

			$year  = (int) $r->year;
			$month = (int) $r->month;
			$plan  = SotReport::planSchedule($year, $month, $holidays, (int) $r->total_po, (int) $r->daily_plan_qty, (int) $r->working_days);

			if (!isset($lines[$modelId])) {
				$lines[$modelId] = array(
					'model_id' => $modelId,
					'part_id'  => $partId,
					'part'     => $catalog['parts'][$partId] ?? ((string) $r->part !== '' ? (string) $r->part : '-'),
					'model'    => $catalog['models'][$modelId]['name'],
					'po_nos'   => array(),
					'total_po' => 0,
					'plan'     => array(),
					'po_wd'    => 0,
					'year'     => $year,
					'month'    => $month,
					'first_id' => (int) $r->id,
				);
			}

			$line = &$lines[$modelId];

			if ($r->po_no !== '' && !in_array($r->po_no, $line['po_nos'], true)) {
				$line['po_nos'][] = (string) $r->po_no;
			}

			$line['total_po'] += (int) $r->total_po;
			$line['plan']      = SotReport::mergePlan($line['plan'], $plan);
			$line['po_wd']     = max($line['po_wd'], (int) $r->working_days);

			unset($line);
		}

		uasort(
			$lines,
			static function ($a, $b) {
				return array($a['part_id'], $a['model_id']) <=> array($b['part_id'], $b['model_id']);
				// return array($a['part_id'], $a['first_id']) <=> array($b['part_id'], $b['first_id']);
			}
		);

		return $lines;
	}

	/**
	 * Movements per model per date between two dates (inclusive).
	 *
	 * @param   string  $from      First date
	 * @param   string  $to        Last date
	 * @param   int[]   $modelIds  Models to load
	 *
	 * @return  array  metric => model id => 'Y-m-d' => quantity; metrics: wo, pr, fg, nc, scrap, sort, pnc
	 */
	public function movements(string $from, string $to, array $modelIds): array
	{
		$out = array(
			'wo' => array(),
			'pr' => array(),
			'fg' => array(),
			'nc' => array(),
			'scrap' => array(),
			'sort' => array(),
			'pnc' => array(),
			'co_wo' => array(),
			'co_fg' => array(),
			'co_sort' => array(),
			'co_pnc' => array()
		);

		if (!$modelIds || $to < $from) {
			return $out;
		}

		$start = $from . ' 00:00:00';
		$end   = (new \DateTimeImmutable($to))->modify('+1 day')->format('Y-m-d') . ' 00:00:00';

		foreach ($this->orders('#__incoming_orders', $start, $end, $modelIds) as $r) {
			$metric = (int) $r->remark === SotReport::IN_WO ? 'wo'
				: ((int) $r->remark === SotReport::IN_PR ? 'pr'
					: ((int) $r->remark === SotReport::IN_CARRY ? 'co_wo' : null));

			if ($metric) {
				self::add($out[$metric], (int) $r->model_id, $r->d, (int) $r->qty);
			}
		}

		$outMap = array(SotReport::OUT_FG => 'fg', SotReport::OUT_NC => 'nc', SotReport::OUT_SCRAP => 'scrap', SotReport::OUT_CARRY => 'co_fg');

		foreach ($this->orders('#__outgoing_orders', $start, $end, $modelIds) as $r) {
			if (isset($outMap[(int) $r->remark])) {
				self::add($out[$outMap[(int) $r->remark]], (int) $r->model_id, $r->d, (int) $r->qty);
			}
		}

		// Production may report variants (e.g. L1..L4) of a model the PO and orders know as one (L)
		$map    = $this->modelMap();
		$wanted = array_flip($modelIds);
		$prodId = $modelIds;

		foreach ($map as $child => $parent) {
			if (isset($wanted[$parent])) {
				$prodId[] = $child;
			}
		}

		foreach ($this->production($start, $end, array_values(array_unique($prodId))) as $r) {
			$id = (int) $r->model_id;
			$id = (isset($map[$id]) && isset($wanted[$map[$id]])) ? $map[$id] : $id;

			if (!isset($wanted[$id])) {
				continue;
			}

			$sortKey = $r->manual ? 'co_sort' : 'sort';
			$ncKey   = $r->manual ? 'co_pnc'  : 'pnc';

			self::add($out[$sortKey], $id, $r->d, (int) $r->total_sort);
			self::add($out[$ncKey],   $id, $r->d, (int) $r->total_nc);
		}

		return $out;
	}

	/**
	 * Quantity per day / model / remark from an orders table.
	 */
	private function orders(string $table, string $start, string $end, array $modelIds): array
	{
		$db      = $this->db;
		$dateCol = $db->quoteName('o.date');

		$query = $db->getQuery(true)
			->select(
				array(
					'DATE(' . $dateCol . ') AS ' . $db->quoteName('d'),
					$db->quoteName('o.model', 'model_id'),
					$db->quoteName('o.remark', 'remark'),
					'SUM(' . $db->quoteName('o.quantity') . ') AS ' . $db->quoteName('qty'),
				)
			)
			->from($db->quoteName($table, 'o'))
			->where($db->quoteName('o.state') . ' = 1')
			->where($dateCol . ' >= :ostart')
			->where($dateCol . ' < :oend')
			->whereIn($db->quoteName('o.model'), $modelIds)
			->group(array('DATE(' . $dateCol . ')', $db->quoteName('o.model'), $db->quoteName('o.remark')))
			->bind(':ostart', $start)
			->bind(':oend', $end);

		return $db->setQuery($query)->loadObjectList();
	}

	/**
	 * Total sort / total NC per day / model from #__production_summary.
	 * Manual rows (source = 'manual') are flagged so they can be shown as "Carried over".
	 */
	private function production(string $start, string $end, array $modelIds): array
	{
		$db      = $this->db;
		$dateCol = $db->quoteName('s.date');

		// 1 for rows entered manually (carried over), 0 for the rest
		$manual = 'CASE WHEN ' . $db->quoteName('s.source') . ' = ' . $db->quote('manual') . ' THEN 1 ELSE 0 END';

		$query = $db->getQuery(true)
			->select(
				array(
					'DATE(' . $dateCol . ') AS ' . $db->quoteName('d'),
					$db->quoteName('s.model_id', 'model_id'),
					'SUM(' . $db->quoteName('s.total_sort') . ') AS ' . $db->quoteName('total_sort'),
					'SUM(' . $db->quoteName('s.total_nc') . ') AS ' . $db->quoteName('total_nc'),
					$manual . ' AS ' . $db->quoteName('manual'),
				)
			)
			->from($db->quoteName('#__production_summary', 's'))
			->where($db->quoteName('s.state') . ' = 1')
			->where($dateCol . ' >= :pstart')
			->where($dateCol . ' < :pend')
			->whereIn($db->quoteName('s.model_id'), $modelIds)
			->group(array('DATE(' . $dateCol . ')', $db->quoteName('s.model_id'), $manual))
			->bind(':pstart', $start)
			->bind(':pend', $end);

		return $db->setQuery($query)->loadObjectList();
	}

	/**
	 * Add a quantity into metric[model][date].
	 */
	private static function add(array &$metric, int $modelId, string $date, int $qty): void
	{
		$date = substr($date, 0, 10);

		$metric[$modelId][$date] = ($metric[$modelId][$date] ?? 0) + $qty;
	}

	/**
	 * Resolve a stored reference to a catalog id. Accepts the id itself or the name.
	 *
	 * @param   mixed  $value     Stored value (id or name)
	 * @param   array  $byId      Catalog keyed by id
	 * @param   array  $nameToId  Lowercase name => id
	 */
	private static function resolve($value, array $byId, array $nameToId): ?int
	{
		$value = trim((string) $value);

		if ($value === '') {
			return null;
		}

		if (ctype_digit($value) && isset($byId[(int) $value])) {
			return (int) $value;
		}

		return $nameToId[self::norm($value)] ?? null;
	}

	private static function norm($name): string
	{
		return mb_strtolower(trim((string) $name));
	}

	/**
	 * Year / month pairs that have a published purchase order.
	 *
	 * @return  array  year => [months ascending], newest year first
	 */
	public function poPeriods(): array
	{
		$db = $this->db;

		$rows = $db->setQuery(
			$db->getQuery(true)
				->select('DISTINCT ' . $db->quoteName('year'))
				->select($db->quoteName('month'))
				->from($db->quoteName('#__sot_purchase_orders'))
				->where($db->quoteName('year') . ' IS NOT NULL')
				->where($db->quoteName('month') . ' IS NOT NULL')
				->where($db->quoteName('state') . ' = 1')
				->order($db->quoteName('year') . ' DESC')
				->order($db->quoteName('month') . ' ASC')
		)->loadObjectList();

		$out = array();

		foreach ($rows as $r) {
			$out[(int) $r->year][] = (int) $r->month;
		}

		return $out;
	}

	/**
	 * Production variant => main model, from the component Options (Model Mapping).
	 *
	 * @return  array  child model id => parent model id
	 */
	public function modelMap(): array
	{
		static $map = null;

		if ($map !== null) {
			return $map;
		}

		$map  = array();
		$rows = (array) ComponentHelper::getParams('com_sot')->get('model_map', array());

		foreach ($rows as $row) {
			$row  = (object) $row;
			$main = (int) ($row->main ?? 0);

			if ($main <= 0) {
				continue;
			}

			foreach (preg_split('/\s*[,;\s]\s*/', trim((string) ($row->variants ?? '')), -1, PREG_SPLIT_NO_EMPTY) as $part) {
				if (preg_match('/^(\d+)\s*-\s*(\d+)$/', $part, $m)) {
					$from = (int) $m[1];
					$to   = min((int) $m[2], $from + 99);   // sanity cap on a range

					for ($id = $from; $id <= $to; $id++) {
						if ($id > 0 && $id !== $main) {
							$map[$id] = $main;
						}
					}
				} elseif ((int) $part > 0 && (int) $part !== $main) {
					$map[(int) $part] = $main;
				}
			}
		}

		return $map;
	}
}
