<?php

/**
 * @copyright	Copyright (c) 2026. All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// no direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Session\Session;
use Joomla\Database\DatabaseInterface;

/**
 * Ajax - Update Part and Model
 *
 * Does the same lookup as the importorders plugin (models_mapping): an order's
 * raw_model is matched to #__product_catalogs.custom_field_1, then
 *     order.model = catalog.id
 *     order.part  = catalog.component
 *
 * Call:  index.php?option=com_ajax&group=ajax&plugin=updatepartmodel&format=json
 * POST:  type = Incoming | Outgoing
 *        mode = unmatched (default: only orders without a model) | all (re-match every order)
 *        <form token> = 1
 */
class PlgAjaxUpdatepartmodel extends CMSPlugin
{
	/** type => [orders table, component used for the permission check] */
	private const TYPES = [
		'incoming' => ['#__incoming_orders', 'com_incoming'],
		'outgoing' => ['#__outgoing_orders', 'com_outgoing'],
	];

	/** How many unmatched Model names to list in the message */
	private const SHOW_UNMATCHED = 15;

	public function onAjaxUpdatepartmodel()
	{
		$app = Factory::getApplication();

		if (!Session::checkToken('post'))
		{
			throw new \RuntimeException('Invalid token. Please reload the page and try again.', 403);
		}

		$type = strtolower($app->getInput()->post->getString('type', ''));

		if (!isset(self::TYPES[$type]))
		{
			throw new \InvalidArgumentException('Unknown order type.', 400);
		}

		[$table, $component] = self::TYPES[$type];

		if (!$app->getIdentity()->authorise('core.edit.state', $component))
		{
			throw new \RuntimeException('You are not allowed to update these orders.', 403);
		}

		$all = $app->getInput()->post->getString('mode', 'unmatched') === 'all';

		$db = Factory::getContainer()->get(DatabaseInterface::class);
		$t  = $db->quoteName($table);

		// "no model yet": NULL, '' or 0 (the importer stores '' when nothing matched).
		// Compared as text so it works for INT and VARCHAR columns, also in strict SQL mode.
		$unmatched = "COALESCE(CAST(o.`model` AS CHAR), '') IN ('', '0')";

		// One catalog row per Model name (lowest id), so the result never depends on row order
		$update = "UPDATE $t AS o"
			. " INNER JOIN (SELECT `custom_field_1`, MIN(`id`) AS `id` FROM `#__product_catalogs` WHERE `state` = 1 GROUP BY `custom_field_1`) AS m"
			. " ON m.`custom_field_1` = o.`raw_model`"
			. " INNER JOIN `#__product_catalogs` AS c ON c.`id` = m.`id`"
			. " SET o.`part` = c.`component`, o.`model` = c.`id`"
			. " WHERE o.`state` <> -2" . ($all ? '' : " AND $unmatched");

		$db->setQuery($update)->execute();
		$updated = (int) $db->getAffectedRows();

		// What is still not matched? (so the user knows what to add to the catalog)
		$db->setQuery("SELECT COUNT(*) FROM $t AS o WHERE o.`state` <> -2 AND $unmatched");
		$left = (int) $db->loadResult();

		$names = [];

		if ($left > 0)
		{
			$db->setQuery(
				"SELECT DISTINCT o.`raw_model` FROM $t AS o"
				. " WHERE o.`state` <> -2 AND $unmatched AND o.`raw_model` <> ''"
				. " ORDER BY o.`raw_model`",
				0,
				self::SHOW_UNMATCHED + 1
			);
			$names = $db->loadColumn() ?: [];
		}

		$message = "$updated order(s) updated.";

		if ($left > 0)
		{
			$more     = count($names) > self::SHOW_UNMATCHED;
			$names    = array_slice($names, 0, self::SHOW_UNMATCHED);
			$message .= " $left order(s) still have no matching Model in the product catalog"
				. ($names ? ': ' . implode(', ', $names) . ($more ? ', ...' : '') : '') . '.';
		}

		return ['updated' => $updated, 'unmatched' => $left, 'message' => $message];
	}
}
