<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Production
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 QC YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Production\Component\Production\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\Database\DatabaseInterface;
use \Joomla\Database\ParameterType;

/**
 * Methods supporting a list of Production records.
 *
 * @since  1.0.0
 */
class ProductionreportModel extends ListModel
{
	/**
	 * Extra filters: request name => column in #__production_summary.
	 * They only take effect when the column actually exists in the table.
	 *
	 * @var array
	 */
	protected array $extraFilters = [
		'vendor'      => 'vendor',
		'lot'         => 'lot',
		'remark'      => 'remark',
		'operator'    => 'operator',
		'nc_category' => 'nc_category',
		'nc_type'     => 'nc_type',
	];

	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see    JController
	 * @since  1.0.0
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id',
				'a.id',
				'state',
				'a.state',
				'ordering',
				'a.ordering',
				'created_by',
				'a.created_by',
				'modified_by',
				'a.modified_by',
				'date',
				'a.date',
				'model_id',
				'a.model_id',
				'model',
				'a.model',
				'total_sort',
				'a.total_sort',
				'total_nc',
				'a.total_nc',
				'total_acc',
				'a.total_acc',
				'synced_at',
				'a.synced_at',
				'part',
				'a.part',
				'model_name',
				'pm.model_name',
				'part_name',
				'pc.component_name',
			);
		}

		parent::__construct($config);
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return  void
	 *
	 * @throws  \Exception
	 *
	 * @since   1.0.0
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState("a.id", "ASC");

		$app  = Factory::getApplication();
		$list = $app->getUserState($this->context . '.list');

		$value = $app->getUserState($this->context . '.list.limit', $app->get('list_limit', 25));
		$list['limit'] = $value;

		$this->setState('list.limit', $value);

		$value = $app->input->get('limitstart', 0, 'uint');
		$this->setState('list.start', $value);

		$ordering  = $this->getUserStateFromRequest($this->context . '.filter_order', 'filter_order', "a.id");
		$direction = strtoupper($this->getUserStateFromRequest($this->context . '.filter_order_Dir', 'filter_order_Dir', "ASC"));

		if (!empty($ordering) || !empty($direction)) {
			$list['fullordering'] = $ordering . ' ' . $direction;
		}

		$app->setUserState($this->context . '.list', $list);

		$context = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $context);

		// Split context into component and optional section
		if (!empty($context)) {
			$parts = FieldsHelper::extract($context);

			if ($parts) {
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  \Joomla\Database\DatabaseQuery
	 *
	 * @since   1.0.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select',
				'DISTINCT a.*'
			)
		);

		$query->from('`#__production_summary` AS a');

		// Join over the users for the checked out user.
		$query->select('uc.name AS uEditor');
		$query->join('LEFT', '#__users AS uc ON uc.id=a.checked_out');

		$query->select($db->quoteName('pm.model_name', 'model_name'));
		$query->join('LEFT', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'));

		$query->select($db->quoteName('pc.component_name', 'part_name'));
		$query->join('LEFT', $db->quoteName('#__product_components', 'pc') . ' ON ' . $db->quoteName('pc.id') . ' = ' . $db->quoteName('a.part'));


		if (!Factory::getApplication()->getIdentity()->authorise('core.edit', 'com_production')) {
			$query->where('a.state = 1');
		} else {
			$query->where('(a.state IN (0, 1))');
		}

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search)) {
			if (stripos($search, 'id:') === 0) {
				$query->where('a.id = ' . (int) substr($search, 3));
			} else {
				$search = '%' . $search . '%';
				$query->where('( pm.model_name LIKE :search_0 OR  pc.component_name LIKE :search_1)')
					->bind([':search_0', ':search_1'], $search);
			}
		}

		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', "a.id");
		$orderDirn = $this->state->get('list.direction', "ASC");

		if ($orderCol && $orderDirn) {
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}

	/**
	 * Method to get an array of data items
	 *
	 * @return  mixed An array of data on success, false on failure.
	 */
	public function getItems()
	{
		$items = parent::getItems();

		return $items;
	}

	/**
	 * Overrides the default function to check Date fields format, identified by
	 * "_dateformat" suffix, and erases the field if it's not correct.
	 *
	 * @return void
	 */
	protected function loadFormData()
	{
		$app              = Factory::getApplication();
		$filters          = $app->getUserState($this->context . '.filter', array());
		$error_dateformat = false;

		foreach ($filters as $key => $value) {
			if (strpos($key, '_dateformat') && !empty($value) && $this->isValidDate($value) == null) {
				$filters[$key]    = '';
				$error_dateformat = true;
			}
		}

		if ($error_dateformat) {
			$app->enqueueMessage(Text::_("COM_PRODUCTION_SEARCH_FILTER_DATE_FORMAT"), "warning");
			$app->setUserState($this->context . '.filter', $filters);
		}

		return parent::loadFormData();
	}

	/**
	 * Checks if a given date is valid and in a specified format (YYYY-MM-DD)
	 *
	 * @param   string  $date  Date to be checked
	 *
	 * @return bool
	 */
	private function isValidDate($date)
	{
		$date = str_replace('/', '-', $date);
		return (date_create($date)) ? Factory::getDate($date)->format("Y-m-d") : null;
	}

	/* ---------------------------------------------------------------------
	 * Pivot view (Part / Model x Day or Week, with Sort + NC)
	 * ------------------------------------------------------------------- */

	/**
	 * Read the pivot filters from the request (remembered in the user state).
	 *
	 * @return  object
	 */
	public function getFilters(): object
	{
		$app = Factory::getApplication();
		$ctx = 'com_production.pivot';
		$now = new \DateTime();
		$f   = new \stdClass;

		// Clear Filters: wipe the stored state, then fall through to the defaults
		if ($app->input->getInt('clearfilters', 0) === 1) {
			$keys = array_merge(
				['period_type', 'year', 'month', 'week', 'date_from', 'date_to', 'part', 'model'],
				array_keys($this->extraFilters)
			);

			foreach ($keys as $key) {
				$app->setUserState($ctx . '.' . $key, null);
				$app->input->set('filter_' . $key, null);
			}
		}

		$f->period_type = $app->getUserStateFromRequest($ctx . '.period_type', 'filter_period_type', 'month', 'cmd');
		$f->year        = $app->getUserStateFromRequest($ctx . '.year', 'filter_year', (int) $now->format('o'), 'int');
		$f->month       = $app->getUserStateFromRequest($ctx . '.month', 'filter_month', (int) $now->format('n'), 'int');
		$f->week        = $app->getUserStateFromRequest($ctx . '.week', 'filter_week', (int) $now->format('W'), 'int');
		$f->date_from   = $app->getUserStateFromRequest($ctx . '.date_from', 'filter_date_from', $now->format('Y-m-01'), 'string');
		$f->date_to     = $app->getUserStateFromRequest($ctx . '.date_to', 'filter_date_to', $now->format('Y-m-d'), 'string');
		$f->part        = $app->getUserStateFromRequest($ctx . '.part', 'filter_part', '', 'string');
		$f->model       = $app->getUserStateFromRequest($ctx . '.model', 'filter_model', '', 'string');

		foreach (array_keys($this->extraFilters) as $name) {
			// Remark defaults to Normal ('0'), as in the Data site reports
			$default  = $name === 'remark' ? '0' : '';
			$f->$name = (string) $app->getUserStateFromRequest($ctx . '.' . $name, 'filter_' . $name, $default, 'string');
		}

		return $f;
	}

	/**
	 * Column names of #__production_summary (cached).
	 *
	 * @return  string[]
	 */
	protected function tableColumns(): array
	{
		static $cols = null;

		return $cols ??= array_keys($this->getDatabase()->getTableColumns('#__production_summary'));
	}

	/**
	 * Returns [start DateTime, end DateTime, 'day'|'week'].
	 * 'day'  = one column per day, 'week' = one column per ISO week.
	 */
	protected function getRange(object $f): array
	{
		if ($f->period_type === 'year') {
			$s = new \DateTime(sprintf('%04d-01-01', (int) $f->year));
			$e = new \DateTime(sprintf('%04d-12-31', (int) $f->year));

			return [$s, $e, 'month'];
		}

		if ($f->period_type === 'week') {
			$s = (new \DateTime())->setISODate((int) $f->year, (int) $f->week);   // Monday
			$e = (clone $s)->modify('+6 days');

			return [$s, $e, 'day'];
		}

		if ($f->period_type === 'custom') {
			$s = new \DateTime($f->date_from ?: 'today');
			$e = new \DateTime($f->date_to ?: 'today');

			if ($e < $s) {
				$e = clone $s;
			}

			// Keep the table readable
			if ($s->diff($e)->days > 62) {
				$e = (clone $s)->modify('+62 days');
			}

			return [$s, $e, 'day'];
		}

		$s = new \DateTime(sprintf('%04d-%02d-01', (int) $f->year, (int) $f->month));
		$e = (clone $s)->modify('last day of this month');

		return [$s, $e, 'week'];
	}

	public function getYearOptions(): array
	{
		$db = $this->getDatabase();
		$q  = $db->getQuery(true)
			->select('DISTINCT YEAR(' . $db->quoteName('date') . ') AS yr')
			->from($db->quoteName('#__production_summary'))
			->where($db->quoteName('date') . ' IS NOT NULL')
			->order('yr DESC');

		$years   = array_map('intval', $db->setQuery($q)->loadColumn() ?: []);
		$current = (int) date('Y');

		if (!in_array($current, $years, true)) {
			$years[] = $current;
			rsort($years);
		}

		return $years;
	}

	/**
	 * Calendar months of the selected year, newest first.
	 * Always includes the current month (if it's the current year) and the selected month.
	 *
	 * @return  array  List of objects: { value: 7, label: "July" }
	 */
	public function getMonthOptions(): array
	{
		$f  = $this->getFilters();
		$db = $this->getDatabase();

		$query = $db->getQuery(true)
			->select('DISTINCT MONTH(' . $db->quoteName('date') . ') AS mo')
			->from($db->quoteName('#__production_summary'))
			->where('YEAR(' . $db->quoteName('date') . ') = ' . (int) $f->year);

		$months = array_map('intval', $db->setQuery($query)->loadColumn() ?: []);

		$now = Factory::getDate('now', 'Asia/Kuala_Lumpur');

		if ((int) $now->format('Y') === (int) $f->year) {
			$months[] = (int) $now->format('n');
		}

		// Keep the selected month choosable even with no data
		$months[] = (int) $f->month;

		$months = array_unique($months);
		rsort($months);

		$options = [];

		foreach ($months as $m) {
			$options[] = (object) [
				'value' => $m,
				'label' => (new \DateTime(sprintf('%04d-%02d-01', (int) $f->year, $m)))->format('F'),
			];
		}

		return $options;
	}

	/**
	 * ISO weeks of the selected (ISO) year that have data, newest first.
	 * Always includes the current week (if it's the current ISO year) and the selected week.
	 *
	 * @return  array  List of objects: { value: 43, label: "19 Oct - 25 Oct" }
	 */
	public function getWeekOptions(): array
	{
		$f  = $this->getFilters();
		$db = $this->getDatabase();

		$query = $db->getQuery(true)
			->select('DISTINCT WEEK(' . $db->quoteName('date') . ', 3) AS wk')
			->from($db->quoteName('#__production_summary'))
			->where('YEARWEEK(' . $db->quoteName('date') . ', 3) DIV 100 = ' . (int) $f->year);

		$weeks = array_map('intval', $db->setQuery($query)->loadColumn() ?: []);

		$now = Factory::getDate('now', 'Asia/Kuala_Lumpur');

		if ((int) $now->format('o') === (int) $f->year) {
			$weeks[] = (int) $now->format('W');
		}

		// Keep the selected week choosable even with no data
		$weeks[] = (int) $f->week;

		$weeks = array_unique($weeks);
		rsort($weeks);

		$options = [];

		foreach ($weeks as $w) {
			$mon = (new \DateTime())->setISODate((int) $f->year, $w);
			$sun = (clone $mon)->modify('+6 days');

			$options[] = (object) [
				'value' => $w,
				'label' => $mon->format('d M') . ' - ' . $sun->format('d M'),
			];
		}

		return $options;
	}


	/**
	 * Build the pivot data.
	 *
	 * @return  array  ['columns' => [key => label], 'parts' => [part => [model => ['total' => int, 'cells' => [key => ['sort' => int, 'nc' => int]]]]]]
	 */
	public function getPivot(): array
	{
		$f = $this->getFilters();
		[$start, $end, $mode] = $this->getRange($f);

		$bucket = fn(\DateTime $d) => match ($mode) {
			'day'   => $d->format('Y-m-d'),
			'month' => $d->format('Y-m'),
			default => $d->format('o-W'),
		};

		// Build columns
		$columns = [];

		for ($d = clone $start; $d <= $end; $d->modify('+1 day')) {
			$key = $bucket($d);

			if (!isset($columns[$key])) {
				$columns[$key] = match ($mode) {
					'day'   => $d->format('d M'),
					'month' => $d->format('M'),
					default => 'Week ' . $d->format('W'),
				};
			}
		}

		// Query
		$startStr = $start->format('Y-m-d');
		$endStr   = $end->format('Y-m-d');
		$partVal  = (string) $f->part;
		$modelVal = (string) $f->model;
		// part / model are catalog ids: filter on the ids, show (and group by) the names
		$partId  = (int) $partVal;
		$modelId = (int) $modelVal;

		$db = $this->getDatabase();

		// Manual rows are not daily output: they go to the Carried Over column
		$manualExpr = in_array('source', $this->tableColumns(), true)
			? 'CASE WHEN ' . $db->quoteName('a.source') . ' = ' . $db->quote('manual') . ' THEN 1 ELSE 0 END'
			: '0';

		$query = $db->getQuery(true)
			->select($db->quoteName('a.date', 'date'))
			->select($manualExpr . ' AS ' . $db->quoteName('is_manual'))
			->select('COALESCE(' . $db->quoteName('pc.component_name') . ', ' . $db->quote('-') . ') AS ' . $db->quoteName('part'))
			->select('COALESCE(' . $db->quoteName('pm.model_name') . ', ' . $db->quote('-') . ') AS ' . $db->quoteName('model'))
			->select('SUM(' . $db->quoteName('a.total_sort') . ') AS ' . $db->quoteName('sum_sort'))
			->select('SUM(' . $db->quoteName('a.total_nc') . ') AS ' . $db->quoteName('sum_nc'))
			->select('SUM(' . $db->quoteName('a.total_acc') . ') AS ' . $db->quoteName('sum_acc'))
			->from($db->quoteName('#__production_summary', 'a'))
			->join('LEFT', $db->quoteName('#__product_components', 'pc') . ' ON pc.id = a.part')
			->join('LEFT', $db->quoteName('#__product_catalogs', 'pm') . ' ON pm.id = a.model')
			->where($db->quoteName('a.state') . ' = 1')
			->where($db->quoteName('a.date') . ' BETWEEN :s AND :e')
			->bind(':s', $startStr)
			->bind(':e', $endStr)
			->group($db->quoteName(['a.date', 'a.part', 'a.model', 'pc.component_name', 'pm.model_name', 'is_manual']))
			->order($db->quoteName(['pc.component_name', 'pm.model_name', 'a.date']));

		if ($partId > 0) {
			$query->where($db->quoteName('a.part') . ' = :part')->bind(':part', $partId, ParameterType::INTEGER);
		}

		if ($modelId > 0) {
			$query->where($db->quoteName('a.model') . ' = :model')->bind(':model', $modelId, ParameterType::INTEGER);
		}

		// Extra filters (only if the column exists in the table)
		$extraVals = [];

		foreach ($this->extraFilters as $name => $column) {
			if ($f->$name === '' || !in_array($column, $this->tableColumns(), true)) {
				continue;
			}

			$extraVals[$name] = (string) $f->$name;
			$query->where($db->quoteName('a.' . $column) . ' = :f_' . $name)
				->bind(':f_' . $name, $extraVals[$name]);
		}

		$db->setQuery($query);

		// Pivot in PHP: $parts[part][model] = ['total' => , 'cells' => [colKey => ['sort', 'nc']]]
		$parts = [];

		foreach ($db->loadObjectList() as $r) {
			$key = $bucket(new \DateTime($r->date));
			$row = &$parts[$r->part][$r->model];
			$row ??= ['total' => 0, 'total_nc' => 0, 'total_acc' => 0,'carried_sort' => 0, 'carried_nc' => 0, 'carried_acc' => 0,'cells' => []];

			if ((int) $r->is_manual === 1) {
				// not part of any daily/weekly column
				$row['carried_sort'] += (int) $r->sum_sort;
				$row['carried_nc']   += (int) $r->sum_nc;
				$row['carried_acc']   += (int) $r->sum_acc;
			} else {
				$row['cells'][$key] ??= ['sort' => 0, 'nc' => 0, 'acc' => 0];
				$row['cells'][$key]['sort'] += (int) $r->sum_sort;
				$row['cells'][$key]['nc']   += (int) $r->sum_nc;
				$row['cells'][$key]['acc']   += (int) $r->sum_acc;
			}

			// totals = carried over + the period columns
			$row['total']    += (int) $r->sum_sort;
			$row['total_nc'] += (int) $r->sum_nc;
			$row['total_acc'] += (int) $r->sum_acc;
			unset($row);
		}

		return ['columns' => $columns, 'parts' => $parts];
	}

	/**
	 * Distinct values of a column as objects (value / text / key).
	 * Returns an empty array if the column doesn't exist in #__production_summary.
	 *
	 * @param   string  $column  Column name
	 *
	 * @return  object[]
	 */
	public function getDistinctOptions(string $column): array
	{
		if (!in_array($column, $this->tableColumns(), true)) {
			return [];
		}

		$db = $this->getDatabase();
		$q  = $db->getQuery(true)
			->select('DISTINCT ' . $db->quoteName($column))
			->from($db->quoteName('#__production_summary'))
			->where($db->quoteName($column) . ' IS NOT NULL')
			->where($db->quoteName($column) . " <> ''")
			->order($db->quoteName($column));

		$out = [];

		foreach ($db->setQuery($q)->loadColumn() as $v) {
			$out[] = (object) ['value' => $v, 'text' => $v, 'key' => $v];
		}

		return $out;
	}

	/**
	 * Parts that have data, as value = component id / text = component name.
	 */
	public function getPartOptions(): array
	{
		$db = $this->getDatabase();
		$q  = $db->getQuery(true)
			->select('DISTINCT ' . $db->quoteName('pc.id', 'value') . ', ' . $db->quoteName('pc.component_name', 'text'))
			->from($db->quoteName('#__production_summary', 'a'))
			->join('INNER', $db->quoteName('#__product_components', 'pc') . ' ON pc.id = a.part')
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('pc.component_name'));

		return $db->setQuery($q)->loadObjectList() ?: [];
	}

	/**
	 * Models that have data, as value = catalog id / text = model name.
	 */
	public function getModelOptions(): array
	{
		$db = $this->getDatabase();
		$q  = $db->getQuery(true)
			->select('DISTINCT ' . $db->quoteName('pm.id', 'value') . ', ' . $db->quoteName('pm.model_name', 'text'))
			->from($db->quoteName('#__production_summary', 'a'))
			->join('INNER', $db->quoteName('#__product_catalogs', 'pm') . ' ON pm.id = a.model')
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('pm.model_name'));

		return $db->setQuery($q)->loadObjectList() ?: [];
	}

	/**
	 * Most recent sync time (UTC, as stored), or null if nothing has been synced yet.
	 */
	public function getLastSync(): ?string
	{
		$db = $this->getDatabase();
		$q  = $db->getQuery(true)
			->select('MAX(' . $db->quoteName('synced_at') . ')')
			->from($db->quoteName('#__production_summary'));

		$value = $db->setQuery($q)->loadResult();

		return $value ?: null;
	}
}
