<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Production
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 QC YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Production\Component\Production\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\CMS\Layout\FileLayout;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use \Production\Component\Production\Site\Helper\ProductionHelper;
use \Joomla\Database\DatabaseInterface;

/**
 * Methods supporting a list of Production records.
 *
 * @since  1.0.0
 */
class ProductionsummariesModel extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see    JController
	 * @since  1.0.0
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id',
				'a.id',
				'state',
				'a.state',
				'ordering',
				'a.ordering',
				'created_by',
				'a.created_by',
				'modified_by',
				'a.modified_by',
				'date',
				'a.date',
				'model_id',
				'a.model_id',
				'model',
				'a.model',
				'total_sort',
				'a.total_sort',
				'total_nc',
				'a.total_nc',
				'total_acc',
				'a.total_acc',
				'synced_at',
				'a.synced_at',
				'part',
				'a.part',
				'model_name',
				'pm.model_name',
				'part_name',
				'pc.component_name',
			);
		}

		parent::__construct($config);
	}



	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return  void
	 *
	 * @throws  \Exception
	 *
	 * @since   1.0.0
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState("a.date", "DESC");

		$app = Factory::getApplication();
		$list = $app->getUserState($this->context . '.list');

		$value = $app->getUserState($this->context . '.list.limit', $app->get('list_limit', 25));
		$list['limit'] = $value;

		$this->setState('list.limit', $value);

		$value = $app->input->get('limitstart', 0, 'uint');
		$this->setState('list.start', $value);

		$ordering  = $this->getUserStateFromRequest($this->context . '.filter_order', 'filter_order', "a.date");
		$direction = strtoupper($this->getUserStateFromRequest($this->context . '.filter_order_Dir', 'filter_order_Dir', "DESC"));

		if (!empty($ordering) || !empty($direction)) {
			$list['fullordering'] = $ordering . ' ' . $direction;
		}

		// Default the year filter to the current year on first load
		$year = $this->getUserStateFromRequest($this->context . '.filter.year', 'filter_year', date('Y'), 'int');
		$this->setState('filter.year', $year);

		// Default the month filter to the current month on first load
		$month = $this->getUserStateFromRequest($this->context . '.filter.month', 'filter_month', date('n'), 'int');
		$this->setState('filter.month', $month);

		// --- Week range ---
		if (!empty($week)) {
			$this->weekStart = new \DateTime();
			$this->weekStart->setISODate((int) $year, (int) $week, 1)->setTime(0, 0, 0);

			$this->weekEnd = clone $this->weekStart;
			$this->weekEnd->modify('+6 days')->setTime(23, 59, 59);

			$this->setState('filter.weekStart', $this->weekStart);
			$this->setState('filter.weekEnd', $this->weekEnd);
		} else {
			$this->setState('filter.weekStart', null);
			$this->setState('filter.weekEnd', null);
		}

		// --- Month range (used as fallback display when week = 'all') ---
		if (!empty($month) && $month !== 'all') {
			$this->monthStart = new \DateTime();
			$this->monthStart->setDate((int) $year, (int) $month, 1)->setTime(0, 0, 0);

			$this->monthEnd = clone $this->monthStart;
			$this->monthEnd->modify('last day of this month')->setTime(23, 59, 59);

			$this->setState('filter.monthStart', $this->monthStart);
			$this->setState('filter.monthEnd', $this->monthEnd);
		} else {
			$this->setState('filter.monthStart', null);
			$this->setState('filter.monthEnd', null);
		}

		// --- Year range ---
		if (!empty($year)) {
			$this->yearStart = new \DateTime();
			$this->yearStart->setDate((int) $year, 1, 1)->setTime(0, 0, 0);

			$this->yearEnd = clone $this->yearStart;
			$this->yearEnd->setDate((int) $year, 12, 31)->setTime(23, 59, 59);

			$this->setState('filter.yearStart', $this->yearStart);
			$this->setState('filter.yearEnd', $this->yearEnd);
		} else {
			$this->setState('filter.yearStart', null);
			$this->setState('filter.yearEnd', null);
		}

		// --- Custom date range (from/to) — takes priority over week/month/year for display ---
		$dateFrom = $this->getUserStateFromRequest($this->context . '.filter.date_from', 'filter_date_from');
		$dateTo   = $this->getUserStateFromRequest($this->context . '.filter.date_to', 'filter_date_to');

		$this->setState('filter.date_from', $dateFrom);
		$this->setState('filter.date_to', $dateTo);

		if (!empty($dateFrom)) {
			$this->dateFrom = \DateTime::createFromFormat('Y-m-d', $dateFrom);
			if ($this->dateFrom) {
				$this->dateFrom->setTime(0, 0, 0);
			}
			$this->setState('filter.dateFromObj', $this->dateFrom);
		} else {
			$this->setState('filter.dateFromObj', null);
		}

		if (!empty($dateTo)) {
			$this->dateTo = \DateTime::createFromFormat('Y-m-d', $dateTo);
			if ($this->dateTo) {
				$this->dateTo->setTime(23, 59, 59);
			}
			$this->setState('filter.dateToObj', $this->dateTo);
		} else {
			$this->setState('filter.dateToObj', null);
		}

		// --- Validate date range against week/month/year filters ---
		$conflictDetected = false;

		// Case 1: dateFrom is after dateTo
		if (!empty($this->dateFrom) && !empty($this->dateTo) && $this->dateFrom > $this->dateTo) {
			$conflictDetected = true;
			$app->enqueueMessage(
				Text::_('COM_INCOMING_FILTER_DATE_FROM_AFTER_TO'),
				'warning'
			);
		}

		// Case 1b: dateTo falls outside the selected week's range
		if (!$conflictDetected && !empty($this->dateTo) && !empty($this->weekStart) && !empty($this->weekEnd)) {
			if ($this->dateTo < $this->weekStart || $this->dateTo > $this->weekEnd) {
				$conflictDetected = true;
				$app->enqueueMessage(
					Text::sprintf(
						'COM_INCOMING_FILTER_DATE_OUTSIDE_WEEK',
						$this->dateTo->format('Y-m-d'),
						$this->weekStart->format('Y-m-d'),
						$this->weekEnd->format('Y-m-d')
					),
					'warning'
				);
			}
		}

		// Case 1c: dateFrom falls outside the selected week's range
		if (!$conflictDetected && !empty($this->dateFrom) && !empty($this->weekStart) && !empty($this->weekEnd)) {
			if ($this->dateFrom < $this->weekStart || $this->dateFrom > $this->weekEnd) {
				$conflictDetected = true;
				$app->enqueueMessage(
					Text::sprintf(
						'COM_INCOMING_FILTER_DATE_OUTSIDE_WEEK',
						$this->dateFrom->format('Y-m-d'),
						$this->weekStart->format('Y-m-d'),
						$this->weekEnd->format('Y-m-d')
					),
					'warning'
				);
			}
		}


		// Case 2: dateTo falls outside the selected month's range
		if (!$conflictDetected && !empty($this->dateTo) && !empty($this->monthStart) && !empty($this->monthEnd)) {
			if ($this->dateTo < $this->monthStart || $this->dateTo > $this->monthEnd) {
				$conflictDetected = true;
				$app->enqueueMessage(
					Text::sprintf(
						'COM_INCOMING_FILTER_DATE_OUTSIDE_MONTH',
						$this->dateTo->format('Y-m-d'),
						$this->monthStart->format('F Y')
					),
					'warning'
				);
			}
		}

		// Case 3: dateFrom falls outside the selected month's range
		if (!$conflictDetected && !empty($this->dateFrom) && !empty($this->monthStart) && !empty($this->monthEnd)) {
			if ($this->dateFrom < $this->monthStart || $this->dateFrom > $this->monthEnd) {
				$conflictDetected = true;
				$app->enqueueMessage(
					Text::sprintf(
						'COM_INCOMING_FILTER_DATE_OUTSIDE_MONTH',
						$this->dateFrom->format('Y-m-d'),
						$this->monthStart->format('F Y')
					),
					'warning'
				);
			}
		}

		// Case 4: date range falls entirely outside the selected year
		if (!$conflictDetected && !empty($this->yearStart) && !empty($this->yearEnd)) {
			$outOfYear = (!empty($this->dateFrom) && ($this->dateFrom < $this->yearStart || $this->dateFrom > $this->yearEnd))
				|| (!empty($this->dateTo) && ($this->dateTo < $this->yearStart || $this->dateTo > $this->yearEnd));

			if ($outOfYear) {
				$app->enqueueMessage(
					Text::sprintf('COM_INCOMING_FILTER_DATE_OUTSIDE_YEAR', $this->yearStart->format('Y')),
					'warning'
				);
			}
		}

		$filters = $app->getUserState($this->context . '.filter', array());

		if (empty($filters['year'])) {
			$filters['year'] = $year;
			$app->setUserState($this->context . '.filter', $filters);
		}

		if (empty($filters['month'])) {
			$filters['month'] = $month;
			$app->setUserState($this->context . '.filter', $filters);
		}

		$app->setUserState($this->context . '.list', $list);



		$context = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $context);

		// Split context into component and optional section
		if (!empty($context)) {
			$parts = FieldsHelper::extract($context);

			if ($parts) {
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  \Joomla\Database\DatabaseQuery
	 *
	 * @since   1.0.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select',
				'DISTINCT a.*'
			)
		);

		$query->from('`#__production_summary` AS a');

		// Join over the users for the checked out user.
		$query->select('uc.name AS uEditor');
		$query->join('LEFT', '#__users AS uc ON uc.id=a.checked_out');

		$query->select($db->quoteName('pm.model_name', 'model_name'));
		$query->join('LEFT', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'));

		$query->select($db->quoteName('pc.component_name', 'part_name'));
		$query->join('LEFT', $db->quoteName('#__product_components', 'pc') . ' ON ' . $db->quoteName('pc.id') . ' = ' . $db->quoteName('a.part'));

		if (!Factory::getApplication()->getIdentity()->authorise('core.edit', 'com_production')) {
			$query->where('a.state = 1');
		} else {
			$query->where('(a.state IN (0, 1))');
		}

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search)) {
			if (stripos($search, 'id:') === 0) {
				$query->where('a.id = ' . (int) substr($search, 3));
			} else {
				$search = '%' . $search . '%';
				$query->where('( pm.model_name LIKE :search_0 OR  pc.component_name LIKE :search_1)')
					->bind([':search_0', ':search_1'], $search);
			}
		}

		// Filter by date range
		$dateFrom = $this->getState('filter.date_from');
		if (!empty($dateFrom) && preg_match('/^\d{4}-\d{2}-\d{2}/', $dateFrom)) {
			$dateFrom = substr($dateFrom, 0, 10);
			$query->where('DATE(' . $db->quoteName('a.date') . ') >= :date_from')
				->bind(':date_from', $dateFrom);
		}

		$dateTo = $this->getState('filter.date_to');
		if (!empty($dateTo) && preg_match('/^\d{4}-\d{2}-\d{2}/', $dateTo)) {
			$dateTo = substr($dateTo, 0, 10);
			$query->where('DATE(' . $db->quoteName('a.date') . ') <= :date_to')
				->bind(':date_to', $dateTo);
		}

		// Filter by part (matches the part_name shown in the list)
		$part = $this->getState('filter.part');
		if (!empty($part)) {
			$query->where($db->quoteName('pm.component') . ' = ' . (int) $part);
		}

		// Filter by model
		$modelId = $this->getState('filter.model');
		if (!empty($modelId)) {
			$query->where($db->quoteName('a.model') . ' = ' . (int) $modelId);
		}

		// Filter by remark
		$remark = $this->getState('filter.remark');
		if (!empty($remark)) {
			$query->where($db->quoteName('a.remark') . ' = ' . (int) $remark);
		}

		// Filter by week (YEARWEEK key, e.g. 202631)
		$week = $this->getState('filter.week');
		if (!empty($week)) {
			$query->where('YEARWEEK(' . $db->quoteName('a.date') . ', 3) = ' . (int) $week);
		}

		// Filter by year
		$year = $this->getState('filter.year');
		if (!empty($year)) {
			$query->where('YEAR(' . $db->quoteName('a.date') . ') = ' . (int) $year);
		}

		// Filter by month
		$month = $this->getState('filter.month');
		if (!empty($month) && $month !== 'all') {
			$query->where('MONTH(' . $db->quoteName('a.date') . ') = ' . (int) $month);
		}


		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', "a.date");
		$orderDirn = $this->state->get('list.direction', "DESC");

		if ($orderCol && $orderDirn) {
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}

	/**
	 * Method to get an array of data items
	 *
	 * @return  mixed An array of data on success, false on failure.
	 */
	public function getItems()
	{
		$items = parent::getItems();


		return $items;
	}

	/**
	 * Overrides the default function to check Date fields format, identified by
	 * "_dateformat" suffix, and erases the field if it's not correct.
	 *
	 * @return void
	 */
	protected function loadFormData()
	{
		$app              = Factory::getApplication();
		$filters          = $app->getUserState($this->context . '.filter', array());
		$error_dateformat = false;

		foreach ($filters as $key => $value) {
			if (strpos($key, '_dateformat') && !empty($value) && $this->isValidDate($value) == null) {
				$filters[$key]    = '';
				$error_dateformat = true;
			}
		}

		if ($error_dateformat) {
			$app->enqueueMessage(Text::_("COM_PRODUCTION_SEARCH_FILTER_DATE_FORMAT"), "warning");
			$app->setUserState($this->context . '.filter', $filters);
		}

		return parent::loadFormData();
	}

	/**
	 * Checks if a given date is valid and in a specified format (YYYY-MM-DD)
	 *
	 * @param   string  $date  Date to be checked
	 *
	 * @return bool
	 */
	private function isValidDate($date)
	{
		$date = str_replace('/', '-', $date);
		return (date_create($date)) ? Factory::getDate($date)->format("Y-m-d") : null;
	}
}
