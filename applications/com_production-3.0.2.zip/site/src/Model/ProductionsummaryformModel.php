<?php
/**
 * @package    Com_Production
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Production\Component\Production\Site\Model;

// No direct access.
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\FormModel;
use Joomla\Utilities\ArrayHelper;

/**
 * Site form to add (or edit) a production summary record by hand.
 *
 * part / model_id are filled in by ProductionsummaryTable::check() from the chosen
 * catalog row, so the form only asks for date, model, total sort and total NC.
 */
class ProductionsummaryformModel extends FormModel
{
	protected $item = null;

	protected function populateState()
	{
		$app   = Factory::getApplication();
		$value = $app->getUserState('com_production.edit.productionsummary.id');

		// FormController keeps a list of ids being edited, the old edit() stored a single id
		if (is_array($value)) {
			$value = end($value);
		}

		$this->setState('productionsummary.id', (int) $value);
		$this->setState('params', $app->getParams());
	}

	public function getTable($type = 'Productionsummary', $prefix = 'Administrator', $config = [])
	{
		return parent::getTable($type, $prefix, $config);
	}

	public function getItem($id = null)
	{
		if ($this->item === null) {
			$id    = (int) ($id ?: $this->getState('productionsummary.id'));
			$table = $this->getTable();

			if ($id && $table->load($id)) {
				$this->item = ArrayHelper::toObject($table->getProperties(1));
			} else {
				$this->item = (object) ['id' => 0];
			}
		}

		return $this->item;
	}

	public function getForm($data = [], $loadData = true)
	{
		$form = $this->loadForm(
			'com_production.productionsummaryform',
			'productionsummaryform',
			['control' => 'jform', 'load_data' => $loadData]
		);

		return empty($form) ? false : $form;
	}

	protected function loadFormData()
	{
		$data = Factory::getApplication()->getUserState('com_production.edit.productionsummary.data', []);

		if (empty($data)) {
			$data = $this->getItem();

			if (empty($data->id)) {
				$data->date = Factory::getDate('now', 'Asia/Kuala_Lumpur')->format('Y-m-d');
			}
		}

		return $data;
	}

	/**
	 * @param   array  $data  Validated form data
	 *
	 * @return  boolean
	 */
	public function save($data)
	{
		$user  = Factory::getApplication()->getIdentity();
		$id    = (int) ($data['id'] ?? 0);
		$table = $this->getTable();

		if (!$user->authorise($id ? 'core.edit' : 'core.create', 'com_production')) {
			$this->setError(Text::_('JERROR_ALERTNOAUTHOR'));

			return false;
		}

		if ($id && !$table->load($id)) {
			$this->setError($table->getError() ?: Text::_('COM_PRODUCTION_ITEM_NOT_LOADED'));

			return false;
		}

		// Only these come from the form; part / model_id are derived in the Table.
		// Anything saved here is marked manual so the Data site sync never overwrites it.
		$row           = array_intersect_key($data, array_flip(['date','part', 'model', 'total_sort', 'total_nc', 'total_acc']));
		$row['id']     = $id;
		$row['source'] = 'manual';

		if (!$id) {
			$row['state'] = 1;
		}

		try {
			if (!$table->bind($row) || !$table->check() || !$table->store()) {
				$this->setError($table->getError());

				return false;
			}
		} catch (\Exception $e) {
			$this->setError($e->getMessage());

			return false;
		}

		$this->setState('productionsummary.id', (int) $table->id);

		return true;
	}
}
