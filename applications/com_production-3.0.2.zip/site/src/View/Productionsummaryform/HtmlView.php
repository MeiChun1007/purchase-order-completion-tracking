<?php
/**
 * @package    Com_Production
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Production\Component\Production\Site\View\Productionsummaryform;

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

class HtmlView extends BaseHtmlView
{
	protected $state;

	protected $item;

	protected $form;

	protected $params;

	public function display($tpl = null)
	{
		$app  = Factory::getApplication();
		$user = $app->getIdentity();

		if (!$user->authorise('core.create', 'com_production')) {
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), 403);
		}

		$this->state  = $this->get('State');
		$this->item   = $this->get('Item');
		$this->form   = $this->get('Form');
		$this->params = $app->getParams('com_production');

		if (count($errors = $this->get('Errors'))) {
			throw new \Exception(implode("\n", $errors));
		}

		$this->document->setTitle(Text::_('COM_PRODUCTION_TITLE_PRODUCTIONSUMMARYFORM'));

		parent::display($tpl);
	}
}
