<?php

/**
 * @package    Com_Production
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Production\Component\Production\Site\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Response\JsonResponse;
use Joomla\Database\DatabaseInterface;

/**
 * Add / edit a production summary record from the site.
 */
class ProductionsummaryformController extends FormController
{
	protected $option    = 'com_production';
	protected $context   = 'productionsummary';
	protected $view_item = 'productionsummaryform';
	protected $view_list = 'productionsummaries';

	/**
	 * FormController would otherwise look for a model named after $context.
	 */
	public function getModel($name = 'Productionsummaryform', $prefix = 'Site', $config = ['ignore_request' => true])
	{
		return parent::getModel($name, $prefix, $config);
	}

	public function add()
	{
		// forget a previously edited record so the form starts empty
		$this->app->setUserState('com_production.edit.productionsummary.id', null);

		return parent::add();
	}

	public function edit($key = null, $urlVar = null)
	{
		return parent::edit('id', 'id');
	}

	public function save($key = null, $urlVar = null)
	{
		return parent::save('id', 'id');
	}

	public function getModelsByComponent()
	{
		$app = Factory::getApplication();

		if (!$app->getIdentity()->authorise('core.create', 'com_production')) {
			echo new JsonResponse(null, Text::_('JERROR_ALERTNOAUTHOR'), true);
			$app->close();
		}

		$cid   = $this->input->getInt('component_id', 0);
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true)
			->select($db->quoteName(['id', 'model_name'], ['key', 'value']))
			->from($db->quoteName('#__product_catalogs'))
			->where($db->quoteName('state') . ' = 1')
			->order($db->quoteName('model_name'));

		// component_id = 0 -> every model; otherwise only the models of that component
		if ($cid > 0) {
			$cidStr = (string) $cid;
			$query->where('FIND_IN_SET(:cid, REPLACE(' . $db->quoteName('component') . ", ' ', '')) > 0")
				->bind(':cid', $cidStr);
		}

		echo new JsonResponse($db->setQuery($query)->loadObjectList());
		$app->close();
	}
}
