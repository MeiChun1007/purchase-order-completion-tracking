<?php

namespace Production\Component\Production\Site\Field;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\Database\DatabaseInterface;

class ProductionweekField extends ListField
{
    protected $type = 'Productionweek';

    protected function getOptions()
    {
        // The <option> from the XML (the "- Select Week -" header)
        $options = parent::getOptions();

        $app = Factory::getApplication();
        $db  = Factory::getContainer()->get(DatabaseInterface::class);

        // Selected year: current request first, then the saved session value
        $filter = $app->input->get('filter', null, 'array');
        if (!is_array($filter)) {
            $filter = (array) $app->getUserState('com_production.productionsummaries.filter', []);
        }
        $year = (int) ($filter['year'] ?? 0);

        $query = $db->getQuery(true)
            ->select('DISTINCT YEARWEEK(' . $db->quoteName('date') . ', 3) AS ' . $db->quoteName('wk'))
            ->from($db->quoteName('#__production_summary'))
            ->where($db->quoteName('date') . ' IS NOT NULL')
            ->order($db->quoteName('wk') . ' DESC');

        if ($year) {
            $query->where('YEAR(' . $db->quoteName('date') . ') = ' . $year);
        }

        $db->setQuery($query);

        foreach ($db->loadColumn() as $wk) {
            $isoYear = (int) substr($wk, 0, 4);
            $weekNo  = (int) substr($wk, 4);

            $monday = new \DateTime();
            $monday->setISODate($isoYear, $weekNo, 1);
            $sunday = clone $monday;
            $sunday->modify('+6 days');

            // Show the year only when it isn't obvious from the selected year
            $prefix = ($year && $isoYear === $year) ? '' : $isoYear . ' - ';
            $label  = $prefix . 'Week ' . $weekNo
                . ' (' . $monday->format('d M') . ' - ' . $sunday->format('d M') . ')';

            $options[] = HTMLHelper::_('select.option', $wk, $label);
        }

        return $options;
    }
}