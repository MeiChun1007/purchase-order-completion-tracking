<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Production
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 QC YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Production\Component\Production\Site\Service;
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\Categories\Categories;
/**
 * Content Component Category Tree
 *
 * @since  1.0.0
 */

