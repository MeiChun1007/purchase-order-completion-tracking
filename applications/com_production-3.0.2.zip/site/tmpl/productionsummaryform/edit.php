<?php

/**
 * @package    Com_Production
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
	->useScript('form.validate');

$existingComponentId = (string) $this->form->getValue('part');
$existingModelId     = (string) $this->form->getValue('model');
?>

<div class="productionsummary-edit">
	<div class="page-header">
		<h1><?php echo Text::_('COM_PRODUCTION_TITLE_PRODUCTIONSUMMARYFORM'); ?></h1>
	</div>

	<form action="<?php echo Route::_('index.php?option=com_production&id=' . (int) ($this->item->id ?? 0)); ?>"
		method="post" name="adminForm" id="productionsummary-form" class="form-validate form-horizontal">

		<?php echo $this->form->renderField('date'); ?>
		<?php echo $this->form->renderField('part'); ?>
		<?php echo $this->form->renderField('model'); ?>
		<?php echo $this->form->renderField('total_sort'); ?>
		<?php echo $this->form->renderField('total_nc'); ?>
		<?php echo $this->form->renderField('total_acc'); ?>

		<?php echo $this->form->getInput('id'); ?>

		<div class="control-group" style="margin-top: 2rem;">
			<div class="controls d-flex justify-content-end" style="gap: 3px;">
				<button type="submit" name="task" value="productionsummaryform.cancel" class="btn btn-danger" formnovalidate>
					<span class="icon-times" aria-hidden="true"></span> <?php echo Text::_('JCANCEL'); ?>
				</button>
				<button type="submit" name="task" value="productionsummaryform.save" class="validate btn btn-primary">
					<span class="icon-check" aria-hidden="true"></span> <?php echo Text::_('JSAVE'); ?>
				</button>
			</div>
		</div>


		<?php echo HTMLHelper::_('form.token'); ?>
	</form>
</div>

<script>
	document.addEventListener('DOMContentLoaded', function() {
		const existingComponentId = <?php echo json_encode((string) $existingComponentId); ?>;
		const existingModelId = <?php echo json_encode((string) $existingModelId); ?>;

		// Absolute URL, so it also works on SEF / menu-alias pages
		const modelsUrl = <?php echo json_encode(Uri::root() . 'index.php?option=com_production&task=productionsummaryform.getModelsByComponent&format=json'); ?>;

		/**
		 * Fetch and populate the Model dropdown for a given Component.
		 * If selectedModelId is provided, that option is pre-selected
		 * (used on page load to restore the saved value).
		 */
		function populateModelField(componentId, selectedModelId) {
			selectedModelId = selectedModelId || '';

			const modelField = document.querySelector('select[name="jform[model]"]');
			if (!modelField) {
				console.error("Could not find the model select element by name attribute.");
				return;
			}

			const modelWrapper = modelField.closest('joomla-field-fancy-select');

			modelField.innerHTML = '<option value="">Select Model</option>';

			if (modelWrapper && modelWrapper.choicesInstance) {
				modelWrapper.choicesInstance.clearChoices();
				modelWrapper.choicesInstance.setChoices([{
					value: '',
					label: 'Select Model',
					selected: true
				}], 'value', 'label', true);
			}


			fetch(`${modelsUrl}&component_id=${componentId || 0}`)
				.then(response => response.json())
				.then(data => {
					if (data && data.success && data.data) {

						data.data.forEach(model => {
							const option = new Option(model.value, model.key);
							if (String(model.key) === String(selectedModelId)) {
								option.selected = true;
							}
							modelField.add(option);
						});

						if (modelWrapper && modelWrapper.choicesInstance) {
							const newChoices = data.data.map(m => ({
								value: String(m.key),
								label: String(m.value),
								selected: String(m.key) === String(selectedModelId)
							}));

							modelWrapper.choicesInstance.setChoices(newChoices, 'value', 'label', true);
						}
					}
				})
				.catch(error => console.error('Error Syncing JSON payload:', error));
		}

		// --- Component -> Model cascade ---
		const componentField = document.querySelector('select[name="jform[part]"]');


		document.addEventListener('change', function(event) {
			if (componentField && event.target === componentField) {
				populateModelField(componentField.value);
			}
		});

		// --- Initialize on page load (edit mode): restore dependent dropdowns
		// to match the already-saved Component/Vendor selections ---
		if (existingComponentId) {
			populateModelField(existingComponentId, existingModelId);
		}
	});
</script>