<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Production
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 QC YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Layout\LayoutHelper;
use \Joomla\CMS\Session\Session;
use \Joomla\CMS\User\UserFactoryInterface;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');

$user       = Factory::getApplication()->getIdentity();
$userId     = $user->get('id');
$listOrder  = $this->state->get('list.ordering');
$listDirn   = $this->state->get('list.direction');
$canCreate  = $user->authorise('core.create', 'com_production') && file_exists(JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'productionsummaryform.xml');
$canEdit    = $user->authorise('core.edit', 'com_production') && file_exists(JPATH_COMPONENT .  DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'productionsummaryform.xml');
$canCheckin = $user->authorise('core.manage', 'com_production');
$canChange  = $user->authorise('core.edit.state', 'com_production');
$canDelete  = $user->authorise('core.delete', 'com_production');

// Import CSS
$wa = $this->document->getWebAssetManager();
$wa->useStyle('com_production.list');
?>

<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
	</div>
<?php endif; ?>

<form action="<?php echo htmlspecialchars(Uri::getInstance()->toString()); ?>" method="post"
	name="adminForm" id="adminForm">
	<?php if (!empty($this->filterForm)) {
		echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this));
	} ?>

	<div class="button d-flex justify-content-end w-100 mb-3 " style="padding: 10px 28px; gap: 8px" ;>
		<!-- Add button -->
		<?php if (Factory::getApplication()->getIdentity()->authorise('core.create', 'com_production')) : ?>
			<div class="mb-3 text-end">
				<a class="btn btn-success" href="<?php echo Route::_('index.php?option=com_production&task=productionsummaryform.add'); ?>">
					<span class="icon-plus" aria-hidden="true"></span>
					<?php echo Text::_('COM_PRODUCTION_ADD_RECORD'); ?>
				</a>
			</div>
		<?php endif; ?>
	</div>


	<div class="table-responsive">
		<table class="table table-striped" id="productionsummaryList">
			<thead>
				<tr>

					<!-- <th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_PRODUCTION_PRODUCTIONSUMMARIES_ID', 'a.id', $listDirn, $listOrder); ?>
					</th> -->

					<!-- <th>
						<?php echo HTMLHelper::_('grid.sort', 'JPUBLISHED', 'a.state', $listDirn, $listOrder); ?>
					</th> -->

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_PRODUCTION_PRODUCTIONSUMMARIES_DATE', 'a.date', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_PRODUCTION_PRODUCTIONSUMMARIES_PART', 'pc.component_name', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_PRODUCTION_PRODUCTIONSUMMARIES_MODEL', 'pm.model_name', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_PRODUCTION_PRODUCTIONSUMMARIES_TOTAL_SORT', 'a.total_sort', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_PRODUCTION_PRODUCTIONSUMMARIES_TOTAL_NC', 'a.total_nc', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_PRODUCTION_PRODUCTIONSUMMARIES_TOTAL_ACC', 'a.total_acc', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_PRODUCTION_PRODUCTIONSUMMARIES_SYNCED_AT', 'a.synced_at', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo Text::_('COM_PRODUCTION_PRODUCTIONSUMMARIES_SOURCE'); ?>
					</th>

					<?php if ($canEdit || $canDelete): ?>
						<th class="center">
							<?php echo Text::_('COM_PRODUCTION_PRODUCTIONSUMMARIES_ACTIONS'); ?>
						</th>
					<?php endif; ?>

				</tr>
			</thead>
			<tfoot>
				<tr>
					<td colspan="12">
						<div class="pagination">
							<?php echo $this->pagination->getPagesLinks(); ?>
						</div>
					</td>
				</tr>
			</tfoot>
			<tbody>
				<?php foreach ($this->items as $i => $item) : ?>
					<?php $canEdit = $user->authorise('core.edit', 'com_production'); ?>

					<tr class="row<?php echo $i % 2; ?>">

						<!-- <td>
							<?php echo $item->id; ?>
						</td>
						<td>
							<?php $class = ($canChange) ? 'active' : 'disabled'; ?>
							<a class="btn btn-micro <?php echo $class; ?>" href="<?php echo ($canChange) ? Route::_('index.php?option=com_production&task=productionsummary.publish&id=' . $item->id . '&state=' . (($item->state + 1) % 2) . '&' . Session::getFormToken() . '=1', false, 2) : '#'; ?>">
								<?php if ($item->state == 1): ?>
									<i class="icon-publish"></i>
								<?php else: ?>
									<i class="icon-unpublish"></i>
								<?php endif; ?>
							</a>
						</td> -->
						<td>
							<?php echo $item->date; ?>
						</td>
						<td>
							<?php $canCheckin = Factory::getApplication()->getIdentity()->authorise('core.manage', 'com_production.' . $item->id) || $item->checked_out == Factory::getApplication()->getIdentity()->id; ?>
							<?php if ($canCheckin && $item->checked_out > 0) : ?>
								<a href="<?php echo Route::_('index.php?option=com_production&task=productionsummary.checkin&id=' . $item->id . '&' . Session::getFormToken() . '=1'); ?>">
									<?php echo HTMLHelper::_('jgrid.checkedout', $i, $item->uEditor, $item->checked_out_time, 'productionsummary.', false); ?></a>
							<?php endif; ?>
							<a href="<?php echo Route::_('index.php?option=com_production&view=productionsummary&id=' . (int) $item->id); ?>">
								<?php echo $this->escape($item->part_name ?? $item->part); ?></a>
						</td>
						<td>
							<?php echo $this->escape($item->model_name ?? $item->model); ?>
						</td>
						<td>
							<?php echo $item->total_sort; ?>
						</td>
						<td>
							<?php echo $item->total_nc; ?>
						</td>
						<td>
							<?php echo (int) $item->total_acc; ?>
						</td>
						<td>
							<?php echo $item->synced_at; ?>
						</td>
						<td>
							<?php echo Text::_(($item->source ?? 'sync') === 'manual' ? 'COM_PRODUCTION_SOURCE_MANUAL' : 'COM_PRODUCTION_SOURCE_SYNC'); ?>
						</td>
						<?php if ($canEdit || $canDelete): ?>
							<td class="center text-nowrap">
								<?php if ($canEdit) : ?>
									<a class="btn btn-mini" type="button" href="<?php echo Route::_('index.php?option=com_production&task=productionsummaryform.edit&id=' . (int) $item->id); ?>">
										<i class="icon-edit"></i>
									</a>
								<?php endif; ?>
								<?php if ($canDelete) : ?>
									<a class="btn btn-mini delete-button" type="button" href="<?php echo Route::_('index.php?option=com_production&task=productionsummary.remove&id=' . (int) $item->id . '&' . Session::getFormToken() . '=1'); ?>">
										<i class="icon-trash"></i>
									</a>
								<?php endif; ?>
							</td>
						<?php endif; ?>

					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="filter_order" value="" />
	<input type="hidden" name="filter_order_Dir" value="" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>

<?php
if ($canDelete) {
	$wa->addInlineScript("
			jQuery(document).ready(function () {
				jQuery('.delete-button').click(deleteItem);
			});

			function deleteItem() {

				if (!confirm(\"" . Text::_('COM_PRODUCTION_DELETE_MESSAGE') . "\")) {
					return false;
				}
			}
		", [], [], ["jquery"]);
}
?>