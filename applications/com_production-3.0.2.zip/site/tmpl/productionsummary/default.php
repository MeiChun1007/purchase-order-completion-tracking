<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Production
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 QC YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Session\Session;
use Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Layout\LayoutHelper;


?>

<div class="item_fields">
<?php if ($this->params->get('show_page_heading')) : ?>
    <div class="page-header">
        <h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
    </div>
    <?php endif;?>
	<table class="table">
		

		<tr>
			<th><?php echo Text::_('COM_PRODUCTION_FORM_LBL_PRODUCTIONSUMMARY_DATE'); ?></th>
			<td><?php echo $this->item->date; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_PRODUCTION_FORM_LBL_PRODUCTIONSUMMARY_MODEL_ID'); ?></th>
			<td><?php echo $this->item->model_id; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_PRODUCTION_FORM_LBL_PRODUCTIONSUMMARY_MODEL'); ?></th>
			<td><?php echo $this->item->model; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_PRODUCTION_FORM_LBL_PRODUCTIONSUMMARY_TOTAL_SORT'); ?></th>
			<td><?php echo $this->item->total_sort; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_PRODUCTION_FORM_LBL_PRODUCTIONSUMMARY_TOTAL_NC'); ?></th>
			<td><?php echo $this->item->total_nc; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_PRODUCTION_FORM_LBL_PRODUCTIONSUMMARY_SYNCED_AT'); ?></th>
			<td><?php echo $this->item->synced_at; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_PRODUCTION_FORM_LBL_PRODUCTIONSUMMARY_PART'); ?></th>
			<td><?php echo $this->item->part; ?></td>
		</tr>

	</table>

</div>

