<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

$wa = $this->document->getWebAssetManager();

$cssFile = JPATH_ROOT . '/media/com_production/css/list.css';
$wa->registerAndUseStyle(
	'com_production.list',
	Uri::root() . 'media/com_production/css/list.css',
	['version' => (string) @filemtime($cssFile)]
);

$jsFile = JPATH_ROOT . '/media/com_production/js/list.js';
if (is_file($jsFile)) $wa->registerAndUseScript(
	'com_production.list',
	Uri::root() . 'media/com_production/js/list.js',
	['version' => (string) @filemtime($jsFile)],
	['defer' => true],
	['choicesjs']
);

$filters = $this->filters;
$pivot   = is_array($this->pivot ?? null) ? $this->pivot : [];
$columns = $pivot['columns'] ?? [];
$parts   = $pivot['parts'] ?? [];

/** Renders one filter <select> (options are objects with ->value and ->text) */
$select = function (string $name, string $labelKey, string $allKey, array $options, string $extraClass = '') use ($filters) {
	$current = (string) ($filters->$name ?? '');
?>
	<label for="filter_<?php echo $name; ?>"><?php echo Text::_($labelKey); ?></label>
	<select name="filter_<?php echo $name; ?>" id="filter_<?php echo $name; ?>" class="form-select <?php echo $extraClass; ?>" onchange="this.form.submit();">
		<option value=""><?php echo Text::_($allKey); ?></option>
		<?php foreach ($options as $o) : ?>
			<option value="<?php echo htmlspecialchars((string) $o->value, ENT_QUOTES); ?>" <?php echo $current === (string) $o->value ? 'selected="selected"' : ''; ?>>
				<?php echo htmlspecialchars((string) $o->text, ENT_QUOTES); ?>
			</option>
		<?php endforeach; ?>
	</select>
<?php
};
?>

<!-- <form action="<?php echo htmlspecialchars(Uri::getInstance()->toString()); ?>" method="post" name="adminForm" id="adminForm"> -->
<form action="<?php echo Route::_('index.php?option=com_production&view=productionreport'); ?>" method="post" name="adminForm" id="adminForm">

	<div class="header mb-4">
		<h1 class="header__title"><?php echo Text::_('COM_PRODUCTION_TITLE'); ?></h1>
		<p class="header__subtitle"><?php echo Text::_('COM_PRODUCTION_SUBTITLE'); ?></p>
		<p class="text-muted mb-2 last-sync">
			<?php echo Text::_('COM_PRODUCTION_SYNC_LAST'); ?>:
			<strong>
				<?php echo !empty($this->lastSync)
					? HTMLHelper::_('date', $this->lastSync, Text::_('DATE_FORMAT_LC5'))
					: Text::_('COM_PRODUCTION_SYNC_NEVER'); ?>
			</strong>
		</p>
	</div>

	<div class="selectors row">
		<div class="selector col-md-4">
			<label><?php echo Text::_('COM_PRODUCTION_PERIOD_TYPE'); ?></label>
			<div class="btn-group d-block" role="group">
				<input type="radio" class="btn-check" name="filter_period_type" id="period_year" value="year"
					<?php echo $filters->period_type === 'year' ? 'checked' : ''; ?> onchange="this.form.submit();">
				<label class="btn btn-period" for="period_year"><?php echo Text::_('COM_PRODUCTION_YEAR'); ?></label>

				<input type="radio" class="btn-check" name="filter_period_type" id="period_month" value="month"
					<?php echo $filters->period_type === 'month' ? 'checked' : ''; ?> onchange="this.form.submit();">
				<label class="btn btn-period" for="period_month"><?php echo Text::_('COM_PRODUCTION_MONTH'); ?></label>

				<input type="radio" class="btn-check" name="filter_period_type" id="period_week" value="week"
					<?php echo $filters->period_type === 'week' ? 'checked' : ''; ?> onchange="this.form.submit();">
				<label class="btn btn-period" for="period_week"><?php echo Text::_('COM_PRODUCTION_WEEK'); ?></label>

				<input type="radio" class="btn-check" name="filter_period_type" id="period_date" value="custom"
					<?php echo $filters->period_type === 'custom' ? 'checked' : ''; ?> onchange="this.form.submit();">
				<label class="btn btn-period" for="period_date"><?php echo Text::_('COM_PRODUCTION_DATE'); ?></label>
			</div>
		</div>

		<div class="selector col-md-4" style="display: grid; align-content: center;">
			<?php if (in_array($filters->period_type, ['week', 'month', 'year'], true)) : ?>
				<label for="filter_year"><?php echo Text::_('COM_PRODUCTION_YEAR_SELECTOR'); ?></label>
				<select name="filter_year" id="filter_year" class="form-select" onchange="this.form.submit();">
					<?php foreach ($this->yearOptions as $yearOption) : ?>
						<option value="<?php echo (int) $yearOption; ?>" <?php echo (int) $filters->year === (int) $yearOption ? 'selected="selected"' : ''; ?>>
							<?php echo (int) $yearOption; ?>
						</option>
					<?php endforeach; ?>
				</select>
			<?php endif; ?>

			<?php if ($filters->period_type === 'week') : ?>
				<div style="padding-top:10px;">
					<label for="filter_week"><?php echo Text::_('COM_PRODUCTION_WEEK_SELECTOR'); ?></label>
					<select name="filter_week" id="filter_week" class="form-select" onchange="this.form.submit();">
						<?php foreach ($this->weekOptions as $weekOption) : ?>
							<option value="<?php echo (int) $weekOption->value; ?>"
								<?php echo (int) $filters->week === (int) $weekOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo Text::sprintf('COM_PRODUCTION_WEEK_N', $weekOption->value, $weekOption->label); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>

			<?php elseif ($filters->period_type === 'month') : ?>
				<div style="padding-top:10px;">
					<label for="filter_month"><?php echo Text::_('COM_PRODUCTION_MONTH_SELECTOR'); ?></label>
					<select name="filter_month" id="filter_month" class="form-select" onchange="this.form.submit();">
						<?php foreach ($this->monthOptions as $monthOption) : ?>
							<option value="<?php echo (int) $monthOption->value; ?>"
								<?php echo (int) $filters->month === (int) $monthOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($monthOption->label); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>

			<?php elseif ($filters->period_type === 'custom') : ?>
				<div style="padding-top:10px;">
					<label for="filter_date_from"><?php echo Text::_('COM_PRODUCTION_DATE_FROM'); ?></label>
					<input type="date" name="filter_date_from" id="filter_date_from" class="form-control"
						value="<?php echo $this->escape($filters->date_from); ?>" onchange="this.form.submit();" />
				</div>
				<div style="padding-top:10px;">
					<label for="filter_date_to"><?php echo Text::_('COM_PRODUCTION_DATE_TO'); ?></label>
					<input type="date" name="filter_date_to" id="filter_date_to" class="form-control"
						value="<?php echo $this->escape($filters->date_to); ?>" onchange="this.form.submit();" />
				</div>
			<?php endif; ?>
		</div>
	</div>

	<!-- All Dashboard Filters -->
	<div id="dashboard-filters">
		<div class="selectors row">
			<div class="selector col-md-3">
				<?php $select('part', 'COM_PRODUCTION_PART_SELECTOR', 'COM_PRODUCTION_ALL_PARTS', $this->partOptions, 'js-choices'); ?>
			</div>

			<div class="selector col-md-3">
				<?php $select('model', 'COM_PRODUCTION_MODEL_SELECTOR', 'COM_PRODUCTION_ALL_MODELS', $this->modelOptions, 'js-choices'); ?>
			</div>
		</div>

		<div class="row mb-4">
			<div class="col-md-12 text-end">
				<button type="button" id="btn-clear-filters" class="btn btn-link btn-sm text-muted">
					<span class="icon-undo" aria-hidden="true"></span>
					<?php echo Text::_('COM_PRODUCTION_CLEAR_FILTERS'); ?>
				</button>
			</div>
		</div>
	</div>

	<div class="filter-toggle-row">
		<div class="filter-toggle-title text-muted">
			<span id="filter-toggle-text">Less Filters</span>
		</div>
		<button type="button" id="btn-toggle-filters" class="filter-toggle-btn"
			aria-expanded="true" aria-controls="dashboard-filters">
			<span id="filter-toggle-icon" class="icon-chevron-up" aria-hidden="true"></span>
		</button>
	</div>

	<!-- Pivot table -->
	<div class="table-responsive pivot-scroll mt-4">
		<table class="table table-bordered pivot-table align-middle" id="productionList">
			<thead>
				<tr>
					<th rowspan="2" class="col-part"><?php echo Text::_('COM_PRODUCTION_PARTS'); ?></th>
					<th rowspan="2" class="col-model"><?php echo Text::_('COM_PRODUCTION_MODELS'); ?></th>
					<th rowspan="2"><?php echo Text::_('COM_PRODUCTION_TOTAL_SORT'); ?></th>
					<th rowspan="2"><?php echo Text::_('COM_PRODUCTION_TOTAL_NC'); ?></th>
					<th rowspan="2"><?php echo Text::_('COM_PRODUCTION_TOTAL_ACC'); ?></th>
					<th colspan="3" class="text-center"><?php echo Text::_('COM_PRODUCTION_CARRIED_OVER'); ?></th>
					<?php foreach ($columns as $label) : ?>
						<th colspan="2" class="text-center"><?php echo $this->escape($label); ?></th>
					<?php endforeach; ?>
				</tr>
				<tr>
					<th><?php echo Text::_('COM_PRODUCTION_SORT'); ?></th>
					<th><?php echo Text::_('COM_PRODUCTION_NC'); ?></th>
					<th><?php echo Text::_('COM_PRODUCTION_ACC'); ?></th>
					<?php foreach ($columns as $label) : ?>
						<th><?php echo Text::_('COM_PRODUCTION_SORT'); ?></th>
						<th><?php echo Text::_('COM_PRODUCTION_NC'); ?></th>
					<?php endforeach; ?>
				</tr>
			</thead>
			<tbody>
				<?php
				$colorIndex = -1;
				$palette    = ['part-bg-0', 'part-bg-1', 'part-bg-2', 'part-bg-3', 'part-bg-4', 'part-bg-5', 'part-bg-6', 'part-bg-7'];
				?>
				<?php if (!$parts) : ?>
					<tr>
						<td colspan="<?php echo 8 + count($columns) * 2; ?>" class="text-center text-muted"><?php echo Text::_('COM_PRODUCTION_EMPTY'); ?></td>
					</tr>
				<?php endif; ?>

				<?php foreach ($parts as $part => $models) :
					$first      = true;
					$colorIndex++;
					$partClass  = $palette[$colorIndex % count($palette)]; ?>
					<?php foreach ($models as $model => $row) : ?>
						<tr class="<?php echo $partClass; ?>">
							<?php if ($first) : ?>
								<td rowspan="<?php echo count($models); ?>" class="part-cell col-part fw-bold"><?php echo $this->escape($part); ?></td>
								<?php $first = false; ?>
							<?php endif; ?>
							<td class="col-model"><?php echo $this->escape($model); ?></td>
							<td class="text-center fw-bold"><?php echo number_format($row['total']); ?></td>
							<td class="text-center fw-bold <?php echo $row['total_nc'] > 0 ? 'text-danger' : '';
															echo $row['total_nc'] === 0 ? ' value-zero' : ''; ?>">
								<?php echo number_format($row['total_nc']); ?>
							</td>
							<td class="text-center fw-bold"><?php echo number_format($row['total_acc']); ?></td>

							<td class="text-center<?php echo $row['carried_sort'] === 0 ? ' value-zero' : ''; ?>"><?php echo number_format($row['carried_sort']); ?></td>
							<td class="text-center<?php echo $row['carried_nc'] === 0 ? ' value-zero' : ' text-danger'; ?>"><?php echo number_format($row['carried_nc']); ?></td>
							<td class="text-center<?php echo $row['carried_acc'] === 0 ? ' value-zero' : ''; ?>"><?php echo number_format($row['carried_acc']); ?></td>

							<?php foreach (array_keys($columns) as $key) :
								$cell    = $row['cells'][$key] ?? null;
								$sortQty = (int) ($cell['sort'] ?? 0);
								$ncQty   = (int) ($cell['nc'] ?? 0); ?>

								<td class="text-center<?php echo $sortQty === 0 ? ' value-zero' : ''; ?>">
									<?php echo number_format($sortQty); ?>
								</td>
								<td class="text-center<?php echo $ncQty === 0 ? ' value-zero' : ' text-danger'; ?>">
									<?php echo number_format($ncQty); ?>
								</td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<input type="hidden" name="task" value="" />
	<input type="hidden" name="clearfilters" id="clearfilters" value="0" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>