<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Production
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 QC YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Production\Component\Production\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Utilities\ArrayHelper;
use Production\Component\Production\Administrator\Helper\SyncHelper;

/**
 * Productionsummaries list controller class.
 *
 * @since  1.0.0
 */
class ProductionsummariesController extends AdminController
{
	/**
	 * Method to clone existing Productionsummaries
	 *
	 * @return  void
	 *
	 * @throws  \Exception
	 */
	public function duplicate()
	{
		// Check for request forgeries
		$this->checkToken();

		// Get id(s)
		$pks = $this->input->post->get('cid', array(), 'array');

		try {
			if (empty($pks)) {
				throw new \Exception(Text::_('COM_PRODUCTION_NO_ELEMENT_SELECTED'));
			}

			ArrayHelper::toInteger($pks);
			$model = $this->getModel();
			$model->duplicate($pks);
			$this->setMessage(Text::_('COM_PRODUCTION_ITEMS_SUCCESS_DUPLICATED'));
		} catch (\Exception $e) {
			Factory::getApplication()->enqueueMessage($e->getMessage(), 'warning');
		}

		$this->setRedirect('index.php?option=com_production&view=productionsummaries');
	}

	/**
	 * Toolbar button "Sync All": fetch every record from the Data site.
	 *
	 * @return  void
	 */
	public function syncAll()
	{
		$this->checkToken();
		$this->runSync(SyncHelper::MODE_ALL, '');
	}

	/**
	 * Toolbar button "Specified Sync": fetch from the date chosen in the popup.
	 *
	 * @return  void
	 */
	public function syncDate()
	{
		$this->checkToken();
		$this->runSync(SyncHelper::MODE_DATE, $this->input->post->getString('sync_date_from', ''));
	}

	/**
	 * Shared by both sync buttons.
	 */
	protected function runSync(string $mode, string $dateFrom): void
	{
		$app  = Factory::getApplication();
		$user = $app->getIdentity();

		$this->setRedirect(Route::_('index.php?option=com_production&view=productionsummaries', false));

		if (!$user->authorise('core.create', 'com_production') || !$user->authorise('core.edit', 'com_production')) {
			$app->enqueueMessage(Text::_('JERROR_ALERTNOAUTHOR'), 'error');

			return;
		}

		try {
			$r = SyncHelper::run($mode, $dateFrom);

			$where = $r['from'] === null
				? Text::_('COM_PRODUCTION_SYNC_RANGE_ALL')
				: Text::sprintf('COM_PRODUCTION_SYNC_RANGE_FROM', $r['from']);

			$app->enqueueMessage(
				Text::sprintf('COM_PRODUCTION_SYNC_DONE', $where, $r['inserted'], $r['updated']),
				'message'
			);
		} catch (\Throwable $e) {
			$app->enqueueMessage(Text::_('COM_PRODUCTION_SYNC_FAILED') . ' ' . $e->getMessage(), 'error');
		}
	}

	/**
	 * Proxy for getModel.
	 *
	 * @param   string  $name    Optional. Model name
	 * @param   string  $prefix  Optional. Class prefix
	 * @param   array   $config  Optional. Configuration array for model
	 *
	 * @return  object	The Model
	 *
	 * @since   1.0.0
	 */
	public function getModel($name = 'Productionsummary', $prefix = 'Administrator', $config = array())
	{
		return parent::getModel($name, $prefix, array('ignore_request' => true));
	}

	public function getModelsByComponent()
	{
		// Safety check to ensure it's a JSON call
		$this->input->set('format', 'json');

		$componentId = $this->input->getInt('component_id', 0);
		$db = Factory::getDbo();

		$query = $db->getQuery(true)
			->select($db->quoteName('id', 'key'))
			->select($db->quoteName('model_name', 'value')) // Change to your actual column name
			->from($db->quoteName('#__product_catalogs'))     // Change to your actual table name
			->where($db->quoteName('component') . ' = ' . (int) $componentId)
			->where($db->quoteName('state') . ' = 1')
			->order($db->quoteName('model_name') . ' ASC');

		$db->setQuery($query);
		$results = $db->loadObjectList();

		// Output clean JSON back to JavaScript
		echo json_encode([
			'success' => true,
			'data'    => $results
		]);

		Factory::getApplication()->close();
	}



	/**
	 * Method to save the submitted ordering values for records via AJAX.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 *
	 * @throws  \Exception
	 */
	public function saveOrderAjax()
	{
		// Get the input
		$pks   = $this->input->post->get('cid', array(), 'array');
		$order = $this->input->post->get('order', array(), 'array');

		// Sanitize the input
		ArrayHelper::toInteger($pks);
		ArrayHelper::toInteger($order);

		// Get the model
		$model = $this->getModel();

		// Save the ordering
		$return = $model->saveorder($pks, $order);

		if ($return) {
			echo "1";
		}

		// Close the application
		Factory::getApplication()->close();
	}
}
