<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Production
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 QC YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Production\Component\Production\Administrator\Table;
// No direct access
defined('_JEXEC') or die;

use \Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Access\Access;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Table\Table as Table;
use \Joomla\CMS\Versioning\VersionableTableInterface;
use Joomla\CMS\Tag\TaggableTableInterface;
use Joomla\CMS\Tag\TaggableTableTrait;
use \Joomla\Database\DatabaseDriver;
use \Joomla\Database\ParameterType;
use \Joomla\CMS\Filter\OutputFilter;
use \Joomla\Registry\Registry;
use \Production\Component\Production\Administrator\Helper\ProductionHelper;
use \Joomla\CMS\Helper\ContentHelper;
use \Joomla\CMS\User\CurrentUserInterface;
use \Joomla\CMS\User\CurrentUserTrait;


/**
 * Productionsummary table
 *
 * @since 1.0.0
 */
class ProductionsummaryTable extends Table implements VersionableTableInterface, TaggableTableInterface, CurrentUserInterface
{
	use TaggableTableTrait;
	use CurrentUserTrait;

	/**
	 * Indicates that columns fully support the NULL value in the database
	 *
	 * @var    boolean
	 * @since  4.0.0
	 */
	protected $_supportNullValue = true;


	/**
	 * Constructor
	 *
	 * @param   DatabaseDriver  $db  A database connector object
	 */
	public function __construct(DatabaseDriver $db)
	{
		$this->typeAlias = 'com_production.productionsummary';
		parent::__construct('#__production_summary', 'id', $db);
		$this->setColumnAlias('published', 'state');
	}

	/**
	 * Get the type alias for the history table
	 *
	 * @return  string  The alias as described above
	 *
	 * @since   1.0.0
	 */
	public function getTypeAlias()
	{
		return $this->typeAlias;
	}

	/**
	 * Overloaded bind function to pre-process the params.
	 *
	 * @param   array  $array   Named array
	 * @param   mixed  $ignore  Optional array or list of parameters to ignore
	 *
	 * @return  boolean  True on success.
	 *
	 * @see     Table:bind
	 * @since   1.0.0
	 * @throws  \InvalidArgumentException
	 */
	public function bind($array, $ignore = '')
	{
		$date = Factory::getDate();
		$task = Factory::getApplication()->input->get('task');
		$user = Factory::getApplication()->getIdentity();

		$input = Factory::getApplication()->input;
		$task = $input->getString('task', '');

		if ($array['id'] == 0 && empty($array['created_by'])) {
			$array['created_by'] = $this->getCurrentUser()->id;
		}

		if ($array['id'] == 0 && empty($array['modified_by'])) {
			$array['modified_by'] = $this->getCurrentUser()->id;
		}

		if ($task == 'apply' || $task == 'save') {
			$array['modified_by'] = $this->getCurrentUser()->id;
		}

		if (isset($array['params']) && is_array($array['params'])) {
			$registry = new Registry;
			$registry->loadArray($array['params']);
			$array['params'] = (string) $registry;
		}

		if (isset($array['metadata']) && is_array($array['metadata'])) {
			$registry = new Registry;
			$registry->loadArray($array['metadata']);
			$array['metadata'] = (string) $registry;
		}

		if (!$user->authorise('core.admin', 'com_production.productionsummary.' . $array['id'])) {
			$actions         = Access::getActionsFromFile(
				JPATH_ADMINISTRATOR . '/components/com_production/access.xml',
				"/access/section[@name='productionsummary']/"
			);
			$default_actions = Access::getAssetRules('com_production.productionsummary.' . $array['id'])->getData();
			$array_jaccess   = array();

			foreach ($actions as $action) {
				if (key_exists($action->name, $default_actions)) {
					$array_jaccess[$action->name] = $default_actions[$action->name];
				}
			}

			$array['rules'] = $this->JAccessRulestoArray($array_jaccess);
		}

		// Bind the rules for ACL where supported.
		if (isset($array['rules']) && is_array($array['rules'])) {
			$this->setRules($array['rules']);
		}

		return parent::bind($array, $ignore);
	}

	/**
	 * Method to store a row in the database from the Table instance properties.
	 *
	 * If a primary key value is set the row with that primary key value will be updated with the instance property values.
	 * If no primary key value is set a new row will be inserted into the database with the properties from the Table instance.
	 *
	 * @param   boolean  $updateNulls  True to update fields even if they are null.
	 *
	 * @return  boolean  True on success.
	 *
	 * @since   1.0.0
	 */
	public function store($updateNulls = true)
	{

		if (!($this->id)) {
			if (empty($this->date)) {
				$this->date = NULL;
			}
		} else {
			if (empty($this->date)) {
				$this->date = NULL;
			}
		}

		return parent::store($updateNulls);
	}

	/**
	 * This function convert an array of Access objects into an rules array.
	 *
	 * @param   array  $jaccessrules  An array of Access objects.
	 *
	 * @return  array
	 */
	private function JAccessRulestoArray($jaccessrules)
	{
		$rules = array();

		foreach ($jaccessrules as $action => $jaccess) {
			$actions = array();

			if ($jaccess) {
				foreach ($jaccess->getData() as $group => $allow) {
					$actions[$group] = ((bool)$allow);
				}
			}

			$rules[$action] = $actions;
		}

		return $rules;
	}

	/**
	 * Overloaded check function
	 *
	 * @return bool
	 */
	public function check()
	{
		// If there is an ordering column and this is a new row then get the next ordering value
		if (property_exists($this, 'ordering') && $this->id == 0) {
			$this->ordering = self::getNextOrder();
		}



		// ---- com_production: part / model come from #__product_catalogs ----
		$this->date = substr(trim((string) $this->date), 0, 10);

		if ($this->date === '') {
			$this->setError(Text::_('COM_PRODUCTION_ERROR_DATE_REQUIRED'));

			return false;
		}

		$db      = $this->_db;
		$modelId = (int) $this->model;

		if ($modelId <= 0) {
			$this->setError(Text::_('COM_PRODUCTION_ERROR_MODEL_REQUIRED'));

			return false;
		}

		$query = $db->getQuery(true)
			->select($db->quoteName(['id', 'component']))
			->from($db->quoteName('#__product_catalogs'))
			->where($db->quoteName('id') . ' = :mid')
			->bind(':mid', $modelId, ParameterType::INTEGER);

		$catalog = $db->setQuery($query)->loadObject();

		if (!$catalog) {
			$this->setError(Text::_('COM_PRODUCTION_ERROR_MODEL_NOT_FOUND'));

			return false;
		}

		// model = catalog id, part = component id of that catalog row (first one if comma separated)
		$this->model    = (int) $catalog->id;
		$this->model_id = (int) $catalog->id;
		$components = array_map('intval', explode(',', (string) $catalog->component));
		$this->part = in_array((int) $this->part, $components, true)
			? (int) $this->part
			: (int) ($components[0] ?? 0);

		if (empty($this->source)) {
			$this->source = $this->id ? 'sync' : 'manual';
		}

		// One row per date + model (this is also the key the sync matches on)
		$selfId = (int) $this->id;
		$date   = $this->date;
		$mid    = (int) $this->model_id;

		$query = $db->getQuery(true)
			->select($db->quoteName('id'))
			->from($db->quoteName('#__production_summary'))
			->where($db->quoteName('date') . ' = :d')
			->where($db->quoteName('model_id') . ' = :m')
			->where($db->quoteName('state') . ' != -2')
			->where($db->quoteName('id') . ' != :self')
			->bind(':d', $date)
			->bind(':m', $mid, ParameterType::INTEGER)
			->bind(':self', $selfId, ParameterType::INTEGER);

		$dupId = (int) $db->setQuery($query, 0, 1)->loadResult();

		if ($dupId) {
			$this->setError(Text::sprintf('COM_PRODUCTION_ERROR_DUPLICATE', $dupId));

			return false;
		}

		return parent::check();
	}

	/**
	 * Define a namespaced asset name for inclusion in the #__assets table
	 *
	 * @return string The asset name
	 *
	 * @see Table::_getAssetName
	 */
	protected function _getAssetName()
	{
		$k = $this->_tbl_key;

		return $this->typeAlias . '.' . (int) $this->$k;
	}

	/**
	 * Returns the parent asset's id. If you have a tree structure, retrieve the parent's id using the external key field
	 *
	 * @param   Table   $table  Table name
	 * @param   integer  $id     Id
	 *
	 * @see Table::_getAssetParentId
	 *
	 * @return mixed The id on success, false on failure.
	 */
	protected function _getAssetParentId($table = null, $id = null)
	{
		// We will retrieve the parent-asset from the Asset-table
		$assetParent = Table::getInstance('Asset');

		// Default: if no asset-parent can be found we take the global asset
		$assetParentId = $assetParent->getRootId();

		// The item has the component as asset-parent
		$assetParent->loadByName('com_production');

		// Return the found asset-parent-id
		if ($assetParent->id) {
			$assetParentId = $assetParent->id;
		}

		return $assetParentId;
	}

	//XXX_CUSTOM_TABLE_FUNCTION


	/**
	 * Delete a record by id
	 *
	 * @param   mixed  $pk  Primary key value to delete. Optional
	 *
	 * @return bool
	 */
	public function delete($pk = null)
	{
		$this->load($pk);
		$result = parent::delete($pk);

		return $result;
	}
}
