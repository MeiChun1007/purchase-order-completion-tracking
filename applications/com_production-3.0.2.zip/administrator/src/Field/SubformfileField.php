<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Production
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 QC YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Production\Component\Production\Administrator\Field;

defined('JPATH_BASE') or die;

use \Joomla\CMS\Form\Field\FileField;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Uri\Uri;

/**
 * Supports a file field nested inside a subform row.
 *
 * Joomla's core FileField deliberately renders no value (a file input can't be
 * pre-filled by the browser), so a nested file field always looked empty even
 * after a file was uploaded and saved. This subclass appends a "currently
 * uploaded" link below the input using the field's own bound value, which is
 * already scoped to this row by Joomla's SubformField.
 *
 * @since  1.0.0
 */
#[\AllowDynamicProperties]
class SubformfileField extends FileField
{
	/**
	 * The form field type.
	 *
	 * @var    string
	 * @since  1.0.0
	 */
	protected $type = 'subformfile';

	/**
	 * Method to get the field input markup for the file field, plus a link to
	 * any already-uploaded file(s) for this row.
	 *
	 * @return  string  The field input markup.
	 *
	 * @since   1.0.0
	 */
	protected function getInput()
	{
		$html = parent::getInput();

		if (empty($this->value))
		{
			return $html;
		}

		$uploadDir = (string) $this->element['upload_directory'];

		if ($uploadDir === '')
		{
			$uploadDir = 'uploads';
		}

		$links = array();

		foreach ((array) explode(',', $this->value) as $file)
		{
			$file = trim($file);

			if ($file === '')
			{
				continue;
			}

			$links[] = '<a href="' . Route::_(Uri::root() . $uploadDir . '/' . $file, false) . '" target="_blank">' . htmlspecialchars($file) . '</a>';
		}

		if (empty($links))
		{
			return $html;
		}

		return '<div class="subform-file-current">Currently uploaded: ' . implode(', ', $links) . '</div>' . $html;
	}
}
