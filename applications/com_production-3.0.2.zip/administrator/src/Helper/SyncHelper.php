<?php

/**
 * @package    Com_Production
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Production\Component\Production\Administrator\Helper;

\defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Http\HttpFactory;
use Joomla\Database\DatabaseInterface;

/**
 * Pulls the daily Total Sort / Total NC per model from the Data site's API
 * into #__production_summary.
 *
 * Used by the toolbar buttons on the list screen and by the scheduled task (plg_task_datasync).
 */
class SyncHelper
{
	public const MODE_AUTO = 'auto';
	public const MODE_ALL  = 'all';
	public const MODE_DATE = 'date';

	/**
	 * Newest synced_at in the table (UTC string) or null if never synced.
	 */
	public static function lastSync(): ?string
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$value = $db->setQuery(
			$db->getQuery(true)
				->select('MAX(' . $db->quoteName('synced_at') . ')')
				->from($db->quoteName('#__production_summary'))
		)->loadResult();

		return $value ?: null;
	}

	/**
	 * Daily summary sync.
	 *
	 * @param   string  $mode      auto | all | date
	 * @param   string  $dateFrom  YYYY-MM-DD, only used when $mode === 'date'
	 *
	 * @return  array   ['mode' => , 'from' => string|null, 'inserted' => int, 'updated' => int]
	 *
	 * @throws  \RuntimeException
	 */
	public static function run(string $mode = self::MODE_AUTO, string $dateFrom = ''): array
	{
		@set_time_limit(300);

		$cfg = self::settings();

		if ($cfg['endpoint'] === '' || $cfg['token'] === '') {
			throw new \RuntimeException('Sync endpoint or token is not configured (Production > Options > Data Sync).');
		}

		// The summary points at parts/models (ids in com_product's tables), so make sure they exist
		// on this site BEFORE inserting - otherwise part/model would be saved as 0 until the next run.
		// Skipped when com_product's Data Sync settings are not filled in.
		if (
			class_exists(\Product\Component\Product\Administrator\Helper\SyncHelper::class)
			&& \Product\Component\Product\Administrator\Helper\SyncHelper::isConfigured()
		) {
			\Product\Component\Product\Administrator\Helper\SyncHelper::run();
		}

		$db   = Factory::getContainer()->get(DatabaseInterface::class);
		$from = null;

		if ($mode === self::MODE_DATE) {
			$dateFrom = substr(trim($dateFrom), 0, 10);

			if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) {
				throw new \RuntimeException('Please enter a valid "Date from" (YYYY-MM-DD).');
			}

			$from = $dateFrom;
		} elseif ($mode !== self::MODE_ALL) {
			$mode = self::MODE_AUTO;
			$last = self::lastSync();

			if ($last !== null) {
				// synced_at is UTC; the Data site's dates are Kuala Lumpur local time.
				$dt = new \DateTime($last, new \DateTimeZone('UTC'));
				$dt->setTimezone(new \DateTimeZone('Asia/Kuala_Lumpur'));

				if ($cfg['overlap'] > 0) {
					$dt->modify('-' . $cfg['overlap'] . ' days'); // safety margin for late edits
				}

				$from = $dt->format('Y-m-d');
			}
		}
		// mode "all": $from stays null -> no filter -> everything.

		$url = $cfg['endpoint'];

		if ($from !== null) {
			$url .= (strpos($url, '?') === false ? '?' : '&') . http_build_query(['filter' => ['date_from' => $from]]);
		}

		$json = self::fetch($url, $cfg['token']);

		if (!isset($json['data']) || !is_array($json['data'])) {
			throw new \RuntimeException('Unexpected response from the Data site API.');
		}

		[$inserted, $updated] = self::upsertSummary($db, $json['data'], $from);

		return ['mode' => $mode, 'from' => $from, 'inserted' => $inserted, 'updated' => $updated];
	}

	private static function settings(): array
	{
		$params = ComponentHelper::getParams('com_production');

		return [
			'endpoint'         => trim((string) $params->get('sync_endpoint', '')),
			'token'            => trim((string) $params->get('sync_token', '')),
			'overlap'          => max(0, (int) $params->get('sync_overlap_days', 1)),
		];
	}

	private static function fetch(string $url, string $token): array
	{
		try {
			$response = HttpFactory::getHttp()->get($url, ['X-Joomla-Token' => $token, 'Accept' => 'application/vnd.api+json'], 120);
		} catch (\Throwable $e) {
			throw new \RuntimeException('Request to the Data site failed: ' . $e->getMessage());
		}

		if ((int) $response->code !== 200) {
			$snippet = mb_substr(trim(preg_replace('/\s+/', ' ', strip_tags((string) $response->body))), 0, 200);

			throw new \RuntimeException(
				'The Data site API returned HTTP ' . $response->code . ($snippet !== '' ? ': ' . $snippet : '') . ' (' . $url . ')'
			);
		}

		$json = json_decode((string) $response->body, true);

		if (!is_array($json)) {
			throw new \RuntimeException('The Data site API did not return valid JSON.');
		}

		return $json;
	}

	/**
	 * A summary row matches on date + model_id. Match -> UPDATE, no match -> INSERT.
	 *
	 * `model` and `part` are written the way their columns expect:
	 *   numeric column -> the id (model_id / the model's component id from #__product_catalogs)
	 *   text column    -> the name
	 */
	private static function upsertSummary(DatabaseInterface $db, array $rows, ?string $from): array
	{
		$now = Factory::getDate()->toSql();
		$q   = fn($v) => $db->quote((string) $v);

		// Which columns exist / are numeric
		$cols      = $db->getTableColumns('#__production_summary', false);
		$isNumeric = function ($col) use ($cols) {
			return isset($cols[$col]) && preg_match('/int|decimal|numeric|float|double/i', (string) $cols[$col]->Type);
		};
		$hasPart    = isset($cols['part']);
		$partIsId   = $isNumeric('part');
		$modelIsId  = $isNumeric('model');
		$hasSource  = isset($cols['source']);


		// Lookups from THIS site's product tables (ids are identical to the Data site's)
		$catalogs = [];

		foreach (
			$db->setQuery(
				$db->getQuery(true)
					->select($db->quoteName(['id', 'component', 'model_name']))
					->from($db->quoteName('#__product_catalogs'))
			)->loadObjectList() ?: [] as $c
		) {
			$catalogs[(int) $c->id] = $c;
		}

		$partNames = [];

		foreach (
			$db->setQuery(
				$db->getQuery(true)
					->select($db->quoteName(['id', 'component_name']))
					->from($db->quoteName('#__product_components'))
			)->loadObjectList() ?: [] as $c
		) {
			$partNames[(int) $c->id] = $c->component_name;
		}

		$db->transactionStart();
		try {
			$select = $db->getQuery(true)
				->select($db->quoteName($hasSource ? ['id', 'date', 'model_id', 'source'] : ['id', 'date', 'model_id']))
				->from($db->quoteName('#__production_summary'))
				->where($db->quoteName('state') . ' = 1');

			if ($from !== null) {
				$select->where($db->quoteName('date') . ' >= ' . $db->quote($from));
			}

			$existing = [];
			$manual   = [];

			foreach ($db->setQuery($select)->loadObjectList() ?: [] as $e) {
				$key = $e->date . '|' . (int) $e->model_id;

				// Rows entered by hand are left alone by the sync
				if ($hasSource && ($e->source ?? '') === 'manual') {
					$manual[$key] = true;
				}

				if (!isset($existing[$key])) {
					$existing[$key] = (int) $e->id;
				}
			}

			$inserted = 0;
			$updated  = 0;
			$skipped  = 0;

			foreach ($rows as $row) {
				$modelId = (int) $row['model_id'];
				$key     = $row['date'] . '|' . $modelId;

				if (isset($manual[$key])) {
					$skipped++;
					continue;
				}

				// Resolve part + model for this row
				$cat       = $catalogs[$modelId] ?? null;
				$partId    = $cat ? (int) strtok((string) $cat->component, ',') : 0;
				$modelName = (string) ($row['model'] ?? ($cat->model_name ?? ''));
				$partName  = (string) ($partNames[$partId] ?? '');

				// $modelValue = $modelIsId ? $modelId : $modelName;
				$modelValue = $modelIsId ? $modelId : $modelId;
				// $partValue  = $partIsId ? $partId : $partName;
				$partValue  = $partIsId ? $partId : $partId;

				$totalAcc = 0;

				if (!empty($row['total_sort'])) {
					$totalAcc = $row['total_sort'] - $row['total_nc'];
				}

				if (isset($existing[$key])) {
					$sets = [
						$db->quoteName('model') . ' = ' . $q($modelValue),
						$db->quoteName('total_sort') . ' = ' . (int) ($row['total_sort'] ?? 0),
						$db->quoteName('total_nc') . ' = ' . (int) ($row['total_nc'] ?? 0),
						$db->quoteName('total_acc') . ' = ' . (int) ($totalAcc ?? 0),
						$db->quoteName('synced_at') . ' = ' . $q($now),
					];

					if ($hasPart) {
						$sets[] = $db->quoteName('part') . ' = ' . $q($partValue);
					}

					if ($hasSource) {
						$columns[] = 'source';
						$values[] = $q('sync');
					}

					$db->setQuery(
						'UPDATE ' . $db->quoteName('#__production_summary')
							. ' SET ' . implode(', ', $sets)
							. ' WHERE ' . $db->quoteName('id') . ' = ' . (int) $existing[$key]
					)->execute();
					$updated++;
				} else {
					$columns = ['state', 'ordering', 'created_by', 'modified_by', 'date', 'model_id', 'model', 'total_sort', 'total_nc', 'total_acc', 'synced_at'];
					$values  = [1, 0, 0, 0, $q($row['date']), $modelId, $q($modelValue), (int) ($row['total_sort'] ?? 0), (int) ($row['total_nc'] ?? 0), (int) ($totalAcc ?? 0), $q($now)];

					if ($hasPart) {
						$columns[] = 'part';
						$values[]  = $q($partValue);
					}

					$db->setQuery(
						'INSERT INTO ' . $db->quoteName('#__production_summary')
							. ' (' . implode(', ', array_map(fn($c) => $db->quoteName($c), $columns)) . ')'
							. ' VALUES (' . implode(', ', $values) . ')'
					)->execute();
					$existing[$key] = (int) $db->insertid();
					$inserted++;
				}
			}

			$db->transactionCommit();
		} catch (\Throwable $e) {
			$db->transactionRollback();

			throw new \RuntimeException('Database error during sync: ' . $e->getMessage());
		}

		return [$inserted, $updated];
	}
}
