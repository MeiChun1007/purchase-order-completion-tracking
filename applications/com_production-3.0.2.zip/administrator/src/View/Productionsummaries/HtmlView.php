<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Production
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 QC YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Production\Component\Production\Administrator\View\Productionsummaries;
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use \Production\Component\Production\Administrator\Helper\ProductionHelper;
use \Production\Component\Production\Administrator\Helper\SyncHelper;
use \Joomla\CMS\Toolbar\Toolbar;
use \Joomla\CMS\Toolbar\ToolbarHelper;
use \Joomla\CMS\Language\Text;
use \Joomla\Component\Content\Administrator\Extension\ContentComponent;
use \Joomla\CMS\Form\Form;
use \Joomla\CMS\HTML\Helpers\Sidebar;
/**
 * View class for a list of Productionsummaries.
 *
 * @since  1.0.0
 */
class HtmlView extends BaseHtmlView
{
	protected $items;

	protected $pagination;

	protected $state;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return void
	 *
	 * @throws \Exception
	 */
	public function display($tpl = null)
	{
		$this->state = $this->get('State');
		$this->items = $this->get('Items');
		$this->pagination = $this->get('Pagination');
		$this->filterForm = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');
		$this->lastSync = SyncHelper::lastSync();

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new \Exception(implode("\n", $errors));
		}

		$this->addToolbar();

		$this->sidebar = Sidebar::render();
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	protected function addToolbar()
	{
		$state = $this->get('State');
		$canDo = ProductionHelper::getActions();

		ToolbarHelper::title(Text::_('COM_PRODUCTION_TITLE_PRODUCTIONSUMMARIES'), "generic");

		$toolbar = Toolbar::getInstance('toolbar');

		// Check if the form exists before showing the add/edit buttons
		$formPath = JPATH_COMPONENT_ADMINISTRATOR . '/src/View/Productionsummaries';

		if (file_exists($formPath))
		{
			if ($canDo->get('core.create'))
			{
				$toolbar->addNew('productionsummary.add');
			}
		}

		if ($canDo->get('core.edit.state'))
		{
			$dropdown = $toolbar->dropdownButton('status-group')
				->text('JTOOLBAR_CHANGE_STATUS')
				->toggleSplit(false)
				->icon('fas fa-ellipsis-h')
				->buttonClass('btn btn-action')
				->listCheck(true);

			$childBar = $dropdown->getChildToolbar();

			if (isset($this->items[0]->state))
			{
				$childBar->publish('productionsummaries.publish')->listCheck(true);
				$childBar->unpublish('productionsummaries.unpublish')->listCheck(true);
				$childBar->archive('productionsummaries.archive')->listCheck(true);
			}
			elseif (isset($this->items[0]))
			{
				// If this component does not use state then show a direct delete button as we can not trash
				$toolbar->delete('productionsummaries.delete')
				->text('JTOOLBAR_EMPTY_TRASH')
				->message('JGLOBAL_CONFIRM_DELETE')
				->listCheck(true);
			}

			$childBar->standardButton('duplicate')
				->text('JTOOLBAR_DUPLICATE')
				->icon('fas fa-copy')
				->task('productionsummaries.duplicate')
				->listCheck(true);

			if (isset($this->items[0]->checked_out))
			{
				$childBar->checkin('productionsummaries.checkin')->listCheck(true);
			}

			if (isset($this->items[0]->state))
			{
				$childBar->trash('productionsummaries.trash')->listCheck(true);
			}
		}

		

		// Sync buttons (pull data from the Data site)
		if ($canDo->get('core.create') && $canDo->get('core.edit'))
		{
			$toolbar->confirmButton('syncall')
				->text('COM_PRODUCTION_SYNC_ALL')
				->icon('icon-refresh')
				->message('COM_PRODUCTION_SYNC_CONFIRM_ALL')
				->task('productionsummaries.syncAll')
				->listCheck(false);

			$toolbar->popupButton('syncdate')
				->text('COM_PRODUCTION_SYNC_SPECIFIED')
				->icon('icon-calendar')
				->selector('syncDateModal')
				->listCheck(false);

		}

		// Show trash and delete for components that uses the state field
		if (isset($this->items[0]->state))
		{

			if ($this->state->get('filter.state') == ContentComponent::CONDITION_TRASHED && $canDo->get('core.delete'))
			{
				$toolbar->delete('productionsummaries.delete')
					->text('JTOOLBAR_EMPTY_TRASH')
					->message('JGLOBAL_CONFIRM_DELETE')
					->listCheck(true);
			}
		}

		if ($canDo->get('core.admin'))
		{
			$toolbar->preferences('com_production');
		}

		// Set sidebar action
		Sidebar::setAction('index.php?option=com_production&view=productionsummaries');
	}
	
	/**
	 * Method to order fields 
	 *
	 * @return void 
	 */
	protected function getSortFields()
	{
		return array(
			'a.`id`' => Text::_('JGRID_HEADING_ID'),
			'a.`state`' => Text::_('JSTATUS'),
			'a.`ordering`' => Text::_('JGRID_HEADING_ORDERING'),
			'a.`date`' => Text::_('COM_PRODUCTION_PRODUCTIONSUMMARIES_DATE'),
			'a.`model_id`' => Text::_('COM_PRODUCTION_PRODUCTIONSUMMARIES_MODEL_ID'),
			'a.`model`' => Text::_('COM_PRODUCTION_PRODUCTIONSUMMARIES_MODEL'),
			'a.`total_sort`' => Text::_('COM_PRODUCTION_PRODUCTIONSUMMARIES_TOTAL_SORT'),
			'a.`total_nc`' => Text::_('COM_PRODUCTION_PRODUCTIONSUMMARIES_TOTAL_NC'),
			'a.`synced_at`' => Text::_('COM_PRODUCTION_PRODUCTIONSUMMARIES_SYNCED_AT'),
			'a.`part`' => Text::_('COM_PRODUCTION_PRODUCTIONSUMMARIES_PART'),
		);
	}

	/**
	 * Check if state is set
	 *
	 * @param   mixed  $state  State
	 *
	 * @return bool
	 */
	public function getState($state)
	{
		return isset($this->state->{$state}) ? $this->state->{$state} : false;
	}
}
