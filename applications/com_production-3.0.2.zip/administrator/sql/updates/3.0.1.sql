ALTER TABLE `#__production_summary` ADD COLUMN IF NOT EXISTS `total_acc` INT NULL DEFAULT 0;

ALTER TABLE `#__production_summary` ADD COLUMN IF NOT EXISTS `source` VARCHAR(10) NOT NULL DEFAULT 'sync';

UPDATE `#__production_summary` AS s INNER JOIN `#__product_catalogs` AS c ON c.id = s.model_id SET s.part = CAST(SUBSTRING_INDEX(c.component, ',', 1) AS UNSIGNED), s.model = c.id;

UPDATE `#__production_summary` SET `part` = '0' WHERE `part` NOT REGEXP '^[0-9]+$';

UPDATE `#__production_summary` SET `model` = '0' WHERE `model` NOT REGEXP '^[0-9]+$';

ALTER TABLE `#__production_summary` MODIFY `part` INT NULL DEFAULT 0, MODIFY `model` INT NULL DEFAULT 0;
