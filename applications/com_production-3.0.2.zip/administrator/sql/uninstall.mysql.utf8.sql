DROP TABLE IF EXISTS `#__production_summary`;

DELETE FROM `#__action_log_config` WHERE (type_alias LIKE 'com_production.%');
DELETE FROM `#__action_logs_extensions` WHERE (extension = 'com_production');