CREATE TABLE IF NOT EXISTS `#__production_summary` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`date` DATE NULL  DEFAULT NULL,
`model_id` INT NULL  DEFAULT 0,
`model` INT NULL  DEFAULT 0,
`total_sort` INT NULL  DEFAULT 0,
`total_nc` INT NULL  DEFAULT 0,
`total_acc` INT NULL  DEFAULT 0,
`synced_at` DATETIME NULL  DEFAULT NULL ,
`part` INT NULL  DEFAULT 0,
`source` VARCHAR(10) NOT NULL DEFAULT 'sync',
PRIMARY KEY (`id`)
,KEY `idx_state` (`state`)
,KEY `idx_checked_out` (`checked_out`)
,KEY `idx_created_by` (`created_by`)
,KEY `idx_modified_by` (`modified_by`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `#__production_summary_date` ON `#__production_summary`(`date`);

CREATE INDEX `#__production_summary_model_id` ON `#__production_summary`(`model_id`);

CREATE INDEX `#__production_summary_total_sort` ON `#__production_summary`(`total_sort`);

CREATE INDEX `#__production_summary_total_nc` ON `#__production_summary`(`total_nc`);

CREATE INDEX `#__production_summary_total_acc` ON `#__production_summary`(`total_acc`);

CREATE INDEX `#__production_summary_source` ON `#__production_summary`(`source`);

CREATE INDEX `#__production_summary_synced_at` ON `#__production_summary`(`synced_at`);


INSERT INTO `#__action_log_config` (`type_title`, `type_alias`, `id_holder`, `title_holder`, `table_name`, `text_prefix`)
SELECT * FROM ( SELECT 'productionsummary' AS type_title,'com_production.productionsummary' AS type_alias,'id' AS id_holder,'model' AS title_holder,'#__production_summary' AS table_name,'PLG_ACTIONLOG_PRODUCTION' AS text_prefix ) AS tmp
WHERE NOT EXISTS (
	SELECT type_alias FROM `#__action_log_config` WHERE (`type_alias` = 'com_production.productionsummary')
) LIMIT 1;

INSERT INTO `#__action_logs_extensions` (`extension`)
SELECT * FROM ( SELECT 'com_production' ) AS tmp
WHERE NOT EXISTS (
	SELECT extension FROM `#__action_logs_extensions` WHERE (`extension` = 'com_production')
) LIMIT 1;
