CREATE TABLE IF NOT EXISTS `#__sot_purchase_orders` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`po_no` VARCHAR(255)  NULL  DEFAULT "",
`created_date` DATETIME NULL  DEFAULT NULL ,
`working_days` SMALLINT UNSIGNED NULL  DEFAULT NULL ,
`month` TINYINT UNSIGNED NULL  DEFAULT NULL ,
`year` SMALLINT UNSIGNED NULL  DEFAULT NULL ,
PRIMARY KEY (`id`)
,KEY `idx_state` (`state`)
,KEY `idx_checked_out` (`checked_out`)
,KEY `idx_created_by` (`created_by`)
,KEY `idx_modified_by` (`modified_by`)
,KEY `idx_year_month` (`year`, `month`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__sot_purchase_orders_details` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`po_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
`po_no` VARCHAR(255)  NULL  DEFAULT "",
`created_date` DATETIME NULL  DEFAULT NULL ,
`year` SMALLINT UNSIGNED NULL  DEFAULT NULL ,
`month` TINYINT UNSIGNED NULL  DEFAULT NULL ,
`part` VARCHAR(255)  NULL  DEFAULT "",
`model` VARCHAR(255)  NULL  DEFAULT "",
`total_po` INT NULL  DEFAULT 0,
`daily_plan_qty` INT NULL  DEFAULT 0,
PRIMARY KEY (`id`)
,KEY `idx_po_id` (`po_id`)
,KEY `idx_po_no` (`po_no`)
,KEY `idx_year_month` (`year`, `month`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;


INSERT INTO `#__action_log_config` (`type_title`, `type_alias`, `id_holder`, `title_holder`, `table_name`, `text_prefix`)
SELECT * FROM ( SELECT 'purchaseorder' AS type_title,'com_sot.purchaseorder' AS type_alias,'id' AS id_holder,'po_no' AS title_holder,'#__sot_purchase_orders' AS table_name,'PLG_ACTIONLOG_SOT' AS text_prefix ) AS tmp
WHERE NOT EXISTS (
	SELECT type_alias FROM `#__action_log_config` WHERE (`type_alias` = 'com_sot.purchaseorder')
) LIMIT 1;

INSERT INTO `#__action_logs_extensions` (`extension`)
SELECT * FROM ( SELECT 'com_sot' ) AS tmp
WHERE NOT EXISTS (
	SELECT extension FROM `#__action_logs_extensions` WHERE (`extension` = 'com_sot')
) LIMIT 1;
