DROP TABLE IF EXISTS `#__sot_purchase_orders`;

DROP TABLE IF EXISTS `#__sot_purchase_orders_details`;

DELETE FROM `#__action_log_config` WHERE (type_alias LIKE 'com_sot.%');
DELETE FROM `#__action_logs_extensions` WHERE (extension = 'com_sot');