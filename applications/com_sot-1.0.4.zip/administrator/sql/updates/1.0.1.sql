-- 1.0.1: move part/model/total_po/daily_plan_qty into #__sot_purchase_orders_details

CREATE TABLE IF NOT EXISTS `#__sot_purchase_orders_details` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`po_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
`po_no` VARCHAR(255) NULL DEFAULT "",
`created_date` DATETIME NULL DEFAULT NULL,
`year` SMALLINT UNSIGNED NULL DEFAULT NULL,
`month` TINYINT UNSIGNED NULL DEFAULT NULL,
`part` VARCHAR(255) NULL DEFAULT "",
`model` VARCHAR(255) NULL DEFAULT "",
`total_po` INT NULL DEFAULT 0,
`daily_plan_qty` INT NULL DEFAULT 0,
PRIMARY KEY (`id`),
KEY `idx_po_id` (`po_id`),
KEY `idx_po_no` (`po_no`),
KEY `idx_year_month` (`year`, `month`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

UPDATE `#__sot_purchase_orders` SET `year` = NULL, `month` = NULL;

ALTER TABLE `#__sot_purchase_orders` MODIFY `month` TINYINT UNSIGNED NULL DEFAULT NULL, MODIFY `year` SMALLINT UNSIGNED NULL DEFAULT NULL;

UPDATE `#__sot_purchase_orders` SET `year` = YEAR(`created_date`), `month` = MONTH(`created_date`) WHERE `created_date` IS NOT NULL;

INSERT INTO `#__sot_purchase_orders_details` (`po_id`, `po_no`, `created_date`, `year`, `month`, `part`, `model`, `total_po`, `daily_plan_qty`)
SELECT `id`, `po_no`, `created_date`, `year`, `month`, COALESCE(`part`, ''), COALESCE(`model`, ''), COALESCE(`total_po`, 0), COALESCE(`daily_plan_qty`, 0)
FROM `#__sot_purchase_orders`
WHERE COALESCE(`part`, '') <> '' OR COALESCE(`model`, '') <> '' OR COALESCE(`total_po`, 0) <> 0 OR COALESCE(`daily_plan_qty`, 0) <> 0;

DROP INDEX `#__sot_purchase_orders_total_po` ON `#__sot_purchase_orders`;

DROP INDEX `#__sot_purchase_orders_daily_plan_qty` ON `#__sot_purchase_orders`;

ALTER TABLE `#__sot_purchase_orders` DROP COLUMN `part`, DROP COLUMN `model`, DROP COLUMN `total_po`, DROP COLUMN `daily_plan_qty`, ADD KEY `idx_year_month` (`year`, `month`);
