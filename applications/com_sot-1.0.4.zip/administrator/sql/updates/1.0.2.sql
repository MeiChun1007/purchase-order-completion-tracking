-- 1.0.2: working days per purchase order (daily_plan_qty = total_po / working_days)

ALTER TABLE `#__sot_purchase_orders` ADD COLUMN `working_days` SMALLINT UNSIGNED NULL DEFAULT NULL AFTER `created_date`;
