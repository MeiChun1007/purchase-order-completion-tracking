<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txtSOTholidau
 */

namespace Sot\Component\Sot\Administrator\Table;
// No direct access
defined('_JEXEC') or die;

use \Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Access\Access;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Table\Table as Table;
use \Joomla\CMS\Versioning\VersionableTableInterface;
use Joomla\CMS\Tag\TaggableTableInterface;
use Joomla\CMS\Tag\TaggableTableTrait;
use \Joomla\Database\DatabaseDriver;
use \Joomla\Database\ParameterType;
use \Joomla\CMS\Filter\OutputFilter;
use \Joomla\Registry\Registry;
use \Sot\Component\Sot\Administrator\Helper\SotHelper;
use \Joomla\CMS\Helper\ContentHelper;
use \Joomla\CMS\User\CurrentUserInterface;
use \Joomla\CMS\User\CurrentUserTrait;


/**
 * Purchaseorder table
 *
 * @since 1.0.0
 */
class PurchaseorderTable extends Table implements VersionableTableInterface, TaggableTableInterface, CurrentUserInterface
{
	use TaggableTableTrait;
	use CurrentUserTrait;

	/**
	 * Indicates that columns fully support the NULL value in the database
	 *
	 * @var    boolean
	 * @since  4.0.0
	 */
	protected $_supportNullValue = true;


	/**
	 * Constructor
	 *
	 * @param   DatabaseDriver  $db  A database connector object
	 */
	public function __construct(DatabaseDriver $db)
	{
		$this->typeAlias = 'com_sot.purchaseorder';
		parent::__construct('#__sot_purchase_orders', 'id', $db);
		$this->setColumnAlias('published', 'state');
	}

	/**
	 * Get the type alias for the history table
	 *
	 * @return  string  The alias as described above
	 *
	 * @since   1.0.0
	 */
	public function getTypeAlias()
	{
		return $this->typeAlias;
	}

	/**
	 * Overloaded bind function to pre-process the params.
	 *
	 * @param   array  $array   Named array
	 * @param   mixed  $ignore  Optional array or list of parameters to ignore
	 *
	 * @return  boolean  True on success.
	 *
	 * @see     Table:bind
	 * @since   1.0.0
	 * @throws  \InvalidArgumentException
	 */
	public function bind($array, $ignore = '')
	{
		$date = Factory::getDate();
		$task = Factory::getApplication()->input->get('task');
		$user = Factory::getApplication()->getIdentity();

		$input = Factory::getApplication()->input;
		$task = $input->getString('task', '');

		if ($array['id'] == 0 && empty($array['created_by'])) {
			$array['created_by'] = $this->getCurrentUser()->id;
		}

		if ($array['id'] == 0 && empty($array['modified_by'])) {
			$array['modified_by'] = $this->getCurrentUser()->id;
		}

		if ($task == 'apply' || $task == 'save') {
			$array['modified_by'] = $this->getCurrentUser()->id;
		}

		// Subform rows (part / model / total_po / daily_plan_qty). They are not
		// columns of this table; they are written to #__sot_purchase_orders_details
		// in store(). "null" means "not submitted", so other callers that only
		// load() + store() (e.g. reordering) never wipe the detail rows.
		if (array_key_exists('details', $array)) {
			$this->setDetails(is_array($array['details']) ? $array['details'] : array());
		}

		// year and month are always derived from created_date in check()
		unset($array['year'], $array['month']);

		if (isset($array['params']) && is_array($array['params'])) {
			$registry = new Registry;
			$registry->loadArray($array['params']);
			$array['params'] = (string) $registry;
		}

		if (isset($array['metadata']) && is_array($array['metadata'])) {
			$registry = new Registry;
			$registry->loadArray($array['metadata']);
			$array['metadata'] = (string) $registry;
		}

		if (!$user->authorise('core.admin', 'com_sot.purchaseorder.' . $array['id'])) {
			$actions         = Access::getActionsFromFile(
				JPATH_ADMINISTRATOR . '/components/com_sot/access.xml',
				"/access/section[@name='purchaseorder']/"
			);
			$default_actions = Access::getAssetRules('com_sot.purchaseorder.' . $array['id'])->getData();
			$array_jaccess   = array();

			foreach ($actions as $action) {
				if (key_exists($action->name, $default_actions)) {
					$array_jaccess[$action->name] = $default_actions[$action->name];
				}
			}

			$array['rules'] = $this->JAccessRulestoArray($array_jaccess);
		}

		// Bind the rules for ACL where supported.
		if (isset($array['rules']) && is_array($array['rules'])) {
			$this->setRules($array['rules']);
		}

		return parent::bind($array, $ignore);
	}

	/**
	 * Method to store a row in the database from the Table instance properties.
	 *
	 * If a primary key value is set the row with that primary key value will be updated with the instance property values.
	 * If no primary key value is set a new row will be inserted into the database with the properties from the Table instance.
	 *
	 * @param   boolean  $updateNulls  True to update fields even if they are null.
	 *
	 * @return  boolean  True on success.
	 *
	 * @since   1.0.0
	 */
	public function store($updateNulls = true)
	{
		if (!parent::store($updateNulls)) {
			return false;
		}

		// Only touch the details table when rows were handed to this table object
		if ($this->_pendingDetails !== null) {
			if (!$this->syncDetails()) {
				return false;
			}

			$this->_pendingDetails = null;
		}

		return true;
	}

	/**
	 * Rows for #__sot_purchase_orders_details waiting to be written by store().
	 *
	 * @var    array|null
	 */
	protected $_pendingDetails = null;

	/**
	 * Set the detail (subform) rows that store() will write to
	 * #__sot_purchase_orders_details. Rows without any data are dropped.
	 * daily_plan_qty is never taken from the input: it is calculated in
	 * syncDetails() as total_po / working_days.
	 *
	 * @param   array  $rows  Rows with the keys part, model, total_po
	 *
	 * @return  void
	 */
	public function setDetails(array $rows)
	{
		$clean = array();

		foreach ($rows as $row) {
			$row = (array) $row;

			$part  = trim((string) ($row['part'] ?? ''));
			$model = trim((string) ($row['model'] ?? ''));
			$total = (int) ($row['total_po'] ?? 0);

			// Skip completely empty rows (e.g. the untouched first subform row)
			if ($part === '' && $model === '') {
				continue;
			}

			$clean[] = array(
				'part'           => $part,
				'model'          => $model,
				'total_po'       => $total,
			);
		}

		$this->_pendingDetails = $clean;
	}

	/**
	 * Every part / model already known in #__sot_purchase_orders_details,
	 * as ready-made subform rows (Total PO left blank) for a NEW purchase order.
	 */
	public function getPartModelList()
	{
		$db    = $this->_db;
		$query = $db->getQuery(true)
			->select('DISTINCT ' . $db->quoteName('part') . ', ' . $db->quoteName('model'))
			->from($db->quoteName('#__sot_purchase_orders_details'))
			->where($db->quoteName('part') . " != ''")
			->where($db->quoteName('model') . " != ''")
			->order($db->quoteName('part') . ', ' . $db->quoteName('model'));

		$rows = array();

		foreach ($db->setQuery($query)->loadAssocList() ?: array() as $i => $r) {
			$rows['details' . $i] = array(
				'part'           => $r['part'],
				'model'          => $r['model'],
				'total_po'       => '',
				'daily_plan_qty' => 0,
			);
		}

		return $rows;
	}

	/**
	 * Get the detail rows of a purchase order, in the order they were entered.
	 *
	 * @param   integer|null  $poId  Purchase order id (defaults to this record)
	 *
	 * @return  array  List of associative arrays
	 */
	public function getDetails($poId = null)
	{
		$poId = (int) ($poId ?: $this->id);

		if ($poId <= 0) {
			return array();
		}

		$db    = $this->_db;
		$query = $db->getQuery(true)
			->select($db->quoteName(array('a.part', 'pc.component_name', 'a.model', 'pm.model_name', 'a.total_po', 'a.daily_plan_qty')))
			->from($db->quoteName('#__sot_purchase_orders_details', 'a'))
			->join('LEFT', $db->quoteName('#__product_components', 'pc') . ' ON ' . $db->quoteName('pc.id') . ' = ' . $db->quoteName('a.part'))
			->join('LEFT', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'))
			->where($db->quoteName('po_id') . ' = :poid')
			->bind(':poid', $poId, ParameterType::INTEGER)
			->order($db->quoteName('a.id') . ' ASC');

		return $db->setQuery($query)->loadAssocList() ?: array();
	}

	/**
	 * Replace the rows of #__sot_purchase_orders_details for this purchase order
	 * with the pending subform rows. po_no, created_date, year and month are
	 * copied from this (already stored) record.
	 *
	 * @return  boolean
	 */
	protected function syncDetails()
	{
		$db   = $this->_db;
		$poId = (int) $this->id;

		try {
			$db->transactionStart();

			$query = $db->getQuery(true)
				->delete($db->quoteName('#__sot_purchase_orders_details'))
				->where($db->quoteName('po_id') . ' = :poid')
				->bind(':poid', $poId, ParameterType::INTEGER);
			$db->setQuery($query)->execute();

			$workingDays = (int) $this->working_days;

			foreach ($this->_pendingDetails as $row) {
				$object = (object) array(
					'po_id'          => $poId,
					'po_no'          => (string) $this->po_no,
					'created_date'   => $this->created_date,
					'year'           => (int) $this->year,
					'month'          => (int) $this->month,
					'part'           => $row['part'],
					'model'          => $row['model'],
					'total_po'       => $row['total_po'],
					// Total PO / working days, rounded up so the plan always covers the PO
					'daily_plan_qty' => $workingDays > 0 ? (int) ceil($row['total_po'] / $workingDays) : 0,
				);

				$db->insertObject('#__sot_purchase_orders_details', $object);
			}

			$db->transactionCommit();
		} catch (\Exception $e) {
			$db->transactionRollback();
			$this->setError($e->getMessage());

			return false;
		}

		return true;
	}

	/**
	 * This function convert an array of Access objects into an rules array.
	 *
	 * @param   array  $jaccessrules  An array of Access objects.
	 *
	 * @return  array
	 */
	private function JAccessRulestoArray($jaccessrules)
	{
		$rules = array();

		foreach ($jaccessrules as $action => $jaccess) {
			$actions = array();

			if ($jaccess) {
				foreach ($jaccess->getData() as $group => $allow) {
					$actions[$group] = ((bool)$allow);
				}
			}

			$rules[$action] = $actions;
		}

		return $rules;
	}

	/**
	 * Overloaded check function
	 *
	 * @return bool
	 */
	public function check()
	{
		// If there is an ordering column and this is a new row then get the next ordering value
		if (property_exists($this, 'ordering') && $this->id == 0) {
			$this->ordering = self::getNextOrder();
		}

		// Default created_date to "now" (UTC) when it was not supplied
		if (empty($this->created_date) || $this->created_date === '0000-00-00 00:00:00' || !strtotime($this->created_date)) {
			$this->created_date = Factory::getDate()->toSql();
		}

		// Auto-detect year and month from created_date. created_date is stored in
		// UTC, so convert to the user's timezone first: a PO created at 01:00 on the
		// 1st in Kuala Lumpur belongs to the new month, not the previous UTC month.
		$date = Factory::getDate($this->created_date, 'UTC');
		$date->setTimezone($this->getCurrentUser()->getTimezone());
		$this->year  = (int) $date->format('Y', true);
		$this->month = (int) $date->format('n', true);

		// Working days of the created_date's month, minus holidays
		$this->working_days = $this->calculateWorkingDays($date);

		return parent::check();
	}

	/**
	 * Define a namespaced asset name for inclusion in the #__assets table
	 *
	 * @return string The asset name
	 *
	 * @see Table::_getAssetName
	 */
	protected function _getAssetName()
	{
		$k = $this->_tbl_key;

		return $this->typeAlias . '.' . (int) $this->$k;
	}

	/**
	 * Returns the parent asset's id. If you have a tree structure, retrieve the parent's id using the external key field
	 *
	 * @param   Table   $table  Table name
	 * @param   integer  $id     Id
	 *
	 * @see Table::_getAssetParentId
	 *
	 * @return mixed The id on success, false on failure.
	 */
	protected function _getAssetParentId($table = null, $id = null)
	{
		// We will retrieve the parent-asset from the Asset-table
		$assetParent = Table::getInstance('Asset');

		// Default: if no asset-parent can be found we take the global asset
		$assetParentId = $assetParent->getRootId();

		// The item has the component as asset-parent
		$assetParent->loadByName('com_sot');

		// Return the found asset-parent-id
		if ($assetParent->id) {
			$assetParentId = $assetParent->id;
		}

		return $assetParentId;
	}

	//XXX_CUSTOM_TABLE_FUNCTION


	/**
	 * Delete a record by id
	 *
	 * @param   mixed  $pk  Primary key value to delete. Optional
	 *
	 * @return bool
	 */
	public function delete($pk = null)
	{
		$this->load($pk);
		$poId   = (int) $this->id;
		$result = parent::delete($pk);

		// Remove the detail rows together with the purchase order
		if ($result && $poId > 0) {
			$db    = $this->_db;
			$query = $db->getQuery(true)
				->delete($db->quoteName('#__sot_purchase_orders_details'))
				->where($db->quoteName('po_id') . ' = :poid')
				->bind(':poid', $poId, ParameterType::INTEGER);
			$db->setQuery($query)->execute();
		}

		return $result;
	}

	/**
	 * Mon-Fri days in the month of $date, minus holidays that fall on those days.
	 *
	 * @param   \Joomla\CMS\Date\Date  $date  created_date, already in the user's timezone
	 *
	 * @return  integer
	 */
	protected function calculateWorkingDays($date)
	{
		// Change to [5, 6] (Fri/Sat) if your company works Sun-Thu
		$weekend = [7]; // ISO day numbers: 6 = Saturday, 7 = Sunday

		$first = new \DateTime($date->format('Y-m-01', true));
		$last  = (clone $first)->modify('last day of this month');

		// Every working day (Mon-Fri) of the month, keyed by Y-m-d
		$workingDays = [];

		for ($d = clone $first; $d <= $last; $d->modify('+1 day')) {
			if (!in_array((int) $d->format('N'), $weekend, true)) {
				$workingDays[$d->format('Y-m-d')] = true;
			}
		}

		// Holidays of that month
		$start = $first->format('Y-m-d');
		$end   = $last->format('Y-m-d');
		$db    = $this->_db;

		$query = $db->getQuery(true)
			->select('DISTINCT ' . $db->quoteName('cal_date'))   // <-- adjust column name here
			->from($db->quoteName('#__calendar_holidays'))
			->where($db->quoteName('cal_date') . ' BETWEEN :start AND :end') // <-- and here
			->bind(':start', $start)
			->bind(':end', $end);

		foreach ($db->setQuery($query)->loadColumn() as $holiday) {
			// A holiday on a weekend is already excluded, so only subtract weekday ones.
			// Using the array keys also stops duplicate rows being subtracted twice.
			unset($workingDays[substr((string) $holiday, 0, 10)]);
		}

		return count($workingDays);
	}
}
