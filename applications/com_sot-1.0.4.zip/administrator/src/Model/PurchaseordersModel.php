<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Sot\Component\Sot\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Sot\Component\Sot\Administrator\Helper\SotHelper;
use \Joomla\Database\DatabaseInterface;

/**
 * Methods supporting a list of Purchaseorders records.
 *
 * @since  1.0.0
 */
class PurchaseordersModel extends ListModel
{
	/**
	* Constructor.
	*
	* @param   array  $config  An optional associative array of configuration settings.
	*
	* @see        JController
	* @since      1.6
	*/
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id',
				'state', 'a.state',
				'ordering', 'a.ordering',
				'created_by', 'a.created_by',
				'modified_by', 'a.modified_by',
				'po_no', 'a.po_no',
				'created_date', 'a.created_date',
		'created_date.from', 'created_date.to',
				'month', 'a.month',
				'year', 'a.year',
				'working_days', 'a.working_days',
			);
		}

		parent::__construct($config);
	}


	

	

	

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return void
	 *
	 * @throws \Exception
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState('id', 'DESC');

		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);

		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);

			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string A store id.
	 *
	 * @since   1.0.0
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');

		
		return parent::getStoreId($id);
		
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  \Joomla\Database\DatabaseQuery
	 *
	 * @since   1.0.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select', 'DISTINCT a.*'
			)
		);
		$query->from('`#__sot_purchase_orders` AS a');

		// Number of rows in #__sot_purchase_orders_details
		$query->select('(SELECT COUNT(*) FROM `#__sot_purchase_orders_details` AS d WHERE d.po_id = a.id) AS detail_count');
		
		// Join over the users for the checked out user
		$query->select("uc.name AS uEditor");
		$query->join("LEFT", "#__users AS uc ON uc.id=a.checked_out");
		

		// Filter by published state
		$published = $this->getState('filter.state');

		if (is_numeric($published))
		{
			$query->where('a.state = ' . (int) $published);
		}
		elseif (empty($published))
		{
			$query->where('(a.state IN (0, 1))');
		}

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = '%' . $search . '%';
				$query->where('( a.po_no LIKE :search_0 OR a.id IN (SELECT d.po_id FROM `#__sot_purchase_orders_details` AS d WHERE d.part LIKE :search_1 OR d.model LIKE :search_2) )')->bind([':search_0', ':search_1', ':search_2'], $search);
			}
		}
		

		// Filtering created_date
		$filter_created_date_from = $this->state->get("filter.created_date.from");

		if ($filter_created_date_from !== null && !empty($filter_created_date_from))
		{
			$tz = \Joomla\CMS\Factory::getApplication()->getIdentity()->getTimezone();
			$fromDate = \Joomla\CMS\Factory::getDate($filter_created_date_from . ' 00:00:00', $tz);
			$fromDateSql_created_date = $fromDate->toSql();
			$query->where($db->quoteName("a.created_date") . " >= :filter_created_date_from")->bind(':filter_created_date_from', $fromDateSql_created_date);
		}
		$filter_created_date_to = $this->state->get("filter.created_date.to");

		if ($filter_created_date_to !== null  && !empty($filter_created_date_to))
		{
			$tz = \Joomla\CMS\Factory::getApplication()->getIdentity()->getTimezone();
			$toDate = \Joomla\CMS\Factory::getDate($filter_created_date_to . ' 23:59:59', $tz);
			$toDateSql_created_date = $toDate->toSql();
			$query->where($db->quoteName("a.created_date") . " <= :filter_created_date_to")->bind(':filter_created_date_to', $toDateSql_created_date);
		}

		// Filtering month
		$filter_month = $this->state->get("filter.month");

		if (is_numeric($filter_month) && (int) $filter_month > 0)
		{
			$filter_month = (int) $filter_month;
			$query->where($db->quoteName("a.month") . " = :filter_month")->bind(':filter_month', $filter_month, ParameterType::INTEGER);
		}

		// Filtering year
		$filter_year = $this->state->get("filter.year");

		if (is_numeric($filter_year) && (int) $filter_year > 0)
		{
			$filter_year = (int) $filter_year;
			$query->where($db->quoteName("a.year") . " = :filter_year")->bind(':filter_year', $filter_year, ParameterType::INTEGER);
		}

		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', 'id');
		$orderDirn = $this->state->get('list.direction', 'DESC');

		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}
}
