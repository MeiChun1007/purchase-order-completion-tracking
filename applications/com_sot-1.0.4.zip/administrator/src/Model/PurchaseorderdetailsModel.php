<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Sot\Component\Sot\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\CMS\Factory;
use \Joomla\Database\DatabaseInterface;
use \Joomla\Database\ParameterType;

/**
 * Methods supporting a list of Purchase Order Details records
 * (table #__sot_purchase_orders_details).
 *
 * @since  1.0.1
 */
class PurchaseorderdetailsModel extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since   1.0.1
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id',
				'po_id', 'a.po_id',
				'po_no', 'a.po_no',
				'created_date', 'a.created_date',
				'created_date.from', 'created_date.to',
				'year', 'a.year',
				'month', 'a.month',
				'part', 'a.part',
				'model', 'a.model',
				'total_po', 'a.total_po',
				'daily_plan_qty', 'a.daily_plan_qty',
			);
		}

		parent::__construct($config);
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return  void
	 *
	 * @since   1.0.1
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		parent::populateState('a.id', 'DESC');
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string  A store id.
	 *
	 * @since   1.0.1
	 */
	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.part');
		$id .= ':' . $this->getState('filter.model');
		$id .= ':' . $this->getState('filter.year');
		$id .= ':' . $this->getState('filter.month');
		$id .= ':' . $this->getState('filter.created_date.from');
		$id .= ':' . $this->getState('filter.created_date.to');

		return parent::getStoreId($id);
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  \Joomla\Database\DatabaseQuery
	 *
	 * @since   1.0.1
	 */
	protected function getListQuery()
	{
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		$query->select($this->getState('list.select', 'a.*'));
		$query->from($db->quoteName('#__sot_purchase_orders_details', 'a'));

		// Hide the details of purchase orders that are in the trash
		$query->join('INNER', $db->quoteName('#__sot_purchase_orders', 'p') . ' ON p.id = a.po_id');
		$query->where('p.state <> -2');

		// Search
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			$search = '%' . $search . '%';
			$query->where('( a.po_no LIKE :search_0 OR a.part LIKE :search_1 OR a.model LIKE :search_2 )')
				->bind([':search_0', ':search_1', ':search_2'], $search);
		}

		// Part / model (exact match, values come from the filter dropdowns)
		$filterPart = (string) $this->getState('filter.part');

		if ($filterPart !== '')
		{
			$query->where($db->quoteName('a.part') . ' = :filter_part')->bind(':filter_part', $filterPart);
		}

		$filterModel = (string) $this->getState('filter.model');

		if ($filterModel !== '')
		{
			$query->where($db->quoteName('a.model') . ' = :filter_model')->bind(':filter_model', $filterModel);
		}

		// Year / month
		$filterYear = $this->getState('filter.year');

		if (is_numeric($filterYear) && (int) $filterYear > 0)
		{
			$filterYear = (int) $filterYear;
			$query->where($db->quoteName('a.year') . ' = :filter_year')->bind(':filter_year', $filterYear, ParameterType::INTEGER);
		}

		$filterMonth = $this->getState('filter.month');

		if (is_numeric($filterMonth) && (int) $filterMonth > 0)
		{
			$filterMonth = (int) $filterMonth;
			$query->where($db->quoteName('a.month') . ' = :filter_month')->bind(':filter_month', $filterMonth, ParameterType::INTEGER);
		}

		// Created date range (entered in the user's timezone, stored in UTC)
		$from = $this->getState('filter.created_date.from');

		if (!empty($from))
		{
			$tz       = Factory::getApplication()->getIdentity()->getTimezone();
			$fromSql  = Factory::getDate($from . ' 00:00:00', $tz)->toSql();
			$query->where($db->quoteName('a.created_date') . ' >= :filter_from')->bind(':filter_from', $fromSql);
		}

		$to = $this->getState('filter.created_date.to');

		if (!empty($to))
		{
			$tz     = Factory::getApplication()->getIdentity()->getTimezone();
			$toSql  = Factory::getDate($to . ' 23:59:59', $tz)->toSql();
			$query->where($db->quoteName('a.created_date') . ' <= :filter_to')->bind(':filter_to', $toSql);
		}

		// Ordering
		$orderCol  = $this->state->get('list.ordering', 'a.id');
		$orderDirn = $this->state->get('list.direction', 'DESC');

		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}
}
