<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Layout\LayoutHelper;
use \Joomla\CMS\Language\Text;

HTMLHelper::_('bootstrap.tooltip');

$user      = Factory::getApplication()->getIdentity();
$canEdit   = $user->authorise('core.edit', 'com_sot');
$listOrder = $this->state->get('list.ordering');
$listDirn  = $this->state->get('list.direction');
?>

<form action="<?php echo Route::_('index.php?option=com_sot&view=purchaseorderdetails'); ?>" method="post"
	  name="adminForm" id="adminForm">
	<div class="row">
		<div class="col-md-12">
			<div id="j-main-container" class="j-main-container">
				<?php echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this)); ?>

				<div class="clearfix"></div>
				<table class="table table-striped" id="purchaseorderdetailList">
					<thead>
					<tr>
						<th class="left">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_PO_NO', 'a.po_no', $listDirn, $listOrder); ?>
						</th>
						<th class="left">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_CREATED_DATE', 'a.created_date', $listDirn, $listOrder); ?>
						</th>
						<!-- <th class="left">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_YEAR', 'a.year', $listDirn, $listOrder); ?>
						</th>
						<th class="left">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_MONTH', 'a.month', $listDirn, $listOrder); ?>
						</th> -->
						<th class="left">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_PART', 'a.part', $listDirn, $listOrder); ?>
						</th>
						<th class="left">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_MODEL', 'a.model', $listDirn, $listOrder); ?>
						</th>
						<th class="left">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_TOTAL_PO', 'a.total_po', $listDirn, $listOrder); ?>
						</th>
						<th class="left">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_DAILY_PLAN_QTY', 'a.daily_plan_qty', $listDirn, $listOrder); ?>
						</th>
						<th scope="col" class="w-3 d-none d-lg-table-cell">
							<?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?>
						</th>
					</tr>
					</thead>
					<tfoot>
					<tr>
						<td colspan="9">
							<?php echo $this->pagination->getListFooter(); ?>
						</td>
					</tr>
					</tfoot>
					<tbody>
					<?php foreach ($this->items as $i => $item) : ?>
						<tr class="row<?php echo $i % 2; ?>">
							<td>
								<?php if ($canEdit) : ?>
									<a href="<?php echo Route::_('index.php?option=com_sot&task=purchaseorder.edit&id=' . (int) $item->po_id); ?>">
										<?php echo $this->escape($item->po_no); ?>
									</a>
								<?php else : ?>
									<?php echo $this->escape($item->po_no); ?>
								<?php endif; ?>
							</td>
							<td>
								<?php echo $item->created_date > 0 ? HTMLHelper::_('date', $item->created_date, Text::_('DATE_FORMAT_LC2')) : '-'; ?>
							</td>
							<!-- <td><?php echo $item->year ? (int) $item->year : '-'; ?></td>
							<td><?php echo $item->month ? Text::_('COM_SOT_PURCHASEORDERS_MONTH_OPTION_' . (int) $item->month) : '-'; ?></td> -->
							<td><?php echo $this->escape($item->part); ?></td>
							<td><?php echo $this->escape($item->model); ?></td>
							<td><?php echo (int) $item->total_po; ?></td>
							<td><?php echo (int) $item->daily_plan_qty; ?></td>
							<td class="d-none d-lg-table-cell"><?php echo (int) $item->id; ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>

				<input type="hidden" name="task" value=""/>
				<input type="hidden" name="boxchecked" value="0"/>
				<input type="hidden" name="list[fullorder]" value="<?php echo $listOrder; ?> <?php echo $listDirn; ?>"/>
				<?php echo HTMLHelper::_('form.token'); ?>
			</div>
		</div>
	</div>
</form>
