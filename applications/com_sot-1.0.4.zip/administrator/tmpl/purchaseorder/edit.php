<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;

$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
	->useScript('form.validate')
	->useScript('com_sot.po-form');
HTMLHelper::_('bootstrap.tooltip');
?>

<form
	action="<?php echo Route::_('index.php?option=com_sot&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="purchaseorder-form" class="form-validate form-horizontal">

	
	<?php echo HTMLHelper::_('uitab.startTabSet', 'myTab', array('active' => 'sotdetail')); ?>
	<?php echo HTMLHelper::_('uitab.addTab', 'myTab', 'sotdetail', Text::_('COM_SOT_TAB_SOTDETAIL', true)); ?>
	<div class="row-fluid">
		<div class="col-md-12 form-horizontal">
			<fieldset class="adminform">
				<legend><?php echo Text::_('COM_SOT_FIELDSET_SOTDETAIL'); ?></legend>
				<?php echo $this->form->renderField('po_no'); ?>
				<?php echo $this->form->renderField('created_date'); ?>
				<?php echo $this->form->renderField('working_days'); ?>
				<?php echo $this->form->renderField('details'); ?>
			</fieldset>
		</div>
	</div>
	<?php echo HTMLHelper::_('uitab.endTab'); ?>
	<input type="hidden" name="jform[id]" value="<?php echo isset($this->item->id) ? $this->item->id : ''; ?>" />

	<input type="hidden" name="jform[state]" value="<?php echo isset($this->item->state) ? $this->item->state : ''; ?>" />

	<?php echo $this->form->renderField('created_by'); ?>
	<?php echo $this->form->renderField('modified_by'); ?>

	
	<?php echo HTMLHelper::_('uitab.endTabSet'); ?>

	<input type="hidden" name="task" value=""/>
	<?php echo HTMLHelper::_('form.token'); ?>

</form>

<script>
	var ncAjaxBase = <?php echo json_encode(rtrim(\Joomla\CMS\Uri\Uri::root(true), '/') . '/index.php'); ?>;

	document.addEventListener('DOMContentLoaded', function() {
		// --- Component -> Model cascade ---
		const componentField = document.querySelector('select[name="jform[part]"]');

		document.addEventListener('change', function(event) {
			if (!componentField || event.target !== componentField) return;

			const componentId = event.target.value;
			const modelField = document.querySelector('select[name="jform[model]"]');
			if (!modelField) {
				console.error("Could not find the model select element by name attribute.");
				return;
			}

			const modelWrapper = modelField.closest('joomla-field-fancy-select');

			modelField.innerHTML = '<option value="">Select Model</option>';

			if (modelWrapper && modelWrapper.choicesInstance) {
				modelWrapper.choicesInstance.clearChoices();
				modelWrapper.choicesInstance.setChoices([{
					value: '',
					label: 'Select Model',
					selected: true
				}], 'value', 'label', true);
			}

			if (!componentId) return;

			fetch(`index.php?option=com_sot&task=purchaseorders.getModelsByComponent&component_id=${componentId}&format=json`)
				.then(response => response.json())
				.then(data => {
					if (data && data.success && data.data) {
						data.data.forEach(model => {
							const option = new Option(model.value, model.key);
							modelField.add(option);
						});

						if (modelWrapper && modelWrapper.choicesInstance) {
							const newChoices = data.data.map(m => ({
								value: String(m.key),
								label: String(m.value)
							}));
							modelWrapper.choicesInstance.setChoices(newChoices, 'value', 'label', true);
						}
					}
				})
				.catch(error => console.error('Error Syncing JSON payload:', error));
		});


		var allowDelete = true; // admin: any backend user can delete, per earlier decision
		var csrfToken = '<?php echo \Joomla\CMS\Session\Session::getFormToken(); ?>';
		var currentEntryId = null;

		function ajaxUrl(task) {
			return 'index.php?option=com_sot&task=purchaseorders.' + task;
		}

	});
</script>
