/**
 * @version     CVS: 1.0.3
 * @package     com_sot
 * @copyright   2026 QA YOLO
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      QA YOLO <qa.yolotech@gmail.com>
 */
/**
 * SOT Summary + SOT Daily Tracker behaviour: auto-submitting filters, status tabs,
 * row click-through, period presets, collapsible cards and filters.
 */
(function () {
    'use strict';

    function pad(n) { return (n < 10 ? '0' : '') + n; }

    function toYmd(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }

    function parseYmd(s) {
        var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || '');
        return m ? new Date(+m[1], +m[2] - 1, +m[3]) : new Date();
    }

    function init() {
        // ---- searchable dropdowns (Choices.js, loaded by Joomla's "choicesjs" asset) ----
        if (typeof Choices !== 'undefined') {
            document.querySelectorAll('.sot select.js-choices').forEach(function (el) {
                new Choices(el, {
                    searchEnabled: true,
                    searchPlaceholderValue: '',
                    shouldSort: false,        // keep the order the server sent (model_id ascending)
                    itemSelectText: '',
                    allowHTML: false
                });
            });
        }
        
        // ---- filters submit on change ----
        document.querySelectorAll('.sot form[data-sot-autosubmit]').forEach(function (form) {
            form.addEventListener('change', function (e) {
                var t = e.target;

                // A new part invalidates the chosen model
                if (t.dataset && t.dataset.resets) {
                    var dep = form.elements[t.dataset.resets];
                    if (dep) { dep.value = '0'; }
                }

                // Picking your own dates makes it a custom range
                if ((t.name === 'from' || t.name === 'to') && form.elements.period) {
                    form.elements.period.value = 'date';
                }

                if (form.checkValidity()) { form.submit(); }
            });
        });

        // ---- period presets (daily view) ----
        document.querySelectorAll('.sot [data-period]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var form = btn.closest('form');
                var from = form.elements.from;
                var to = form.elements.to;
                var base = new Date();   // Year / Month / Week presets always start from today
                var p = btn.dataset.period;
                var a = parseYmd(from.value), b = parseYmd(to.value);

                if (p === 'year') {
                    a = new Date(base.getFullYear(), 0, 1);
                    b = new Date(base.getFullYear(), 11, 31);
                } else if (p === 'month') {
                    a = new Date(base.getFullYear(), base.getMonth(), 1);
                    b = new Date(base.getFullYear(), base.getMonth() + 1, 0);
                } else if (p === 'week') {
                    var shift = (base.getDay() + 6) % 7; // Monday first
                    a = new Date(base.getFullYear(), base.getMonth(), base.getDate() - shift);
                    b = new Date(a.getFullYear(), a.getMonth(), a.getDate() + 6);
                }

                from.value = toYmd(a);
                to.value = toYmd(b);
                form.elements.period.value = p;
                form.submit();
            });
        });

        // ---- year / month / week selectors (daily view) ----
        document.querySelectorAll('.sot [data-sot-range]').forEach(function (box) {
            var form = box.closest('form');
            var yearSel = box.querySelector('[data-range="year"]');
            var monthSel = box.querySelector('[data-range="month"]');
            var weekSel = box.querySelector('[data-range="week"]');

            function addDays(d, n) { return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n); }

            // Monday of ISO week `wk` in ISO year `y` (week 1 contains 4 Jan); falls back to week 52 if there is no week 53
            function isoWeekStart(y, wk) {
                var jan4 = new Date(y, 0, 4);
                var mon = addDays(jan4, -((jan4.getDay() + 6) % 7));
                var a = addDays(mon, 7 * (wk - 1));
                return addDays(a, 3).getFullYear() === y ? a : addDays(a, -7);
            }

            function setRange(a, b) {
                form.elements.from.value = toYmd(a);
                form.elements.to.value = toYmd(b);
            }

            // The form's own change handler runs after these and submits
            yearSel.addEventListener('change', function () {
                var y = +yearSel.value, p = form.elements.period.value;

                if (p === 'year') {
                    setRange(new Date(y, 0, 1), new Date(y, 11, 31));
                } else if (p === 'month') {
                    var m = +monthSel.value;
                    setRange(new Date(y, m - 1, 1), new Date(y, m, 0));
                } else {
                    // Keep the same week number in the new year
                    var opt = weekSel.options[weekSel.selectedIndex];
                    var a = isoWeekStart(y, opt ? +opt.dataset.week : 1);
                    setRange(a, addDays(a, 6));
                }
            });

            monthSel.addEventListener('change', function () {
                var y = +yearSel.value, m = +monthSel.value;
                setRange(new Date(y, m - 1, 1), new Date(y, m, 0));
            });

            weekSel.addEventListener('change', function () {
                var a = parseYmd(weekSel.value);
                setRange(a, addDays(a, 6));
            });

            // Month selector starts on the month of the From date
            var base = parseYmd(form.elements.from.value);
            monthSel.value = base.getMonth() + 1;
        });

        // ---- more / less filters (collapsed by default on phones) ----
        document.querySelectorAll('.sot [data-toggle-extra]').forEach(function (btn) {
            var panel = document.getElementById(btn.getAttribute('aria-controls'));
            var mobile = window.matchMedia('(max-width: 720px)');

            function setOpen(open) {
                btn.setAttribute('aria-expanded', open ? 'true' : 'false');
                btn.querySelector('span').textContent = open ? btn.dataset.less : btn.dataset.more;
                if (panel) {
                    panel.hidden = !open;
                    panel.classList.toggle('is-open', open);
                }
            }

            btn.addEventListener('click', function () {
                setOpen(btn.getAttribute('aria-expanded') !== 'true');
            });

            // Start collapsed on phones, open on larger screens
            setOpen(!mobile.matches);
        });

        // ---- collapsible cards ----
        document.querySelectorAll('.sot .sot-dcard-toggle').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var body = btn.closest('.sot-dcard').querySelector('.sot-dcard-body');
                var open = btn.getAttribute('aria-expanded') === 'true';

                btn.setAttribute('aria-expanded', open ? 'false' : 'true');
                if (body) { body.hidden = open; }
            });
        });

        // ---- summary: status tabs ----
        var tabs = document.querySelectorAll('.sot-summary .sot-tab');

        tabs.forEach(function (tab) {
            tab.addEventListener('click', function () {
                var f = tab.dataset.filter;
                var shown = 0;

                tabs.forEach(function (t) {
                    var on = t === tab;
                    t.classList.toggle('is-active', on);
                    t.setAttribute('aria-pressed', on ? 'true' : 'false');
                });

                document.querySelectorAll('.sot-summary .sot-group').forEach(function (group) {
                    var any = 0;

                    group.querySelectorAll('.sot-row').forEach(function (row) {
                        var ok = f === 'all' || row.dataset.status === f;
                        row.hidden = !ok;
                        if (ok) { any++; }
                    });

                    group.hidden = any === 0;
                    shown += any;
                });

                var empty = document.querySelector('.sot-summary [data-empty-tab]');
                if (empty) { empty.hidden = shown !== 0; }
            });
        });

        // ---- summary: whole row opens the daily view ----
        document.querySelectorAll('.sot-summary .sot-row[data-href]').forEach(function (row) {
            row.addEventListener('click', function (e) {
                if (e.target.closest('a')) { return; }
                window.location.href = row.dataset.href;
            });
        });

         // ---- clear filters: back to the page defaults (current year / month / week) ----
        document.querySelectorAll('.sot [data-clear-filters]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                window.location.href = btn.dataset.url;
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
