/**
 * Purchase order form: show daily_plan_qty = ceil(total_po / working_days)
 * live in every subform row. The server recalculates it on save, so this is
 * only a preview.
 */
(function () {
    'use strict';

    function recalc() {
        var wdInput = document.querySelector('[name$="[working_days]"]');
        var wd = wdInput ? parseInt(wdInput.value, 10) || 0 : 0;

        document.querySelectorAll('[name$="[total_po]"]').forEach(function (total) {
            var row = total.closest('tr, .subform-repeatable-group');
            var daily = row ? row.querySelector('[name$="[daily_plan_qty]"]') : null;

            if (!daily) {
                return;
            }

            var qty = parseInt(total.value, 10) || 0;
            daily.value = wd > 0 ? Math.ceil(qty / wd) : 0;
        });
    }

    document.addEventListener('input', function (e) {
        if (e.target.matches && e.target.matches('[name$="[working_days]"], [name$="[total_po]"]')) {
            recalc();
        }
    });
    document.addEventListener('subform-row-add', recalc);
    document.addEventListener('DOMContentLoaded', recalc);
})();
