<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Session\Session;
use Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Layout\LayoutHelper;

$canEdit = Factory::getApplication()->getIdentity()->authorise('core.edit', 'com_sot');

if (!$canEdit && Factory::getApplication()->getIdentity()->authorise('core.edit.own', 'com_sot')) {
	$canEdit = Factory::getApplication()->getIdentity()->id == $this->item->created_by;
}

// Import CSS
$wa = $this->document->getWebAssetManager();
$cssFile = JPATH_ROOT . '/media/com_sot/css/list.css';
$wa->registerAndUseStyle(
	'com_sot.list',
	Uri::root() . 'media/com_sot/css/list.css',
	['version' => (string) @filemtime($cssFile)]
);
?>

<div class="item_fields">
	<?php if ($this->params->get('show_page_heading')) : ?>
		<div class="page-header">
			<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
		</div>
	<?php endif; ?>

	<div class="header mb-4">
		<h1 class="header__title"><?php echo Text::_('COM_SOT_PURCHASEORDER_TITLE'); ?></h1>
	</div>

	<table class="table">

		<tr>
			<th><?php echo Text::_('COM_SOT_FORM_LBL_PURCHASEORDER_PO_NO'); ?></th>
			<td><?php echo $this->item->po_no; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_SOT_FORM_LBL_PURCHASEORDER_CREATED_DATE'); ?></th>
			<td> <?php
					$date = $this->item->created_date;
					echo $date > 0 ? HTMLHelper::_('date', $date, Text::_('DATE_FORMAT_LC1')) : '-';
					?>

			</td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_SOT_FORM_LBL_PURCHASEORDER_WORKING_DAYS'); ?></th>
			<td><?php echo (int) $this->item->working_days; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_SOT_FORM_LBL_PURCHASEORDER_DETAILS'); ?></th>
			<td>
				<?php if (!empty($this->item->details)) : ?>

					<table class="table table-striped table-sm">
						<thead>
							<tr>
								<th><?php echo Text::_('COM_SOT_FORM_LBL_PURCHASEORDER_PART'); ?></th>
								<th><?php echo Text::_('COM_SOT_FORM_LBL_PURCHASEORDER_MODEL'); ?></th>
								<th><?php echo Text::_('COM_SOT_FORM_LBL_PURCHASEORDER_TOTAL_PO'); ?></th>
								<th><?php echo Text::_('COM_SOT_FORM_LBL_PURCHASEORDER_DAILY_PLAN_QTY'); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ((array) $this->item->details as $row) : ?>
								<tr>
									<td><?php echo $this->escape($row['component_name']); ?></td>
									<td><?php echo $this->escape($row['model_name']); ?></td>
									<td><?php echo (int) $row['total_po']; ?></td>
									<td><?php echo (int) $row['daily_plan_qty']; ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else : ?>
					&#8212;
				<?php endif; ?>


			</td>
		</tr>

	</table>

</div>

<div class="button d-flex w-100 mb-3" style="padding-top: 10px; gap:3px">

	<!-- Delete button -->
	<?php if (Factory::getApplication()->getIdentity()->authorise('core.delete', 'com_sot.purchaseorder.' . $this->item->id)) : ?>

		<a class="btn btn-danger" rel="noopener noreferrer" href="#deleteModal" role="button" data-bs-toggle="modal">
			<?php echo Text::_("COM_SOT_DELETE_ITEM"); ?>
		</a>

		<?php echo HTMLHelper::_(
			'bootstrap.renderModal',
			'deleteModal',
			array(
				'title'  => Text::_('COM_SOT_DELETE_ITEM'),
				'height' => '50%',
				'width'  => '20%',

				'modalWidth'  => '50',
				'bodyHeight'  => '100',
				'footer' => '<button class="btn btn-outline-primary" data-bs-dismiss="modal">Close</button><a href="' . Route::_('index.php?option=com_sot&task=purchaseorder.remove&id=' . $this->item->id, false, 2) . '" class="btn btn-danger">' . Text::_('COM_SOT_DELETE_ITEM') . '</a>'
			),
			Text::sprintf('COM_SOT_DELETE_CONFIRM', $this->item->id)
		); ?>

	<?php endif; ?>

	<!-- Edit button -->
	<?php if ($canEdit): ?>
		<a class="btn btn-outline-primary" href="<?php echo Route::_('index.php?option=com_sot&task=purchaseorder.edit&id=' . $this->item->id); ?>"><?php echo Text::_("COM_SOT_EDIT_ITEM"); ?></a>
	<?php endif; ?>

	<!-- Done button -->
	<a class="btn btn-success ms-auto" href="<?php echo Route::_('index.php?option=com_sot&view=purchaseorders'); ?>">
		<i class="fas fa-check me-1"></i><?php echo Text::_("Done"); ?>
	</a>

</div>