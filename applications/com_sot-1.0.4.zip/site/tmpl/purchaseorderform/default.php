<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Sot\Component\Sot\Site\Helper\SotHelper;

$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
	->useScript('form.validate')
	->useScript('com_sot.po-form');
HTMLHelper::_('bootstrap.tooltip');

$cssFile = JPATH_ROOT . '/media/com_sot/css/list.css';
$wa->registerAndUseStyle(
	'com_sot.list',
	Uri::root() . 'media/com_sot/css/list.css',
	['version' => (string) @filemtime($cssFile)]
);

// Load admin language file
$lang = Factory::getLanguage();
$lang->load('com_sot', JPATH_SITE);

$user    = Factory::getApplication()->getIdentity();
$canEdit = SotHelper::canUserEdit($this->item, $user);

// Resolve the existing (single) selected IDs for the cascading fields, so we can
// re-populate & re-select the correct dependent options on page load (edit mode).
// component/model/vendor/remark may be stored as arrays (multi-value support),
// so just take the first value for the purpose of driving the cascade.
$existingComponentId = '';
if (isset($this->item->part)) {
	$componentVal = $this->item->part;
	$existingComponentId = is_array($componentVal) ? (reset($componentVal) ?: '') : $componentVal;
}

$existingModelId = '';
if (isset($this->item->model)) {
	$modelVal = $this->item->model;
	$existingModelId = is_array($modelVal) ? (reset($modelVal) ?: '') : $modelVal;
}

$norm = fn($v) => is_array($v) ? (string) (reset($v) ?: '') : (string) $v;

$existingRows = [];
foreach ((array) $this->item->details as $rowKey => $row) {
	$row = (object) $row;
	$existingRows[$rowKey] = [
		'part'  => $norm($row->part ?? ''),
		'model' => $norm($row->model ?? ''),
	];
}

// Adjust columns horizontally and force Choices.js dropdown container to expand
$this->document->addStyleDeclaration('
    /* 1. Allocate widths to the layout columns (Headers & Cells) */
    .options-form table th:nth-child(1),
    .options-form table td:nth-child(1) {
        width: 65% !important;
    }
    .options-form table th:nth-child(2),
    .options-form table td:nth-child(2) {
        width: 15% !important;
    }
    .options-form table th:nth-child(3),
    .options-form table td:nth-child(3) {
        width: 20% !important;
        text-align: center;
    }

    /* 2. FORCE Joomla wrappers and Choices.js to stretch to the 55% cell width */
    .options-form table td joomla-field-fancy-select,
    .options-form table td .choices,
    .options-form table td .choices__inner,
    .options-form table td select,
    .options-form table td input {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 100% !important;
        display: block !important;
        box-sizing: border-box !important;
    }

	.subform-repeatable .table-responsive {
    overflow-x: unset;
	}

	.subform-repeatable .choices__list--dropdown {
	max-height:unset;
	}
');
?>

<div class="purchaseorder-edit front-end-edit">

	<?php if ($this->params->get('show_page_heading')) : ?>
		<div class="page-header">
			<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
		</div>
	<?php endif; ?>
	<?php if (!$canEdit) : ?>
		<h3>
			<?php throw new \Exception(Text::_('COM_SOT_ERROR_MESSAGE_NOT_AUTHORISED'), 403); ?>
		</h3>
	<?php else : ?>
		<div class="header mb-4">
			<?php if (!empty($this->item->id)): ?>
				<h1 class="header__title"><?php echo Text::sprintf('COM_SOT_EDIT_ITEM_TITLE', $this->item->po_no); ?></h1>
			<?php else: ?>
				<h1 class="header__title"><?php echo Text::_('COM_SOT_ADD_ITEM_TITLE'); ?></h1>
			<?php endif; ?>
		</div>

		<form id="form-purchaseorder"
			action="<?php echo Route::_('index.php?option=com_sot&task=purchaseorderform.save'); ?>"
			method="post" class="form-validate form-horizontal" enctype="multipart/form-data">

			<input type="hidden" name="jform[id]" value="<?php echo isset($this->item->id) ? $this->item->id : ''; ?>" />

			<input type="hidden" name="jform[state]" value="<?php echo isset($this->item->state) ? $this->item->state : ''; ?>" />

			<?php echo $this->form->getInput('created_by'); ?>
			<?php echo $this->form->getInput('modified_by'); ?>
			<!-- <?php echo HTMLHelper::_('uitab.startTabSet', 'myTab', array('active' => 'sotdetail')); ?> -->
			<!-- <?php echo HTMLHelper::_('uitab.addTab', 'myTab', 'sotdetail', Text::_('COM_SOT_TAB_SOTDETAIL', true)); ?> -->

			<fieldset class="options-form mb-4">

				<legend class="border-bottom pb-2 mb-3"><?php echo Text::_('COM_SOT_TAB_SOTDETAIL'); ?></legend>

				<?php echo $this->form->renderField('po_no'); ?>
				<?php echo $this->form->renderField('created_date'); ?>
				<?php echo $this->form->renderField('working_days'); ?>

			</fieldset>
			<fieldset class="options-form mb-4">

				<?php echo $this->form->renderField('details'); ?>

			</fieldset>

			<!-- <?php echo HTMLHelper::_('uitab.endTab'); ?> -->
			<div class="control-group" style="margin-top: 1rem;">
				<div class="controls d-flex justify-content-end" style="gap: 3px;">

					<a class="btn btn-danger"
						href="<?php echo Route::_('index.php?option=com_sot&task=purchaseorderform.cancel'); ?>"
						title="<?php echo Text::_('JCANCEL'); ?>">
						<span class="fas fa-times" aria-hidden="true"></span>
						<?php echo Text::_('JCANCEL'); ?>
					</a>
					<?php if ($this->canSave): ?>
						<button type="submit" class="validate btn btn-primary">
							<span class="fas fa-check" aria-hidden="true"></span>
							<?php echo Text::_('JSUBMIT'); ?>
						</button>
					<?php endif; ?>
				</div>
			</div>

			<input type="hidden" name="option" value="com_sot" />
			<input type="hidden" name="task"
				value="purchaseorderform.save" />
			<?php echo HTMLHelper::_('form.token'); ?>
		</form>
	<?php endif; ?>
</div>

<script>
	document.addEventListener('DOMContentLoaded', function() {

		// Saved values per row, e.g. { details0: {part: "12", model: "5"}, details1: {...} }
		// Empty object on the Add form
		const existingRows = <?php echo json_encode($existingRows ?: new stdClass()); ?>;

		// Matches jform[details][details0][part] and captures "details0"
		const PART_NAME_RE = /^jform\[details\]\[([^\]]+)\]\[part\]$/;

		function getModelField(rowKey) {
			return document.querySelector(`select[name="jform[details][${rowKey}][model]"]`);
		}

		function populateModelField(rowKey, componentId, selectedModelId) {
			selectedModelId = selectedModelId || '';

			const modelField = getModelField(rowKey);
			if (!modelField) {
				console.error('Model select not found for row', rowKey);
				return;
			}

			const modelWrapper = modelField.closest('joomla-field-fancy-select');
			const choices = modelWrapper && modelWrapper.choicesInstance;

			modelField.innerHTML = '<option value="">Select Model</option>';

			if (choices) {
				choices.clearChoices();
				choices.setChoices([{
					value: '',
					label: 'Select Model',
					selected: true
				}], 'value', 'label', true);
			}

			checkDuplicateModels(); // <-- ADD (1): right after the Model select is cleared, before the early return

			if (!componentId) return;

			fetch(`index.php?option=com_sot&task=purchaseorderform.getModelsByComponent&component_id=${encodeURIComponent(componentId)}&format=json`)
				.then(r => r.json())
				.then(data => {
					if (!(data && data.success && data.data)) return;

					// Row may have been removed while the request was in flight
					const field = getModelField(rowKey);
					if (!field) return;

					data.data.forEach(model => {
						const option = new Option(model.value, model.key);
						if (String(model.key) === String(selectedModelId)) option.selected = true;
						field.add(option);
					});

					const wrapper = field.closest('joomla-field-fancy-select');
					if (wrapper && wrapper.choicesInstance) {
						wrapper.choicesInstance.setChoices(
							data.data.map(m => ({
								value: String(m.key),
								label: String(m.value),
								selected: String(m.key) === String(selectedModelId)
							})),
							'value', 'label', true
						);
					}
					checkDuplicateModels(); // <-- ADD (2): last line inside this .then, after the options have been added
				})
				.catch(err => console.error('Error syncing JSON payload:', err));
		}

		// --- Component -> Model cascade, works for every row (delegated) ---
		document.addEventListener('change', function(event) {
			const match = event.target.name && event.target.name.match(PART_NAME_RE);
			if (!match) return;
			populateModelField(match[1], event.target.value);
		});

		// --- Duplicate model check: the same Part + Model can only be used once per purchase order ---
		const MODEL_NAME_RE = /^jform\[details\]\[([^\]]+)\]\[model\]$/;
		const form = document.getElementById('form-purchaseorder');
		const submitBtn = form ? form.querySelector('button[type="submit"]') : null;

		function markInvalid(sel, on) {
			// Choices.js hides the real <select>, so mark its visible wrapper
			(sel.closest('.choices') || sel).classList.toggle('is-invalid', on);
		}

		function checkDuplicateModels() {
			const selects = Array.from(form.querySelectorAll('select')).filter(function(s) {
				return MODEL_NAME_RE.test(s.name);
			});
			const seen = {};
			const dupNames = [];

			selects.forEach(function(sel) {
				markInvalid(sel, false);
			});

			selects.forEach(function(sel) {
				const model = sel.value;
				if (!model) return;

				const rowKey = sel.name.match(MODEL_NAME_RE)[1];
				const partSel = form.querySelector('select[name="jform[details][' + rowKey + '][part]"]');
				const key = (partSel ? partSel.value : '') + '|' + model;

				if (seen[key]) {
					markInvalid(sel, true);
					markInvalid(seen[key], true);

					const opt = sel.options[sel.selectedIndex];
					const label = opt ? opt.text.trim() : model;
					if (dupNames.indexOf(label) === -1) dupNames.push(label);
				} else {
					seen[key] = sel;
				}
			});

			const hasDuplicate = dupNames.length > 0;
			let warning = document.getElementById('model-duplicate-warning');

			if (hasDuplicate) {
				if (!warning) {
					warning = document.createElement('div');
					warning.id = 'model-duplicate-warning';
					warning.className = 'alert alert-danger mt-2';
					(form.querySelector('.subform-repeatable') || form).closest('fieldset').appendChild(warning);
				}
				warning.textContent = <?php echo json_encode(Text::_('COM_SOT_ERROR_DUPLICATE_MODEL')); ?> + ' ' + dupNames.join(', ');
			} else if (warning) {
				warning.remove();
			}

			if (submitBtn) submitBtn.disabled = hasDuplicate;

			return !hasDuplicate;
		}

		document.addEventListener('change', function(e) {
			if (e.target.name && MODEL_NAME_RE.test(e.target.name)) checkDuplicateModels();
		});

		// Joomla fires this when the user removes a row
		document.addEventListener('subform-row-remove', function() {
			setTimeout(checkDuplicateModels, 0);
		});

		form.addEventListener('submit', function(e) {
			if (!checkDuplicateModels()) e.preventDefault();
		});

		// --- Edit mode: restore saved Model for each existing row ---
		Object.keys(existingRows).forEach(function(rowKey) {
			const row = existingRows[rowKey];
			if (row && row.part) {
				populateModelField(rowKey, row.part, row.model);
			}
		});

	});
</script>