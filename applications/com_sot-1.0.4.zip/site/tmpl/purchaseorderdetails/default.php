<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Layout\LayoutHelper;

HTMLHelper::_('bootstrap.tooltip');

$listOrder = $this->state->get('list.ordering');
$listDirn  = $this->state->get('list.direction');

// Import CSS
$wa = $this->document->getWebAssetManager();
$cssFile = JPATH_ROOT . '/media/com_sot/css/list.css';
$wa->registerAndUseStyle(
	'com_sot.list',
	Uri::root() . 'media/com_sot/css/list.css',
	['version' => (string) @filemtime($cssFile)]
);
?>

<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
	</div>
<?php endif; ?>

<div class="header mb-4">
	<h1 class="header__title"><?php echo Text::_('COM_SOT_PURCHASEORDERSDETAILS_TITLE'); ?></h1>
	<p class="header__subtitle"><?php echo Text::_('COM_SOT_PURCHASEORDERSDETAILS_SUBTITLE'); ?></p>
</div>

<form action="<?php echo htmlspecialchars(Uri::getInstance()->toString()); ?>" method="post"
	name="adminForm" id="adminForm">
	<?php if (!empty($this->filterForm)) {
		echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this));
	} ?>

	<div class="button d-flex justify-content-end w-100 mb-3 " style="padding: 10px 28px" ;>
		<!-- Back Button -->
		<a href="<?php echo Route::_('index.php?option=com_sot&view=purchaseorders'); ?>"
			class="btn btn-danger btn-small">
			<i class="icon-arrow-left"></i> <?php echo Text::_('Back'); ?>
		</a>
	</div>

	<div class="table-responsive">
		<table class="table table-striped" id="purchaseorderdetailList">
			<thead>
				<tr>
					<th><?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_PO_NO', 'a.po_no', $listDirn, $listOrder); ?></th>
					<th><?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_CREATED_DATE', 'a.created_date', $listDirn, $listOrder); ?></th>
					<!-- <th><?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_YEAR', 'a.year', $listDirn, $listOrder); ?></th> -->
					<!-- <th><?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_MONTH', 'a.month', $listDirn, $listOrder); ?></th> -->
					<th><?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_PART', 'a.part', $listDirn, $listOrder); ?></th>
					<th><?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_MODEL', 'a.model', $listDirn, $listOrder); ?></th>
					<th><?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_TOTAL_PO', 'a.total_po', $listDirn, $listOrder); ?></th>
					<th><?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_WORKING_DAYS', 'p.working_days'); ?></th>
					<th><?php echo HTMLHelper::_('searchtools.sort', 'COM_SOT_PURCHASEORDERS_DAILY_PLAN_QTY', 'a.daily_plan_qty', $listDirn, $listOrder); ?></th>
				</tr>
			</thead>
			<tfoot>
				<tr>
					<td colspan="8">
						<div class="pagination">
							<?php echo $this->pagination->getPagesLinks(); ?>
						</div>
					</td>
				</tr>
			</tfoot>
			<tbody>
				<?php foreach ($this->items as $i => $item) : ?>
					<tr class="row<?php echo $i % 2; ?>">
						<td>
							<a href="<?php echo Route::_('index.php?option=com_sot&view=purchaseorder&id=' . (int) $item->po_id); ?>">
								<?php echo $this->escape($item->po_no); ?></a>
						</td>
						<td><?php echo $item->created_date > 0 ? HTMLHelper::_('date', $item->created_date, Text::_('DATE_FORMAT_LC1')) : '-'; ?></td>
						<!-- <td><?php echo $item->year ? (int) $item->year : '-'; ?></td> -->
						<!-- <td><?php echo $item->month ? Text::_('COM_SOT_PURCHASEORDERS_MONTH_OPTION_' . (int) $item->month) : '-'; ?></td> -->
						<!-- <td><?php echo $this->escape($item->part); ?></td> -->
						<td><?php echo $this->escape($item->part_name); ?></td>
						<!-- <td><?php echo $this->escape($item->model); ?></td> -->
						<td><?php echo $this->escape($item->model_name); ?></td>
						<td><?php echo (int) $item->total_po; ?></td>
						<td><?php echo (int) $item->working_days; ?></td>
						<td><?php echo (int) $item->daily_plan_qty; ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="list[fullorder]" value="<?php echo $listOrder; ?> <?php echo $listDirn; ?>" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>