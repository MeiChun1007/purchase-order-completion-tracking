<?php

/**
 * SOT Daily Tracker: daily plan, incoming, outgoing and production by part and model.
 *
 * @version    CVS: 1.0.3
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use \Joomla\CMS\Uri\Uri;

$wa = $this->document->getWebAssetManager();

// Choices.js (shipped with Joomla): both the script and the stylesheet
$wa->useStyle('choicesjs');
$wa->useScript('choicesjs');

$cssFile = JPATH_ROOT . '/media/com_sot/css/report.css';
$wa->registerAndUseStyle(
	'com_sot.report',
	Uri::root() . 'media/com_sot/css/report.css',
	['version' => (string) @filemtime($cssFile)]
);

$jsFile = JPATH_ROOT . '/media/com_sot/js/report.js';
$wa->registerAndUseScript(
	'com_sot.report',
	Uri::root() . 'media/com_sot/js/report.js',
	['version' => (string) @filemtime($jsFile)],
	['defer' => true],
	['choicesjs']
);
$r      = $this->report;
$itemid = Factory::getApplication()->getInput()->getInt('Itemid', 0);
$base   = Route::_('index.php?option=com_sot&view=sotdaily');
$lang 	= Factory::getApplication()->getLanguage();

$num = static function ($v) {
	return number_format((int) $v);
};

/**
 * One metric cell. $kind: plain | bad (red when above zero) | vs (signed, green / red).
 */
$cell = static function ($v, $kind) use ($num) {
	if ($v === null) {
		return '<td class="num is-blank">&middot;</td>';
	}

	$v = (int) $v;

	if ($kind === 'vs') {
		$class = $v > 0 ? 'is-pos' : ($v < 0 ? 'is-neg' : 'is-zero');

		return '<td class="num ' . $class . '">' . ($v > 0 ? '+' : '') . $num($v) . '</td>';
	}

	$class = $v === 0 ? 'is-zero' : ($kind === 'bad' ? 'is-bad' : '');

	return '<td class="num ' . $class . '">' . $num($v) . '</td>';
};

// Group => rows (metric key, kind)
$layout = array(
	'PLAN'       => array('plan' => 'plain'),
	'VS_PLAN'    => array('in_vs' => 'vs', 'fg_vs' => 'vs', 'sort_vs' => 'vs'),
	'INCOMING'   => array('wo' => 'plain', 'pr' => 'plain'),
	'OUTGOING'   => array('fg' => 'plain', 'nc' => 'bad', 'scrap' => 'bad'),
	'PRODUCTION' => array('sort' => 'plain', 'pnc' => 'bad', 'accepted' => 'plain'),
	'BALANCE'    => array('bal_wip' => 'plain', 'bal_fg' => 'plain', 'bal_nc' => 'bad'),
);

$periods = array(
	'year'  => 'COM_SOT_REPORT_PERIOD_YEAR',
	'month' => 'COM_SOT_REPORT_PERIOD_MONTH',
	'week'  => 'COM_SOT_REPORT_PERIOD_WEEK',
	'date'  => 'COM_SOT_REPORT_PERIOD_DATE',
);

$colCount = count($r['buckets']);
?>
<div class="sot sot-daily">
	<header class="sot-head">
		<h1><?php echo $this->escape($this->heading); ?></h1>
		<p><?php echo Text::_('COM_SOT_REPORT_SUBTITLE_DAILY'); ?></p>
	</header>

	<form class="sot-filters sot-filters-daily" method="get" action="<?php echo $this->escape($base); ?>" data-sot-autosubmit>
		<input type="hidden" name="option" value="com_sot">
		<input type="hidden" name="view" value="sotdaily">
		<?php if ($itemid) : ?><input type="hidden" name="Itemid" value="<?php echo (int) $itemid; ?>"><?php endif; ?>
		<input type="hidden" name="period" value="<?php echo $this->escape($r['period']); ?>">

		<div class="selectors row">
			<div class="selector col-md-4">
				<div class="sot-field sot-period">
					<label><?php echo Text::_('COM_SOT_REPORT_PERIOD'); ?></label>
					<div class="sot-seg" role="group" aria-label="<?php echo Text::_('COM_SOT_REPORT_PERIOD'); ?>">
						<?php foreach ($periods as $key => $label) : ?>
							<button type="button" class="sot-seg-btn<?php echo $r['period'] === $key ? ' is-active' : ''; ?>" data-period="<?php echo $key; ?>" aria-pressed="<?php echo $r['period'] === $key ? 'true' : 'false'; ?>"><?php echo Text::_($label); ?></button>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
			<?php
			$fYear  = $r['period'] === 'week' ? (int) $r['iso_year'] : (int) substr($r['from'], 0, 4);
			$years  = array_unique(array_merge(range($tYear - 4, $tYear + 1), array($fYear)));
			$years  = array_unique(array_merge(range($tYear - 4, $tYear + 1), array($fYear)));
			sort($years);
			$shown  = static function (array $periods) use ($r) {
				return in_array($r['period'], $periods, true) ? '' : ' hidden';
			};
			$monthShort = array();
			for ($m = 1; $m <= 12; $m++) {
				$monthShort[] = Text::_(strtoupper(date('F', mktime(0, 0, 0, $m, 1))) . '_SHORT');
			}
			?>
			<div class="selector col-md-4" style="display: grid; align-content: center;">

				<div class="sot-range" data-sot-range
					data-months-by-year="<?php echo $this->escape(json_encode($r['months_by_year'])); ?>">
					<!-- Year: shown for Year, Month and Week -->
					<div class="sot-field" <?php echo $shown(array('year', 'month', 'week')); ?>>
						<label for="sot_year"><?php echo Text::_('COM_SOT_REPORT_FILTER_YEAR'); ?></label>
						<select id="sot_year" class="form-select" data-range="year">
							<?php foreach ($r['years'] as $y) : ?>
								<option value="<?php echo (int) $y; ?>" <?php echo $y == $fYear ? ' selected' : ''; ?>><?php echo (int) $y; ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<!-- Month: Month only -->
					<div class="sot-field" <?php echo $shown(array('month')); ?>>
						<label for="sot_month"><?php echo Text::_('COM_SOT_REPORT_FILTER_MONTH'); ?></label>
						<select id="sot_month" class="form-select" data-range="month">
							<?php foreach ($r['months'] as $m) : ?>
								<option value="<?php echo (int) $m; ?>" <?php echo $m === (int) substr($r['from'], 5, 2) ? ' selected' : ''; ?>><?php echo Text::_('COM_SOT_PURCHASEORDERS_MONTH_OPTION_' . $m); ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<!-- Week: Week only -->
					<div class="sot-field" <?php echo $shown(array('week')); ?>>
						<label for="sot_week"><?php echo Text::_('COM_SOT_REPORT_FILTER_WEEK'); ?></label>
						<select id="sot_week" class="form-select" data-range="week">
							<?php foreach ($r['week_options'] as $w) : ?>
								<option value="<?php echo $this->escape($w->value); ?>" data-week="<?php echo (int) $w->week; ?>" <?php echo $w->value === $r['week_start'] ? ' selected' : ''; ?>>
									<?php echo $this->escape($w->label); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>

					<!-- Date: From / To (the real from/to fields; the other modes fill them) -->
					<div class="sot-field" <?php echo $shown(array('date')); ?>>
						<label for="sot_from"><?php echo Text::_('COM_SOT_REPORT_FROM'); ?></label>
						<input type="date" id="sot_from" name="from" value="<?php echo $this->escape($r['from']); ?>" required>
					</div>
					<div class="sot-field" <?php echo $shown(array('date')); ?>>
						<label for="sot_to"><?php echo Text::_('COM_SOT_REPORT_TO'); ?></label>
						<input type="date" id="sot_to" name="to" value="<?php echo $this->escape($r['to']); ?>" required>
					</div>
				</div>
			</div>
		</div>


		<div class="sot-extra" id="sot-extra">
			<div class="selectors row">
				<div class="sot-field col-md-3">
					<label for="sot_part"><?php echo Text::_('COM_SOT_REPORT_FILTER_PART'); ?></label>
					<select name="part" id="sot_part" data-resets="model" class="form-select">
						<option value="0"><?php echo Text::_('COM_SOT_REPORT_FILTER_ALL_PARTS'); ?></option>
						<?php foreach ($r['options']['parts'] as $id => $name) : ?>
							<option value="<?php echo (int) $id; ?>" <?php echo $id == $r['part_id'] ? ' selected' : ''; ?>><?php echo $this->escape($name); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="sot-field col-md-3">
					<label for="sot_model"><?php echo Text::_('COM_SOT_REPORT_FILTER_MODEL'); ?></label>
					<select name="model" id="sot_model" class="form-select js-choices">
						<option value="0"><?php echo Text::_('COM_SOT_REPORT_FILTER_ALL_MODELS'); ?></option>
						<?php foreach ($r['options']['models'] as $id => $name) : ?>
							<option value="<?php echo (int) $id; ?>" <?php echo $id == $r['model_id'] ? ' selected' : ''; ?>><?php echo $this->escape($name); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>

			<div class="row mb-4">
				<div class="col-md-12 text-end">
					<button type="button" id="btn-clear-filters" class="btn btn-link btn-sm text-muted sot-clear"
						data-clear-filters data-url="<?php echo $this->escape($base); ?>">
						<span class="icon-undo" aria-hidden="true"></span>
						<?php echo Text::_('COM_SOT_REPORT_FILTER_CLEAR'); ?>
					</button>
				</div>

			</div>

		</div>

		<div class="filter-toggle-row">
			<button type="button" class="sot-morefilters" data-toggle-extra aria-expanded="true" aria-controls="sot-extra"
				data-less="<?php echo $this->escape(Text::_('COM_SOT_REPORT_FILTER_LESS')); ?>" data-more="<?php echo $this->escape(Text::_('COM_SOT_REPORT_FILTER_MORE')); ?>">
				<span><?php echo Text::_('COM_SOT_REPORT_FILTER_LESS'); ?></span>
				<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true">
					<path d="M3 10l5-5 5 5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
				</svg>
			</button>
		</div>

		<noscript><button type="submit" class="sot-btn"><?php echo Text::_('COM_SOT_REPORT_FILTER_APPLY'); ?></button></noscript>
	</form>

	<?php if ($r['clamped']) : ?>
		<div class="sot-note" role="status"><?php echo Text::_('COM_SOT_REPORT_RANGE_CLAMPED'); ?></div>
	<?php endif; ?>

	<?php if ($r['unmatched']) : ?>
		<div class="sot-note sot-note-warn" role="alert">
			<?php echo Text::sprintf('COM_SOT_REPORT_UNMATCHED', $this->escape(implode('; ', $r['unmatched']))); ?>
		</div>
	<?php endif; ?>

	<?php if (!$r['cards']) : ?>
		<p class="sot-empty"><?php echo Text::_('COM_SOT_REPORT_NO_DATA'); ?></p>
	<?php endif; ?>

	<?php if ($r['cards']) : ?>
		<!-- <p class="sot-legend"><?php echo Text::_('COM_SOT_REPORT_DAILY_LEGEND'); ?></p> -->
		<div class="sot-daily-bar">
			<details class="sot-help">
				<summary><?php echo Text::_('COM_SOT_REPORT_NOTE_TITLE'); ?></summary>
				<ul>
					<?php foreach (array('PLAN', 'VS_PLAN', 'INCOMING', 'OUTGOING', 'PRODUCTION', 'BALANCE') as $k) : ?>
						<li>
							<strong><?php echo Text::_('COM_SOT_REPORT_GROUP_' . $k); ?></strong>
							<span><?php echo Text::_('COM_SOT_REPORT_NOTE_' . $k); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			</details>
			<a class="btn btn-sm btn-outline-secondary sot-export"
				href="<?php echo $this->escape(Uri::root() . 'index.php?option=com_ajax&plugin=export&group=ajax&format=raw&type=SotDaily'
							. '&period=' . $r['period'] . '&from=' . $r['from'] . '&to=' . $r['to']
							. '&part=' . (int) $r['part_id'] . '&model=' . (int) $r['model_id']); ?>">
				<span class="icon-upload" aria-hidden="true"></span> <?php echo Text::_('COM_SOT_REPORT_EXPORT'); ?>
			</a>
		</div>
	<?php endif; ?>

	<?php foreach ($r['cards'] as $card) : ?>
		<section class="sot-dcard tone-<?php echo (int) ($card['tone'] % 6); ?>">
			<header class="sot-dcard-head">
				<button type="button" class="sot-dcard-toggle" aria-expanded="true" aria-label="<?php echo Text::_('COM_SOT_REPORT_CARD_TOGGLE'); ?>">
					<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true">
						<path d="M4 6l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
					</svg>
				</button>
				<h2><?php echo $this->escape($card['model']); ?></h2>
				<span class="sot-chip"><?php echo $this->escape($card['part']); ?></span>
				<?php if ($card['po_no'] !== '') : ?><span class="sot-pono"><?php echo $this->escape($card['po_no']); ?></span><?php endif; ?>
				<span class="sot-dcard-po"><?php echo Text::_('COM_SOT_REPORT_COL_TOTAL_PO'); ?> <strong><?php echo $num($card['total_po']); ?></strong></span>
			</header>

			<div class="sot-dcard-body">
				<div class="sot-scroll sot-scroll-wide">
					<table class="sot-table sot-daytable">
						<thead>
							<tr>
								<th class="c-group"><?php echo Text::_('COM_SOT_REPORT_COL_GROUP'); ?></th>
								<th class="c-metric"><?php echo Text::_('COM_SOT_REPORT_COL_METRIC'); ?></th>
								<th class="c-total num"><?php echo Text::_('COM_SOT_REPORT_COL_TOTAL'); ?></th>
								<th class="c-carry num"><?php echo Text::_('COM_SOT_REPORT_COL_CARRIED_OVER'); ?></th>
								<?php foreach ($r['buckets'] as $b) :
									$dt = new DateTimeImmutable($b['start']);

									if ($r['gran'] === 'month') {
										$top = Text::_(strtoupper($dt->format('F')) . '_SHORT');
										$sub = $dt->format('Y');
									} else {
										$top = $dt->format('d') . ' ' . Text::_(strtoupper($dt->format('F')) . '_SHORT');
										$sub = $b['off'] ? Text::_('COM_SOT_REPORT_OFF') : Text::_(strtoupper($dt->format('D')));
									}
								?>
									<th class="c-day num<?php echo $b['off'] ? ' is-off' : ''; ?>" <?php echo $b['note'] !== '' ? ' title="' . $this->escape($b['note']) . '"' : ''; ?>>
										<?php echo $this->escape($top); ?><small><?php echo $this->escape($sub); ?></small>
									</th>
								<?php endforeach; ?>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($layout as $group => $metrics) :
								$first = true;

								foreach ($metrics as $metric => $kind) : ?>
									<tr class="m-<?php echo $metric; ?><?php echo $first ? ' is-first' : ''; ?>">
										<?php if ($first) : ?>
											<th class="c-group" rowspan="<?php echo count($metrics); ?>" scope="rowgroup"><?php echo Text::_('COM_SOT_REPORT_GROUP_' . $group); ?></th>
										<?php endif; ?>
										<?php
										$tipKey = 'COM_SOT_REPORT_TIP_' . strtoupper($metric);
										$tip    = $lang->hasKey($tipKey) ? Text::_($tipKey) : '';
										?>
										<th class="c-metric<?php echo $tip !== '' ? ' has-tip' : ''; ?>" scope="row" <?php echo $tip !== '' ? ' title="' . $this->escape($tip) . '" tabindex="0" data-tip="' . $this->escape($tip) . '"' : ''; ?>>
											<?php echo Text::_('COM_SOT_REPORT_METRIC_' . strtoupper($metric)); ?>
										</th>
										<?php
										echo str_replace('<td class="num', '<td class="c-total num', $cell($card['totals'][$metric], $kind));
										echo str_replace('<td class="num', '<td class="c-carry num', $cell($card['carry'][$metric] ?? null, $kind));
										
										foreach ($r['buckets'] as $b) {
											echo $cell($card['series'][$metric][$b['key']], $kind);
										}
										?>
									</tr>
									<?php $first = false; ?>
								<?php endforeach; ?>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</section>
	<?php endforeach; ?>
</div>