<?php

/**
 * SOT Summary: progress of each PO by part and model.
 *
 * @version    CVS: 1.0.3
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use \Joomla\CMS\Uri\Uri;

$wa = $this->document->getWebAssetManager();
$wa->useStyle('com_sot.report')->useScript('com_sot.report');

$cssFile = JPATH_ROOT . '/media/com_sot/css/report.css';
$wa->registerAndUseStyle(
	'com_sot.report',
	Uri::root() . 'media/com_sot/css/report.css',
	['version' => (string) @filemtime($cssFile)]
);

$jsFile = JPATH_ROOT . '/media/com_sot/js/report.js';
$wa->registerAndUseScript(
	'com_sot.report',
	Uri::root() . 'media/com_sot/js/report.js',
	['version' => (string) @filemtime($jsFile)],
	['defer' => true],
	['choicesjs']          // dependency: Choices must load before report.js
);

$r      = $this->report;
$itemid = Factory::getApplication()->getInput()->getInt('Itemid', 0);
$base   = Route::_('index.php?option=com_sot&view=sotsummary');

$num    = static function ($v) {
	return number_format((int) $v);
};
$signed = static function ($v) {
	return ((int) $v > 0 ? '+' : '') . number_format((int) $v);
};
$cls    = static function ($v) {
	return (int) $v > 0 ? 'is-pos' : ((int) $v < 0 ? 'is-neg' : 'is-zero');
};
$fmtDay = static function ($ymd) {
	$d = new DateTimeImmutable($ymd);

	return $d->format('j') . ' ' . Text::_(strtoupper($d->format('F')) . '_SHORT') . ' ' . $d->format('Y');
};

// Header lines
if (in_array($r['mode'], array('live', 'asof'), true)) {
	$asOfText = Text::sprintf('COM_SOT_REPORT_ASOF_TODAY', $fmtDay($r['as_of']));
	$progress = Text::sprintf('COM_SOT_REPORT_WORKING_DAY_PROGRESS', $r['elapsed'], $r['working_days'], $r['days_left']);
} elseif ($r['mode'] === 'final') {
	$asOfText = Text::sprintf('COM_SOT_REPORT_ASOF_MONTHEND', $fmtDay($r['as_of']));
	$progress = Text::sprintf('COM_SOT_REPORT_FINAL_RESULT', $r['working_days']);
} else {
	$asOfText = Text::sprintf('COM_SOT_REPORT_ASOF_UPCOMING', $fmtDay($r['first']));
	$progress = Text::sprintf('COM_SOT_REPORT_NOT_STARTED', $r['working_days']);
}

$statusLabel = array(
	'behind'   => Text::_('COM_SOT_REPORT_STATUS_BEHIND'),
	'on_track' => Text::_('COM_SOT_REPORT_STATUS_ON_TRACK'),
	'closed'   => Text::_('COM_SOT_REPORT_STATUS_CLOSED'),
	'no_po'    => Text::_('COM_SOT_REPORT_STATUS_NO_PO'),
);

$lang = Factory::getApplication()->getLanguage();

// key suffix => css class
$cols = array(
	'MODEL'        => 'col-model',
	'TOTAL_PO'     => 'num',
	'PLAN_TO_DATE' => 'num',
	'INCOMING'     => 'num',
	'OUTGOING_FG'  => 'num',
	'SUBCON_DIFF'  => 'num',
	'BAL_PO'       => 'num',
	'BAL_WIP'      => 'num',
	'BAL_FG'       => 'num',
	'BAL_NC'       => 'num',
	'NEED_PER_DAY' => 'num',
	'STATUS'       => 'col-status',
);
?>
<div class="sot sot-summary">
	<header class="sot-head">
		<h1><?php echo $this->escape($this->heading); ?></h1>
		<p><?php echo Text::_('COM_SOT_REPORT_SUBTITLE_SUMMARY'); ?></p>
	</header>

	<form class="sot-filters" method="get" action="<?php echo $this->escape($base); ?>" data-sot-autosubmit>
		<input type="hidden" name="option" value="com_sot">
		<input type="hidden" name="view" value="sotsummary">
		<?php if ($itemid) : ?><input type="hidden" name="Itemid" value="<?php echo (int) $itemid; ?>"><?php endif; ?>

		<div class="selectors row">
			<div class="sot-field col-md-3">
				<label for="sot_year"><?php echo Text::_('COM_SOT_REPORT_FILTER_YEAR'); ?></label>
				<select name="year" id="sot_year" class="form-select">
					<?php foreach ($r['years'] as $y) : ?>
						<option value="<?php echo (int) $y; ?>" <?php echo $y == $r['year'] ? ' selected' : ''; ?>><?php echo (int) $y; ?></option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="sot-field col-md-3">
				<label for="sot_month"><?php echo Text::_('COM_SOT_REPORT_FILTER_MONTH'); ?></label>
				<select name="month" id="sot_month" class="form-select">
					<?php foreach ($r['months'] as $m) : ?>
						<option value="<?php echo (int) $m; ?>" <?php echo $m == $r['month'] ? ' selected' : ''; ?>><?php echo Text::_('COM_SOT_PURCHASEORDERS_MONTH_OPTION_' . $m); ?></option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="sot-field col-md-3">
				<label for="sot_part"><?php echo Text::_('COM_SOT_REPORT_FILTER_PART'); ?></label>
				<select name="part" id="sot_part" class="form-select js-choices" data-resets="model">
					<option value="0"><?php echo Text::_('COM_SOT_REPORT_FILTER_ALL_PARTS'); ?></option>
					<?php foreach ($r['options']['parts'] as $id => $name) : ?>
						<option value="<?php echo (int) $id; ?>" <?php echo $id == $r['part_id'] ? ' selected' : ''; ?>><?php echo $this->escape($name); ?></option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="sot-field col-md-3">
				<label for="sot_model"><?php echo Text::_('COM_SOT_REPORT_FILTER_MODEL'); ?></label>
				<select name="model" id="sot_model" class="form-select js-choices">
					<option value="0"><?php echo Text::_('COM_SOT_REPORT_FILTER_ALL_MODELS'); ?></option>
					<?php foreach ($r['options']['models'] as $id => $name) : ?>
						<option value="<?php echo (int) $id; ?>" <?php echo $id == $r['model_id'] ? ' selected' : ''; ?>><?php echo $this->escape($name); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>

		<noscript><button type="submit" class="sot-btn"><?php echo Text::_('COM_SOT_REPORT_FILTER_APPLY'); ?></button></noscript>
		<div class="row mb-4">
			<div class="col-md-12 text-end" style="padding: 0 30px;">
				<button type="button" id="btn-clear-filters" class="btn btn-link btn-sm text-muted sot-clear"
					data-clear-filters data-url="<?php echo $this->escape($base); ?>">
					<span class="icon-undo" aria-hidden="true"></span>
					<?php echo Text::_('COM_SOT_REPORT_FILTER_CLEAR'); ?>
				</button>
			</div>

		</div>

		<!-- <div class="sot-asof">
		<strong><?php echo $this->escape($asOfText); ?></strong>
		<span><?php echo $this->escape($progress); ?></span>
	</div> -->

		<?php
		$badge = $r['mode'] === 'live' ? Text::_('COM_SOT_REPORT_ASOF_BADGE_TODAY')
			: ($r['mode'] === 'final' ? Text::_('COM_SOT_REPORT_ASOF_BADGE_MONTHEND') : '');
		$resetUrl = Route::_('index.php?option=com_sot&view=sotsummary&year=' . (int) $r['year'] . '&month=' . (int) $r['month']
			. '&part=' . (int) $r['part_id'] . '&model=' . (int) $r['model_id']);
		?>
		<div class="sot-asof">
			<div class="sot-asof-field">
				<label class="col-md-1" for="sot_asof"><?php echo Text::_('COM_SOT_REPORT_ASOF_LABEL'); ?></label>
				<input type="date" id="sot_asof" name="as_of"
					value="<?php echo $this->escape($r['as_of_input']); ?>"
					min="<?php echo $this->escape($r['first']); ?>" max="<?php echo $this->escape($r['last']); ?>" required>

				<div class="sot-asof-badge col-md-2">
					<?php if ($badge !== '') : ?><span class="sot-badge"><?php echo $this->escape($badge); ?></span><?php endif; ?>
					<?php if ($r['mode'] === 'asof') : ?>
						<a class="btn btn-link btn-sm text-muted" href="<?php echo $this->escape($resetUrl); ?>">
							<span class="icon-undo" aria-hidden="true"></span> <?php echo Text::_('COM_SOT_REPORT_ASOF_RESET'); ?>
						</a>
					<?php endif; ?>
				</div>

				<div class="sot-asof-progress col-md-6">
					<span><?php echo $this->escape($progress); ?></span>
				</div>


			</div>

			<div class="sot-asof-export text-end" style="padding: 0 24px;">
				<a class="btn btn-sm btn-outline-secondary"
					href="<?php echo $this->escape(Uri::root() . 'index.php?option=com_ajax&plugin=export&group=ajax&format=raw&type=SotSummary'
								. '&year=' . (int) $r['year'] . '&month=' . (int) $r['month'] . '&as_of=' . $r['as_of_input']
								. '&part=' . (int) $r['part_id'] . '&model=' . (int) $r['model_id']); ?>">
					<span class="icon-upload" aria-hidden="true"></span> <?php echo Text::_('COM_SOT_REPORT_EXPORT'); ?>
				</a>
			</div>

		</div>
	</form>


	<?php if ($r['unmatched']) : ?>
		<div class="sot-note sot-note-warn" role="alert">
			<?php echo Text::sprintf('COM_SOT_REPORT_UNMATCHED', $this->escape(implode('; ', $r['unmatched']))); ?>
		</div>
	<?php endif; ?>

	<section class="sot-card">
		<div class="sot-tabs" role="group" aria-label="<?php echo Text::_('COM_SOT_REPORT_COL_STATUS'); ?>">
			<button type="button" class="sot-tab is-active" data-filter="all" aria-pressed="true"><?php echo Text::sprintf('COM_SOT_REPORT_TAB_ALL', $r['counts']['all']); ?></button>
			<button type="button" class="sot-tab" data-filter="on_track" aria-pressed="false"><?php echo Text::sprintf('COM_SOT_REPORT_TAB_ON_TRACK', $r['counts']['on_track']); ?></button>
			<button type="button" class="sot-tab" data-filter="behind" aria-pressed="false"><?php echo Text::sprintf('COM_SOT_REPORT_TAB_BEHIND', $r['counts']['behind']); ?></button>
			<button type="button" class="sot-tab" data-filter="closed" aria-pressed="false"><?php echo Text::sprintf('COM_SOT_REPORT_TAB_CLOSED', $r['counts']['closed']); ?></button>
			<button type="button" class="sot-tab" data-filter="no_po" aria-pressed="false"><?php echo Text::sprintf('COM_SOT_REPORT_TAB_NO_PO', $r['counts']['no_po']); ?></button>
		</div>

		<?php if (!$r['groups']) : ?>
			<p class="sot-empty"><?php echo Text::_('COM_SOT_REPORT_NO_DATA'); ?></p>
		<?php else : ?>
			<div class="sot-scroll">
				<table class="sot-table sot-sumtable" id="sotSummary">
					<thead>
						<tr>
							<?php foreach ($cols as $key => $class) :
								$tipKey = 'COM_SOT_REPORT_TIP_COL_' . $key;
								$tip    = $lang->hasKey($tipKey) ? Text::_($tipKey) : '';
							?>
								<th class="<?php echo $class . ($tip !== '' ? ' has-tip' : ''); ?>" <?php echo $tip !== '' ? ' tabindex="0" data-tip="' . $this->escape($tip) . '"' : ''; ?>><?php echo Text::_('COM_SOT_REPORT_COL_' . $key); ?></th>
							<?php endforeach; ?>
						</tr>
					</thead>
					<?php foreach ($r['groups'] as $gi => $g) : ?>
						<tbody class="sot-group">
							<tr class="sot-grouprow tone-<?php echo (int) ((isset($g['tone']) ? $g['tone'] : $gi) % 6); ?>">
								<th colspan="12"><span class="sot-group-label"><?php echo $this->escape($g['part']); ?></span></th>
							</tr>
							<?php foreach ($g['rows'] as $row) :
								$href = Route::_(
									'index.php?option=com_sot&view=sotdaily&period=date&from=' . $r['first'] . '&to=' . $r['link_to']
										. '&part=' . (int) $row['part_id'] . '&model=' . (int) $row['model_id']
								);
							?>
								<tr class="sot-row" data-status="<?php echo $this->escape($row['status']); ?>" data-href="<?php echo $this->escape($href); ?>">
									<td class="col-model">
										<a class="sot-model" href="<?php echo $this->escape($href); ?>" title="<?php echo Text::_('COM_SOT_REPORT_OPEN_DAILY'); ?>"><?php echo $this->escape($row['model']); ?></a>
										<?php if ($row['po_no'] !== '') : ?><span class="sot-pono"><?php echo $this->escape($row['po_no']); ?></span><?php endif; ?>
										<div class="sot-bar" role="img" aria-label="<?php echo $this->escape($row['model']); ?>: <?php echo $num($row['fg']); ?> / <?php echo $num($row['total_po']); ?>">
											<span class="sot-bar-fill" style="width:<?php echo (float) $row['fg_pct']; ?>%"></span>
											<?php if ($row['status'] !== 'closed' && $row['plan_pct'] > 0) : ?>
												<i class="sot-bar-tick" style="left:<?php echo (float) $row['plan_pct']; ?>%"></i>
											<?php endif; ?>
										</div>
										<?php if ($row['carry_lost'] > 0) : ?>
											<span class="sot-carry"><?php echo Text::sprintf('COM_SOT_REPORT_NOT_CARRIED_OVER', $num($row['carry_lost'])); ?></span>
										<?php endif; ?>
									</td>
									<td class="num strong"><?php echo $num($row['total_po']); ?></td>
									<td class="num"><?php echo $num($row['plan_to_date']); ?></td>
									<td class="num"><?php echo $num($row['incoming']); ?></td>
									<td class="num"><?php echo $num($row['fg']); ?></td>
									<td class="num <?php echo $cls($row['subcon_diff']); ?>"><?php echo $signed($row['subcon_diff']); ?></td>
									<td class="num strong"><?php echo $num($row['balance']); ?></td>
									<td class="num <?php echo $cls($row['bal_wip']); ?>"><?php echo $signed($row['bal_wip']); ?></td>
									<td class="num <?php echo $cls($row['bal_fg']); ?>"><?php echo $signed($row['bal_fg']); ?></td>
									<td class="num <?php echo $cls($row['bal_nc']); ?>"><?php echo  $signed($row['bal_nc']); ?></td>
									<td class="num"><?php echo $row['need_per_day'] === null ? '-' : $num($row['need_per_day']); ?></td>
									<td class="col-status">
										<span class="sot-pill sot-pill-<?php echo $this->escape($row['status']); ?>"><?php echo $statusLabel[$row['status']]; ?></span>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					<?php endforeach; ?>
				</table>
				<p class="sot-empty" data-empty-tab hidden><?php echo Text::_('COM_SOT_REPORT_NO_MATCH_TAB'); ?></p>
			</div>
		<?php endif; ?>

		<p class="sot-legend"><?php echo Text::_('COM_SOT_REPORT_SUMMARY_LEGEND'); ?></p>
	</section>
</div>