<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Layout\LayoutHelper;
use \Joomla\CMS\Session\Session;
use \Joomla\CMS\User\UserFactoryInterface;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');

$user       = Factory::getApplication()->getIdentity();
$userId     = $user->get('id');
$listOrder  = $this->state->get('list.ordering');
$listDirn   = $this->state->get('list.direction');
$canCreate  = $user->authorise('core.create', 'com_sot') && file_exists(JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'purchaseorderform.xml');
$canEdit    = $user->authorise('core.edit', 'com_sot') && file_exists(JPATH_COMPONENT .  DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'purchaseorderform.xml');
$canCheckin = $user->authorise('core.manage', 'com_sot');
$canChange  = $user->authorise('core.edit.state', 'com_sot');
$canDelete  = $user->authorise('core.delete', 'com_sot');

// Import CSS
$wa = $this->document->getWebAssetManager();
// $wa->useStyle('com_sot.list');
$cssFile = JPATH_ROOT . '/media/com_sot/css/list.css';
$wa->registerAndUseStyle(
	'com_sot.list',
	Uri::root() . 'media/com_sot/css/list.css',
	['version' => (string) @filemtime($cssFile)]
);
?>

<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
	</div>
<?php endif; ?>

<div class="header mb-4">
	<h1 class="header__title"><?php echo Text::_('COM_SOT_PURCHASEORDERS_TITLE'); ?></h1>
	<p class="header__subtitle"><?php echo Text::_('COM_SOT_PURCHASEORDERS_SUBTITLE'); ?></p>
</div>

<form action="<?php echo htmlspecialchars(Uri::getInstance()->toString()); ?>" method="post"
	name="adminForm" id="adminForm">
	<?php if (!empty($this->filterForm)) {
		echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this));
	} ?>

	<div class="button d-flex justify-content-end w-100 mb-3 " style="padding: 10px 28px; gap: 8px" ;>

		<?php if ($canCreate) : ?>
			<a href="<?php echo Route::_('index.php?option=com_sot&task=purchaseorderform.edit&id=0', false, 0); ?>"
				class="btn btn-success btn-small"><i
					class="icon-plus"></i>
				<?php echo Text::_('COM_SOT_ADD_ITEM'); ?></a>
		<?php endif; ?>

	</div>

	<div class="table-responsive">
		<table class="table table-striped" id="purchaseorderList">
			<thead>
				<tr>

					<!-- <th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_SOT_PURCHASEORDERS_ID', 'a.id', $listDirn, $listOrder); ?>
					</th> -->

					<!-- <th >
						<?php echo HTMLHelper::_('grid.sort', 'JPUBLISHED', 'a.state', $listDirn, $listOrder); ?>
					</th> -->

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_SOT_PURCHASEORDERS_PO_NO', 'a.po_no', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_SOT_PURCHASEORDERS_CREATED_DATE', 'a.created_date', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_SOT_PURCHASEORDERS_WORKING_DAYS', 'a.working_days', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo Text::_('COM_SOT_PURCHASEORDERS_DETAIL_COUNT'); ?>
					</th>

					<?php if ($canEdit || $canDelete): ?>
						<th class="center" style="text-align: center;">
							<?php echo Text::_('COM_SOT_PURCHASEORDERS_ACTIONS'); ?>
						</th>
					<?php endif; ?>

				</tr>
			</thead>
			<tfoot>
				<tr>
					<td colspan=" <?php echo isset($this->items[0]) ? count(get_object_vars($this->items[0])) : 10; ?>">
						<div class="pagination">
							<?php echo $this->pagination->getPagesLinks(); ?>
						</div>
					</td>
				</tr>
			</tfoot>
			<tbody>
				<?php foreach ($this->items as $i => $item) : ?>
					<?php $canEdit = $user->authorise('core.edit', 'com_sot'); ?>
					<?php if (!$canEdit && $user->authorise('core.edit.own', 'com_sot')): ?>
						<?php $canEdit = Factory::getApplication()->getIdentity()->id == $item->created_by; ?>
					<?php endif; ?>

					<tr class="row<?php echo $i % 2; ?>">

						<!-- <td>
							<?php echo $item->id; ?>
						</td> -->
						<!-- <td>
							<?php $class = ($canChange) ? 'active' : 'disabled'; ?>
							<a class="btn btn-micro <?php echo $class; ?>" href="<?php echo ($canChange) ? Route::_('index.php?option=com_sot&task=purchaseorder.publish&id=' . $item->id . '&state=' . (($item->state + 1) % 2), false, 2) : '#'; ?>">
								<?php if ($item->state == 1): ?>
									<i class="icon-publish"></i>
								<?php else: ?>
									<i class="icon-unpublish"></i>
								<?php endif; ?>
							</a>
						</td> -->
						<td>
							<!-- <?php $canCheckin = Factory::getApplication()->getIdentity()->authorise('core.manage', 'com_sot.' . $item->id) || $item->checked_out == Factory::getApplication()->getIdentity()->id; ?> -->
							<!-- <?php if ($canCheckin && $item->checked_out > 0) : ?>
								<a href="<?php echo Route::_('index.php?option=com_sot&task=purchaseorder.checkin&id=' . $item->id . '&' . Session::getFormToken() . '=1'); ?>">
									<?php echo HTMLHelper::_('jgrid.checkedout', $i, $item->uEditor, $item->checked_out_time, 'purchaseorder.', false); ?></a>
							<?php endif; ?> -->
							<a href="<?php echo Route::_('index.php?option=com_sot&view=purchaseorder&id=' . (int) $item->id); ?>">
								<?php echo $this->escape($item->po_no); ?></a>
						</td>
						<td>
							<?php
							$date = $item->created_date;
							echo $date > 0 ? HTMLHelper::_('date', $date, Text::_('DATE_FORMAT_LC1')) : '-';
							?>
						</td>
						<td>
							<?php echo (int) $item->working_days; ?>
						</td>
						<td>
							<?php echo (int) $item->detail_count; ?>
						</td>
						<td class="center">
							<div style="display: flex; gap: 6px; justify-content: center;">

								<!-- VIEW BUTTON (Eye Icon) -->
								<a href="<?php echo Route::_('index.php?option=com_sot&view=purchaseorderdetails&po_id=' . (int)$item->id); ?>"
									class="btn btn-mini"
									type="button">
									<i class="icon-eye"></i>
								</a>

								<?php if ($canEdit || $canDelete): ?>

									<?php if ($canEdit): ?>
										<a href="<?php echo Route::_('index.php?option=com_sot&task=purchaseorder.edit&id=' . $item->id, false, 2); ?>" class="btn btn-mini" type="button"><i class="icon-edit"></i></a>
									<?php endif; ?>

									<?php if ($canDelete): ?>
										<a href="<?php echo Route::_('index.php?option=com_sot&task=purchaseorderform.remove&id=' . $item->id, false, 2); ?>" class="btn btn-mini delete-button" type="button"><i class="icon-trash"></i></a>
									<?php endif; ?>

								<?php endif; ?>

							</div>
						</td>

					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="filter_order" value="" />
	<input type="hidden" name="filter_order_Dir" value="" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>

<?php
if ($canDelete) {
	$wa->addInlineScript("
			jQuery(document).ready(function () {
				jQuery('.delete-button').click(deleteItem);
			});

			function deleteItem() {

				if (!confirm(\"" . Text::_('COM_SOT_DELETE_MESSAGE') . "\")) {
					return false;
				}
			}
		", [], [], ["jquery"]);
}
?>