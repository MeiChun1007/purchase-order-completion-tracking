<?php
/**
 * @version    CVS: 1.0.3
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Sot\Component\Sot\Site\View\Sotsummary;

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

/**
 * View class for COM_SOT_TITLE_SOTSUMMARY.
 *
 * @since  1.0.3
 */
class HtmlView extends BaseHtmlView
{
	/** @var array  Everything the template needs, built by the model */
	protected $report = array();

	protected $params;

	/** @var string  Page heading */
	protected $heading = '';

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return  void
	 *
	 * @throws  \Exception
	 */
	public function display($tpl = null)
	{
		$app = Factory::getApplication();

		$this->params  = $app->getParams('com_sot');
		$this->heading = Text::_('COM_SOT_TITLE_SOTSUMMARY');
		$this->report  = $this->getModel()->getReport();

		$this->_prepareDocument();

		parent::display($tpl);
	}

	/**
	 * Prepares the document (browser title, meta, robots).
	 *
	 * @return  void
	 */
	protected function _prepareDocument()
	{
		$app   = Factory::getApplication();
		$menu  = $app->getMenu()->getActive();
		$title = $this->heading;

		if ($menu
			&& $menu->component === 'com_sot'
			&& isset($menu->query['view'])
			&& $menu->query['view'] === 'sotsummary')
		{
			$title = $this->params->get('page_title') ?: $menu->title;
		}

		if ($app->get('sitename_pagetitles', 0) == 1)
		{
			$title = Text::sprintf('JPAGETITLE', $app->get('sitename'), $title);
		}
		elseif ($app->get('sitename_pagetitles', 0) == 2)
		{
			$title = Text::sprintf('JPAGETITLE', $title, $app->get('sitename'));
		}

		$this->document->setTitle($title);

		if ($this->params->get('menu-meta_description'))
		{
			$this->document->setDescription($this->params->get('menu-meta_description'));
		}

		if ($this->params->get('robots'))
		{
			$this->document->setMetadata('robots', $this->params->get('robots'));
		}
	}
}
