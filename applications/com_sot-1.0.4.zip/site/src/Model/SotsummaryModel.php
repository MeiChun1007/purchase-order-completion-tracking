<?php

/**
 * @version    CVS: 1.0.3
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Sot\Component\Sot\Site\Model;

// No direct access.
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Sot\Component\Sot\Site\Helper\SotReport;

/**
 * SOT Summary: progress of each PO by part and model for one month.
 *
 * @since  1.0.3
 */
class SotsummaryModel extends ReportModel
{
	/**
	 * Build the whole report for the month chosen in the request (default: this month).
	 *
	 * @return  array
	 */
	public function getReport(): array
	{
		$input = Factory::getApplication()->getInput();
		$today = $this->today();
		$ty    = (int) substr($today, 0, 4);
		$tm    = (int) substr($today, 5, 2);

		$year = $input->getInt('year', $ty);
		$year = ($year < 2000 || $year > 2100) ? $ty : $year;

		$month = $input->getInt('month', $tm);
		$month = ($month < 1 || $month > 12) ? $tm : $month;

		$data    = $this->data();

		// Only months that have a purchase order can be chosen
		$periods = $data->poPeriods();

		if (!empty($periods[$year]) && !in_array($month, $periods[$year], true)) {
			$month = max($periods[$year]);   // e.g. a year switch, or this month has no PO yet
		}

		$catalog = $data->catalog();

		list($partId, $modelId) = $this->partModelFilter($catalog);

		$first = sprintf('%04d-%02d-01', $year, $month);
		$last  = (new \DateTimeImmutable($first))->modify('last day of this month')->format('Y-m-d');

		// Optional "as of" date from the request; it must fall inside the chosen month
		$reqAsOf = SotReport::validDate($input->getString('as_of', ''));

		if ($reqAsOf !== null && ($reqAsOf < $first || $reqAsOf > $last)) {
			$reqAsOf = null;
		}

		// live = as of today, final = month end of a finished month, asof = a date the user picked, upcoming = not started
		if ($reqAsOf !== null) {
			$asOf = $reqAsOf;
			$mode = $asOf === $today ? 'live' : (($asOf === $last && $today > $last) ? 'final' : 'asof');
		} elseif ($today > $last) {
			$mode = 'final';
			$asOf = $last;
		} elseif ($today < $first) {
			$mode = 'upcoming';
			$asOf = (new \DateTimeImmutable($first))->modify('-1 day')->format('Y-m-d');
		} else {
			$mode = 'live';
			$asOf = $today;
		}

		$holidays     = $data->holidays($first, $last);
		$calendarDays = count(SotReport::workingDates($year, $month, $holidays));
		$unmatched    = array();
		$lines        = $data->poLines($year, $month, $year, $month, $catalog, $holidays, $partId, $modelId, $unmatched);
		$mov          = $data->movements($first, $asOf, array_keys($lines));

		$groups = array();
		$counts = array('all' => 0, SotReport::BEHIND => 0, SotReport::ON_TRACK => 0, SotReport::CLOSED => 0, SotReport::NO_PO => 0);
		$limits = array();

		foreach ($lines as $mid => $line) {
			$totalPo  = (int) $line['total_po'];
			$limit    = SotReport::effectiveLimit($line['po_wd'], $calendarDays);
			$elapsed  = SotReport::elapsedWorkingDays($year, $month, $holidays, $asOf, $line['po_wd']);
			$daysLeft = max(0, $limit - $elapsed);

			$planToDate = SotReport::sumUpTo($line['plan'], $asOf);
			$incoming   = (int) array_sum($mov['wo'][$mid] ?? array());   // normal incoming only
			$fg         = (int) array_sum($mov['fg'][$mid] ?? array());
			$sort       = (int) array_sum($mov['sort'][$mid] ?? array());
			$prodNc     = (int) array_sum($mov['pnc'][$mid] ?? array());     // total NC from production
			$outNc      = (int) array_sum($mov['nc'][$mid] ?? array());      // outgoing NC
			$scrap      = (int) array_sum($mov['scrap'][$mid] ?? array());   // outgoing scrap
			$accepted   = $sort - $prodNc;                                   // total accepted
			$balWip     = $incoming - $sort;                                 // Incoming WO - Total sort
			$balFg      = $accepted - $fg;                                   // Total accepted - Outgoing FG
			$balNc      = $prodNc - ($outNc + $scrap);                       // Total NC - (Outgoing NC + Scrap)
			$balance    = max(0, $totalPo - $fg);
			$status     = SotReport::status($totalPo, $fg, $planToDate);
			$incoming = (int) array_sum($mov['wo'][$mid] ?? array())   + (int) array_sum($mov['co_wo'][$mid] ?? array());
			$fg       = (int) array_sum($mov['fg'][$mid] ?? array())   + (int) array_sum($mov['co_fg'][$mid] ?? array());
			$sort     = (int) array_sum($mov['sort'][$mid] ?? array()) + (int) array_sum($mov['co_sort'][$mid] ?? array());
			$prodNc   = (int) array_sum($mov['pnc'][$mid] ?? array())  + (int) array_sum($mov['co_pnc'][$mid] ?? array());

			$limits[] = $limit;

			$row = array(
				'model_id'    => $mid,
				'part_id'     => $line['part_id'],
				'model'       => $line['model'],
				'po_no'       => implode(', ', $line['po_nos']),
				'total_po'    => $totalPo,
				'plan_to_date' => $planToDate,
				'incoming'    => $incoming,
				'fg'          => $fg,
				'subcon_diff' => $fg - $planToDate,
				'balance'     => $balance,
				'bal_wip'     => $balWip,
				'bal_fg'      => $balFg,
				'bal_nc'      => $balNc,
				'need_per_day' => SotReport::needPerDay($balance, $daysLeft),
				'status'      => $status,
				'fg_pct'      => $totalPo > 0 ? min(100, round($fg / $totalPo * 100, 1)) : 0,
				'plan_pct'    => $totalPo > 0 ? min(100, round($planToDate / $totalPo * 100, 1)) : 0,
				'carry_lost'  => ($mode === 'final' && $balance > 0) ? $balance : 0,
			);

			if (!isset($groups[$line['part_id']])) {
				$groups[$line['part_id']] = array('part_id' => $line['part_id'], 'part' => $line['part'], 'rows' => array());
			}

			$groups[$line['part_id']]['rows'][] = $row;
			$counts['all']++;
			$counts[$status]++;
		}

		// Header: "Working day X of Y | Z days left"
		$headerLimit = $limits ? max($limits) : $calendarDays;
		$elapsedAll  = SotReport::elapsedWorkingDays($year, $month, $holidays, $asOf, $headerLimit);

		// Year / month choices come from the purchase orders that exist
		$years = array_unique(array_merge(array_keys($periods), array($year)));
		rsort($years);

		$months = array_unique(array_merge($periods[$year] ?? array(), array($month)));
		sort($months);

		return array(
			'year'          => $year,
			'month'         => $month,
			'part_id'       => $partId,
			'model_id'      => $modelId,
			'mode'          => $mode,
			'as_of'         => $asOf,
			'first'         => $first,
			'last'          => $last,
			'link_to'       => in_array($mode, array('final', 'upcoming'), true) ? $last : $asOf,
			'as_of_input'   => $mode === 'upcoming' ? $first : $asOf,
			'working_days'  => $headerLimit,
			'elapsed'       => $elapsedAll,
			'days_left'     => max(0, $headerLimit - $elapsedAll),
			'groups'        => array_values($groups),
			'counts'        => $counts,
			'years'         => $years,
			'options'       => $this->filterOptions($catalog, $partId),
			'unmatched'     => $unmatched,
			'months'        => $months,
		);
	}
}
