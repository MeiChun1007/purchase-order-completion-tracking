<?php

/**
 * @version    CVS: 1.0.3
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Sot\Component\Sot\Site\Model;

// No direct access.
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\Database\DatabaseInterface;
use Sot\Component\Sot\Site\Helper\SotReportData;

/**
 * Shared plumbing for the two report models (summary and daily tracker).
 *
 * @since  1.0.3
 */
abstract class ReportModel extends BaseDatabaseModel
{
	/**
	 * Report data access.
	 */
	protected function data(): SotReportData
	{
		return new SotReportData(Factory::getContainer()->get(DatabaseInterface::class));
	}

	/**
	 * Today's date (Y-m-d) in the user's timezone.
	 */
	protected function today(): string
	{
		$tz = Factory::getApplication()->getIdentity()->getTimezone();

		return Factory::getDate('now', $tz)->format('Y-m-d', true);
	}

	/**
	 * Part and model filters from the request. Unknown ids are dropped, and a model that does
	 * not belong to the chosen part is dropped as well.
	 *
	 * @param   array  $catalog  From SotReportData::catalog()
	 *
	 * @return  int[]  [partId, modelId] (0 = all)
	 */
	protected function partModelFilter(array $catalog): array
	{
		$input   = Factory::getApplication()->getInput();
		$partId  = $input->getInt('part', 0);
		$modelId = $input->getInt('model', 0);

		if (!isset($catalog['parts'][$partId])) {
			$partId = 0;
		}

		if (!isset($catalog['models'][$modelId]) || ($partId && $catalog['models'][$modelId]['part_id'] !== $partId)) {
			$modelId = 0;
		}

		return array($partId, $modelId);
	}

	/**
	 * Options for the part and model drop-downs.
	 *
	 * @return  array  parts [id => name], models [id => name] (limited to the chosen part)
	 */
	protected function filterOptions(array $catalog, int $partId, array $hideIds = array()): array
	{
		$models = array();

		foreach ($catalog['models'] as $id => $m) {
			if ((!$partId || $m['part_id'] === $partId) && !in_array($id, $hideIds, true)) {
				$models[$id] = $m['name'];
			}
		}

		return array('parts' => $catalog['parts'], 'models' => $models);
	}
}
