<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Sot\Component\Sot\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\CMS\Layout\FileLayout;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use \Sot\Component\Sot\Site\Helper\SotHelper;
use \Joomla\Database\DatabaseInterface;

/**
 * Methods supporting a list of Sot records.
 *
 * @since  1.0.0
 */
class PurchaseordersModel extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see    JController
	 * @since  1.0.0
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id',
				'state', 'a.state',
				'ordering', 'a.ordering',
				'created_by', 'a.created_by',
				'modified_by', 'a.modified_by',
				'po_no', 'a.po_no',
				'created_date', 'a.created_date',
				'month', 'a.month',
				'year', 'a.year',
				'working_days', 'a.working_days',
			);
		}

		parent::__construct($config);
	}

	

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return  void
	 *
	 * @throws  \Exception
	 *
	 * @since   1.0.0
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState('a.created_date', 'DESC');

		$app = Factory::getApplication();
		$list = $app->getUserState($this->context . '.list');

		$value = $app->getUserState($this->context . '.list.limit', $app->get('list_limit', 25));
		$list['limit'] = $value;
		
		$this->setState('list.limit', $value);

		$value = $app->input->get('limitstart', 0, 'uint');
		$this->setState('list.start', $value);

		$ordering  = $this->getUserStateFromRequest($this->context .'.filter_order', 'filter_order', 'a.created_date');
		$direction = strtoupper($this->getUserStateFromRequest($this->context .'.filter_order_Dir', 'filter_order_Dir', 'DESC'));
		
		if(!empty($ordering) || !empty($direction))
		{
			$list['fullordering'] = $ordering . ' ' . $direction;
		}

		$app->setUserState($this->context . '.list', $list);

		

		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);

		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);

			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  \Joomla\Database\DatabaseQuery
	 *
	 * @since   1.0.0
	 */
	protected function getListQuery()
	{
			// Create a new query object.
			$db    = Factory::getContainer()->get(DatabaseInterface::class);
			$query = $db->getQuery(true);

			// Select the required fields from the table.
			$query->select(
						$this->getState(
								'list.select', 'DISTINCT a.*'
						)
				);

			$query->from('`#__sot_purchase_orders` AS a');

		// Number of rows in #__sot_purchase_orders_details
		$query->select('(SELECT COUNT(*) FROM `#__sot_purchase_orders_details` AS d WHERE d.po_id = a.id) AS detail_count');
			
		// Join over the users for the checked out user.
		$query->select('uc.name AS uEditor');
		$query->join('LEFT', '#__users AS uc ON uc.id=a.checked_out');
			
		if (!Factory::getApplication()->getIdentity()->authorise('core.edit', 'com_sot'))
		{
			$query->where('a.state = 1');
		}
		else
		{
			$query->where('(a.state IN (0, 1))');
		}

			// Filter by search in title
			$search = $this->getState('filter.search');

			if (!empty($search))
			{
				if (stripos($search, 'id:') === 0)
				{
					$query->where('a.id = ' . (int) substr($search, 3));
				}
				else
				{
					$search = '%' . $search . '%';
					$query->where('( a.po_no LIKE :search_0 OR a.id IN (SELECT d.po_id FROM `#__sot_purchase_orders_details` AS d WHERE d.part LIKE :search_1 OR d.model LIKE :search_2) )')
						->bind([':search_0', ':search_1', ':search_2'], $search);
				}
			}
			

		// Filtering created_date
		$filter_created_date_from = $this->state->get("filter.created_date.from");

		if ($filter_created_date_from !== null && !empty($filter_created_date_from))
		{
			$tz = \Joomla\CMS\Factory::getApplication()->getIdentity()->getTimezone();
			$fromDate = \Joomla\CMS\Factory::getDate($filter_created_date_from . ' 00:00:00', $tz);
			$fromDateSql_created_date = $fromDate->toSql();
			$query->where($db->quoteName("a.created_date") . " >= :filter_created_date_from")->bind(':filter_created_date_from', $fromDateSql_created_date);
		}
		$filter_created_date_to = $this->state->get("filter.created_date.to");

		if ($filter_created_date_to !== null  && !empty($filter_created_date_to))
		{
			$tz = \Joomla\CMS\Factory::getApplication()->getIdentity()->getTimezone();
			$toDate = \Joomla\CMS\Factory::getDate($filter_created_date_to . ' 23:59:59', $tz);
			$toDateSql_created_date = $toDate->toSql();
			$query->where($db->quoteName("a.created_date") . " <= :filter_created_date_to")->bind(':filter_created_date_to', $toDateSql_created_date);
		}

		// Filtering month
		$filter_month = $this->state->get("filter.month");
		if (is_array($filter_month)) {
			$filter_month = array_values(array_filter($filter_month, function($v){ return $v !== "" && $v !== null; }));
		}
		if ((is_array($filter_month) && count($filter_month) > 0) || (!is_array($filter_month) && $filter_month !== "" && $filter_month !== null)) {
			if (is_array($filter_month)) {
				$query->whereIn($db->quoteName("a.month"), array_values($filter_month), ParameterType::STRING);
			} else {
				$query->where($db->quoteName("a.month") . " = :filter_month")->bind(':filter_month', $filter_month);
			}
		}

			
			
			// Add the list ordering clause.
			$orderCol  = $this->state->get('list.ordering', 'a.created_date');
			$orderDirn = $this->state->get('list.direction', 'DESC');

			if ($orderCol && $orderDirn)
			{
				$query->order($db->escape($orderCol . ' ' . $orderDirn));
			}

			return $query;
	}

	/**
	 * Method to get an array of data items
	 *
	 * @return  mixed An array of data on success, false on failure.
	 */
	public function getItems()
	{
		$items = parent::getItems();
		
		return $items;
	}

	/**
	 * Overrides the default function to check Date fields format, identified by
	 * "_dateformat" suffix, and erases the field if it's not correct.
	 *
	 * @return void
	 */
	protected function loadFormData()
	{
		$app              = Factory::getApplication();
		$filters          = $app->getUserState($this->context . '.filter', array());
		$error_dateformat = false;

		foreach ($filters as $key => $value)
		{
			if (strpos($key, '_dateformat') && !empty($value) && $this->isValidDate($value) == null)
			{
				$filters[$key]    = '';
				$error_dateformat = true;
			}
		}

		if ($error_dateformat)
		{
			$app->enqueueMessage(Text::_("COM_SOT_SEARCH_FILTER_DATE_FORMAT"), "warning");
			$app->setUserState($this->context . '.filter', $filters);
		}

		return parent::loadFormData();
	}

	/**
	 * Checks if a given date is valid and in a specified format (YYYY-MM-DD)
	 *
	 * @param   string  $date  Date to be checked
	 *
	 * @return bool
	 */
	private function isValidDate($date)
	{
		$date = str_replace('/', '-', $date);
		return (date_create($date)) ? Factory::getDate($date)->format("Y-m-d") : null;
	}
}
