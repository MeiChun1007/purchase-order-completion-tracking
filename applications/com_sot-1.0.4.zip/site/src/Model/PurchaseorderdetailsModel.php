<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Sot\Component\Sot\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\CMS\Factory;
use \Joomla\Database\DatabaseInterface;
use \Joomla\Database\ParameterType;

/**
 * Methods supporting a list of Purchase Order Details records
 * (table #__sot_purchase_orders_details).
 *
 * @since  1.0.1
 */
class PurchaseorderdetailsModel extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since   1.0.1
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id',
				'a.id',
				'po_id',
				'a.po_id',
				'po_no',
				'a.po_no',
				'created_date',
				'a.created_date',
				'created_date.from',
				'created_date.to',
				'year',
				'a.year',
				'month',
				'a.month',
				'part',
				'a.part',
				'model',
				'a.model',
				'total_po',
				'a.total_po',
				'daily_plan_qty',
				'a.daily_plan_qty',
				'model_name',
				'pm.model_name',
				'part_name',
				'pc.component_name',
				'working_days',
				'p.working_days',
			);
		}

		parent::__construct($config);
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return  void
	 *
	 * @since   1.0.1
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		parent::populateState('a.po_id', 'DESC');
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string  A store id.
	 *
	 * @since   1.0.1
	 */
	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.part');
		$id .= ':' . $this->getState('filter.model');
		$id .= ':' . $this->getState('filter.year');
		$id .= ':' . $this->getState('filter.month');
		$id .= ':' . $this->getState('filter.created_date.from');
		$id .= ':' . $this->getState('filter.created_date.to');

		return parent::getStoreId($id);
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  \Joomla\Database\DatabaseQuery
	 *
	 * @since   1.0.1
	 */
	protected function getListQuery()
	{
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		$query->select($this->getState('list.select', 'a.*'));
		$query->from($db->quoteName('#__sot_purchase_orders_details', 'a'));

		// Same visibility rule as the Purchase Orders list: visitors only see
		// published orders, editors also see unpublished ones. Trash is never shown.
		$query->select($db->quoteName('p.working_days', 'working_days'));
		$query->join('INNER', $db->quoteName('#__sot_purchase_orders', 'p') . ' ON p.id = a.po_id');

		$query->select($db->quoteName('pm.model_name', 'model_name'));
		$query->join('LEFT', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'));

		$query->select($db->quoteName('pc.component_name', 'part_name'));
		$query->join('LEFT', $db->quoteName('#__product_components', 'pc') . ' ON ' . $db->quoteName('pc.id') . ' = ' . $db->quoteName('a.part'));

		if (!Factory::getApplication()->getIdentity()->authorise('core.edit', 'com_sot')) {
			$query->where('p.state = 1');
		} else {
			$query->where('p.state IN (0, 1)');
		}

		$app = Factory::getApplication();
		$poId = $app->input->getInt('po_id', 0);
		if ($poId > 0) {
			$query->where($db->quoteName('a.po_id') . ' = ' . (int) $poId);
		}

		// Search
		$search = $this->getState('filter.search');

		if (!empty($search)) {
			$search = '%' . $search . '%';
			$query->where('( a.po_no LIKE :search_0 OR a.part LIKE :search_1 OR a.model LIKE :search_2 )')
				->bind([':search_0', ':search_1', ':search_2'], $search);
		}

		// Part / model (exact match, values come from the filter dropdowns)
		$filterPart = (string) $this->getState('filter.part');

		if ($filterPart !== '') {
			$query->where($db->quoteName('a.part') . ' = :filter_part')->bind(':filter_part', $filterPart);
		}

		$filterModel = (string) $this->getState('filter.model');

		if ($filterModel !== '') {
			$query->where($db->quoteName('a.model') . ' = :filter_model')->bind(':filter_model', $filterModel);
		}

		// Year / month
		$filterYear = $this->getState('filter.year');

		if (is_numeric($filterYear) && (int) $filterYear > 0) {
			$filterYear = (int) $filterYear;
			$query->where($db->quoteName('a.year') . ' = :filter_year')->bind(':filter_year', $filterYear, ParameterType::INTEGER);
		}

		$filterMonth = $this->getState('filter.month');

		if (is_numeric($filterMonth) && (int) $filterMonth > 0) {
			$filterMonth = (int) $filterMonth;
			$query->where($db->quoteName('a.month') . ' = :filter_month')->bind(':filter_month', $filterMonth, ParameterType::INTEGER);
		}

		// Created date range (entered in the user's timezone, stored in UTC)
		$from = $this->getState('filter.created_date.from');

		if (!empty($from)) {
			$tz       = Factory::getApplication()->getIdentity()->getTimezone();
			$fromSql  = Factory::getDate($from . ' 00:00:00', $tz)->toSql();
			$query->where($db->quoteName('a.created_date') . ' >= :filter_from')->bind(':filter_from', $fromSql);
		}

		$to = $this->getState('filter.created_date.to');

		if (!empty($to)) {
			$tz     = Factory::getApplication()->getIdentity()->getTimezone();
			$toSql  = Factory::getDate($to . ' 23:59:59', $tz)->toSql();
			$query->where($db->quoteName('a.created_date') . ' <= :filter_to')->bind(':filter_to', $toSql);
		}

		// Ordering
		$orderCol  = $this->state->get('list.ordering', 'a.id');
		$orderDirn = $this->state->get('list.direction', 'DESC');

		if ($orderCol && $orderDirn) {
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}
}
