<?php

/**
 * @version    CVS: 1.0.3
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Sot\Component\Sot\Site\Model;

// No direct access.
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Sot\Component\Sot\Site\Helper\SotReport;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;

/**
 * SOT Daily Tracker: plan, incoming, outgoing and production per day, for each part and model.
 *
 * @since  1.0.3
 */
class SotdailyModel extends ReportModel
{
	/** Longest range shown: 366 day columns, or 5 years of month columns (Year period). */
	private const MAX_DAYS_DAY   = 366;
	private const MAX_DAYS_MONTH = 1830;

	/** Metrics shown for every card, in order. */
	public const METRICS = array(
		'plan',
		'wo',
		'pr',
		'fg',
		'nc',
		'scrap',
		'sort',
		'pnc',
		'in_vs',
		'fg_vs',
		'sort_vs',          // keep whatever you already have
		'accepted',
		'bal_wip',
		'bal_fg',
		'bal_nc'
	);

	/**
	 * Build the whole report for the range in the request (default: 1st of this month to today).
	 *
	 * @return  array
	 */
	public function getReport(): array
	{
		$input = Factory::getApplication()->getInput();
		$today = $this->today();

		$period = $input->getCmd('period', 'date');
		$period = in_array($period, array('year', 'month', 'week', 'date'), true) ? $period : 'date';
		$gran   = $period === 'year' ? 'month' : 'day';

		$from = SotReport::validDate($input->getString('from', ''));
		$to   = SotReport::validDate($input->getString('to', ''));

		if ($from === null || $to === null) {
			// No dates given: default to the current year / month / week, or 1st of this month to today for Date
			$t = new \DateTimeImmutable($today);

			switch ($period) {
				case 'year':
					$from = $t->format('Y') . '-01-01';
					$to   = $t->format('Y') . '-12-31';
					break;

				case 'month':
					$from = $t->format('Y-m-01');
					$to   = $t->modify('last day of this month')->format('Y-m-d');
					break;

				case 'week':
					$mon  = $t->setISODate((int) $t->format('o'), (int) $t->format('W'));
					$from = $mon->format('Y-m-d');
					$to   = $mon->modify('+6 days')->format('Y-m-d');
					break;

				default:
					$from = $t->format('Y-m-01');
					$to   = $today;
			}
		}

		if ($to < $from) {
			list($from, $to) = array($to, $from);
		}

		// Keep the page a sensible size
		$maxDays = $gran === 'day' ? self::MAX_DAYS_DAY : self::MAX_DAYS_MONTH;
		$limitTo = (new \DateTimeImmutable($from))->modify('+' . ($maxDays - 1) . ' days')->format('Y-m-d');
		$clamped = $to > $limitTo;
		$to      = $clamped ? $limitTo : $to;

		$data    = $this->data();
		$catalog = $data->catalog();

		list($partId, $modelId) = $this->partModelFilter($catalog);

		// Plans are built per PO month, so load whole months of calendar
		$fromMonthStart = substr($from, 0, 8) . '01';
		$toMonthEnd     = (new \DateTimeImmutable(substr($to, 0, 8) . '01'))->modify('last day of this month')->format('Y-m-d');
		$holidays       = $data->holidays($fromMonthStart, $toMonthEnd);

		$unmatched = array();
		$lines     = $data->poLines(
			(int) substr($from, 0, 4),
			(int) substr($from, 5, 2),
			(int) substr($to, 0, 4),
			(int) substr($to, 5, 2),
			$catalog,
			$holidays,
			$partId,
			$modelId,
			$unmatched
		);
		$mov       = $data->movements($from, $to, array_keys($lines));
		$buckets   = SotReport::buckets($from, $to, $gran, $holidays);
		$keys      = array_column($buckets, 'key');
		$partOrder = array_keys($catalog['parts']);

		$cards = array();

		foreach ($lines as $mid => $line) {
			$series = array();

			foreach (self::METRICS as $metric) {
				$series[$metric] = array_fill_keys($keys, 0);
			}

			$planElapsed = array_fill_keys($keys, 0);

			foreach ($line['plan'] as $d => $qty) {
				if ($d < $from || $d > $to) {
					continue;
				}

				$bk = SotReport::bucketKey($d, $gran);
				$series['plan'][$bk] += $qty;

				if ($d <= $today) {
					$planElapsed[$bk] += $qty;
				}
			}

			foreach (array('wo', 'pr', 'fg', 'nc', 'scrap', 'sort', 'pnc') as $metric) {
				foreach ($mov[$metric][$mid] ?? array() as $d => $qty) {
					$bk = SotReport::bucketKey($d, $gran);

					if (isset($series[$metric][$bk])) {
						$series[$metric][$bk] += $qty;
					}
				}
			}

			// Production accepted and the Balance group, per column (day or month)
			foreach ($keys as $k) {
				$series['accepted'][$k] = $series['sort'][$k] - $series['pnc'][$k];
				$series['bal_wip'][$k]  = $series['wo'][$k] - $series['sort'][$k];                          // Incoming WO - Total sort
				$series['bal_fg'][$k]   = $series['accepted'][$k] - $series['fg'][$k];                      // Total accepted - Outgoing FG
				$series['bal_nc'][$k]   = $series['pnc'][$k] - ($series['nc'][$k] + $series['scrap'][$k]);  // Total NC - (Outgoing NC + Scrap)
			}

			// "vs plan" compares with the plan up to today only, and stays blank for days still to come
			foreach ($buckets as $b) {
				$started = $b['start'] <= $today;

				$series['in_vs'][$b['key']] = $started ? $series['wo'][$b['key']] - $planElapsed[$b['key']] : null;
				$series['fg_vs'][$b['key']] = $started ? $series['fg'][$b['key']] - $planElapsed[$b['key']] : null;
				$series['sort_vs'][$b['key']] = $started ? $series['sort'][$b['key']] - $planElapsed[$b['key']] : null;
			}

			// Carried over: opening quantities, shown in their own column between Total and the first day
			$co = array(
				'wo'   => (int) array_sum($mov['co_wo'][$mid] ?? array()),
				'fg'   => (int) array_sum($mov['co_fg'][$mid] ?? array()),
				'sort' => (int) array_sum($mov['co_sort'][$mid] ?? array()),
				'pnc'  => (int) array_sum($mov['co_pnc'][$mid] ?? array()),
			);
			$co['accepted'] = $co['sort'] - $co['pnc'];
			$co['bal_wip']  = $co['wo'] - $co['sort'];
			$co['bal_fg']   = $co['accepted'] - $co['fg'];
			$co['bal_nc']   = $co['pnc'];            // nothing was shipped out as NC / scrap in the carried-over set

			$totals = array();

			foreach (self::METRICS as $metric) {
				$totals[$metric] = (int) array_sum($series[$metric]);
				$totals[$metric] = (int) array_sum($series[$metric]) + ($co[$metric] ?? 0);
			}

			$rangeStarted     = $from <= $today;
			$totals['in_vs']  = $rangeStarted ? $totals['wo'] - (int) array_sum($planElapsed) : null;
			$totals['fg_vs']  = $rangeStarted ? $totals['fg'] - (int) array_sum($planElapsed) : null;
			$totals['sort_vs']  = $rangeStarted ? $totals['sort'] - (int) array_sum($planElapsed) : null;

			$tone = array_search($line['part_id'], $partOrder, true);

			$cards[] = array(
				'model_id' => $mid,
				'part_id'  => $line['part_id'],
				'part'     => $line['part'],
				'model'    => $line['model'],
				'po_no'    => implode(', ', $line['po_nos']),
				'total_po' => (int) $line['total_po'],
				'tone'     => $tone === false ? 0 : (int) $tone,
				'series'   => $series,
				'totals'   => $totals,
				'carry' => $co,
			);
		}

		// Week selector: ISO year / week of the From date
		$fromDt   = new \DateTimeImmutable($from);
		$isoYear  = (int) $fromDt->format('o');
		$isoWeek  = (int) $fromDt->format('W');
		$weekOpts = $period === 'week' ? $this->weekOptions($isoYear, $isoWeek, $today) : array();
		$weekStart = $fromDt->setISODate($isoYear, $isoWeek)->format('Y-m-d');

		// Year / month choices come from the purchase orders that exist
		$periods = $data->poPeriods();
		$selYear = $period === 'week' ? $isoYear : (int) substr($from, 0, 4);

		$years = array_unique(array_merge(array_keys($periods), array($selYear)));
		rsort($years);

		$months = array_unique(array_merge($periods[$selYear] ?? array(), array((int) substr($from, 5, 2))));
		sort($months);

		return array(
			'period'   => $period,
			'gran'     => $gran,
			'from'     => $from,
			'to'       => $to,
			'today'    => $today,
			'clamped'  => $clamped,
			'part_id'  => $partId,
			'model_id' => $modelId,
			'buckets'  => $buckets,
			'cards'    => $cards,
			'options'  => $this->filterOptions($catalog, $partId),
			'unmatched' => $unmatched,
			'iso_year'     => $isoYear,
			'week_start'   => $weekStart,
			'week_options' => $weekOpts,
			'years'         => $years,
			'months'        => $months,
			'months_by_year' => $periods,
		);
	}

	/**
	 * ISO weeks of an ISO year that have production data, newest first.
	 * Always includes the current week (if it is in that ISO year) and the selected week.
	 *
	 * @return  object[]  value = Monday (Y-m-d), week = ISO week number, label = "Week 43 (19 Oct - 25 Oct)"
	 */
	private function weekOptions(int $isoYear, int $selectedWeek, string $today): array
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		// Date range of the ISO year: Monday of week 1 .. Sunday of the last week
		$lastWeek = (int) (new \DateTimeImmutable($isoYear . '-12-28'))->format('W');
		$start    = (new \DateTimeImmutable())->setISODate($isoYear, 1)->format('Y-m-d') . ' 00:00:00';
		$end      = (new \DateTimeImmutable())->setISODate($isoYear, $lastWeek, 7)->modify('+1 day')->format('Y-m-d') . ' 00:00:00';

		$col   = $db->quoteName('date');
		$query = $db->getQuery(true)
			->select('DISTINCT WEEK(' . $col . ', 3) AS wk')
			->from($db->quoteName('#__production_summary'))
			->where($db->quoteName('state') . ' = 1')
			->where($col . ' >= :wstart')
			->where($col . ' < :wend')
			->bind(':wstart', $start)
			->bind(':wend', $end);

		$weeks = array_map('intval', $db->setQuery($query)->loadColumn() ?: array());

		$now = new \DateTimeImmutable($today);

		if ((int) $now->format('o') === $isoYear) {
			$weeks[] = (int) $now->format('W');
		}

		$weeks[] = $selectedWeek;   // keep the selected week choosable even with no data
		$weeks   = array_unique($weeks);
		rsort($weeks);

		$options = array();

		foreach ($weeks as $w) {
			$mon = (new \DateTimeImmutable())->setISODate($isoYear, $w);
			$sun = $mon->modify('+6 days');

			$options[] = (object) array(
				'value' => $mon->format('Y-m-d'),
				'week'  => $w,
				'label' => Text::sprintf('COM_SOT_REPORT_WEEK_LABEL', $w, $mon->format('d M'), $sun->format('d M')),
			);
		}

		return $options;
	}
}
