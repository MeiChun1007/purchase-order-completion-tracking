<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Sot\Component\Sot\Site\Service;

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Component\Router\RouterViewConfiguration;
use Joomla\CMS\Component\Router\RouterView;
use Joomla\CMS\Component\Router\Rules\StandardRules;
use Joomla\CMS\Component\Router\Rules\NomenuRules;
use Joomla\CMS\Component\Router\Rules\MenuRules;
use Joomla\CMS\Factory;
use Joomla\CMS\Categories\Categories;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Categories\CategoryFactoryInterface;
use Joomla\CMS\Categories\CategoryInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\CMS\Menu\AbstractMenu;
use Joomla\CMS\Component\ComponentHelper;

/**
 * Class SotRouter
 *
 */
class Router extends RouterView
{
	private $noIDs;
	/**
	 * The category factory
	 *
	 * @var    CategoryFactoryInterface
	 *
	 * @since  1.0.0
	 */
	private $categoryFactory;

	/**
	 * The category cache
	 *
	 * @var    array
	 *
	 * @since  1.0.0
	 */
	private $categoryCache = [];

	public function __construct(SiteApplication $app, AbstractMenu $menu, CategoryFactoryInterface $categoryFactory, DatabaseInterface $db)
	{
		$params = ComponentHelper::getParams('com_sot');
		$this->noIDs = (bool) $params->get('sef_ids');
		$this->categoryFactory = $categoryFactory;


		$purchaseorders = new RouterViewConfiguration('purchaseorders');
		$this->registerView($purchaseorders);
		$ccPurchaseorder = new RouterViewConfiguration('purchaseorder');
		$ccPurchaseorder->setKey('id')->setParent($purchaseorders);
		$this->registerView($ccPurchaseorder);
		$purchaseorderform = new RouterViewConfiguration('purchaseorderform');
		$purchaseorderform->setKey('id');
		$this->registerView($purchaseorderform);
		$purchaseorderdetails = new RouterViewConfiguration('purchaseorderdetails');
		$this->registerView($purchaseorderdetails);
		$sotsummary = new RouterViewConfiguration('sotsummary');
		$this->registerView($sotsummary);
		$sotdaily = new RouterViewConfiguration('sotdaily');
		$this->registerView($sotdaily);

		parent::__construct($app, $menu);

		$this->attachRule(new MenuRules($this));
		$this->attachRule(new StandardRules($this));
		$this->attachRule(new NomenuRules($this));
	}



	/**
	 * Method to get the segment(s) for an purchaseorder
	 *
	 * @param   string  $id     ID of the purchaseorder to retrieve the segments for
	 * @param   array   $query  The request that is built right now
	 *
	 * @return  array|string  The segments of this item
	 */
	public function getPurchaseorderSegment($id, $query)
	{
		return array((int) $id => $id);
	}
	/**
	 * Method to get the segment(s) for an purchaseorderform
	 *
	 * @param   string  $id     ID of the purchaseorderform to retrieve the segments for
	 * @param   array   $query  The request that is built right now
	 *
	 * @return  array|string  The segments of this item
	 */
	public function getPurchaseorderformSegment($id, $query)
	{
		return $this->getPurchaseorderSegment($id, $query);
	}


	/**
	 * Method to get the segment(s) for an purchaseorder
	 *
	 * @param   string  $segment  Segment of the purchaseorder to retrieve the ID for
	 * @param   array   $query    The request that is parsed right now
	 *
	 * @return  mixed   The id of this item or false
	 */
	public function getPurchaseorderId($segment, $query)
	{
		return (int) $segment;
	}
	/**
	 * Method to get the segment(s) for an purchaseorderform
	 *
	 * @param   string  $segment  Segment of the purchaseorderform to retrieve the ID for
	 * @param   array   $query    The request that is parsed right now
	 *
	 * @return  mixed   The id of this item or false
	 */
	public function getPurchaseorderformId($segment, $query)
	{
		return $this->getPurchaseorderId($segment, $query);
	}

	/**
	 * Method to get categories from cache
	 *
	 * @param   array  $options   The options for retrieving categories
	 *
	 * @return  CategoryInterface  The object containing categories
	 *
	 * @since   1.0.0
	 */
	private function getCategories(array $options = []): CategoryInterface
	{
		$key = serialize($options);

		if (!isset($this->categoryCache[$key])) {
			$this->categoryCache[$key] = $this->categoryFactory->createCategory($options);
		}

		return $this->categoryCache[$key];
	}
}
