<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Sot\Component\Sot\Site\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

/**
 * Purchaseorder class.
 *
 * @since  1.0.0
 */
class PurchaseorderformController extends FormController
{
	/**
	 * Method to check out an item for editing and redirect to the edit form.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 *
	 * @throws  \Exception
	 */
	public function edit($key = NULL, $urlVar = NULL)
	{
		// Get the previous edit id (if any) and the current edit id.
		$previousId = (int) $this->app->getUserState('com_sot.edit.purchaseorder.id');
		$editId     = $this->input->getInt('id', 0);

		// Set the user id for the user to edit in the session.
		$this->app->setUserState('com_sot.edit.purchaseorder.id', $editId);

		// Get the model.
		$model = $this->getModel('Purchaseorderform', 'Site');

		// Check out the item
		if ($editId) {
			$model->checkout($editId);
		}

		// Check in the previous user.
		if ($previousId) {
			$model->checkin($previousId);
		}

		// Redirect to the edit screen.
		$this->setRedirect(Route::_('index.php?option=com_sot&view=purchaseorderform&layout=edit', false));
	}

	/**
	 * Method to save data.
	 *
	 * @return  void
	 *
	 * @throws  \Exception
	 * @since   1.0.0
	 */
	public function save($key = NULL, $urlVar = NULL)
	{
		// Check for request forgeries.
		$this->checkToken();

		// Initialise variables.
		$model = $this->getModel('Purchaseorderform', 'Site');

		// Get the user data.
		$data = $this->input->get('jform', array(), 'array');

		// Validate the posted data.
		$form = $model->getForm();

		if (!$form) {
			throw new \Exception($model->getError(), 500);
		}

		// Send an object which can be modified through the plugin event
		$objData = (object) $data;
		$this->app->triggerEvent(
			'onContentNormaliseRequestData',
			array($this->option . '.' . $this->context, $objData, $form)
		);

		$data = (array) $objData;

		// Validate the posted data.
		$data = $model->validate($form, $data);

		// Check for errors.
		if ($data === false) {
			// Get the validation messages.
			$errors = $model->getErrors();

			// Push up to three validation messages out to the user.
			for ($i = 0, $n = count($errors); $i < $n && $i < 3; $i++) {
				if ($errors[$i] instanceof \Exception) {
					$this->app->enqueueMessage($errors[$i]->getMessage(), 'warning');
				} else {
					$this->app->enqueueMessage($errors[$i], 'warning');
				}
			}

			$jform = $this->input->get('jform', array(), 'ARRAY');

			// Save the data in the session.
			$this->app->setUserState('com_sot.edit.purchaseorder.data', $jform);

			// Redirect back to the edit screen.
			$id = (int) $this->app->getUserState('com_sot.edit.purchaseorder.id');
			$this->setRedirect(Route::_('index.php?option=com_sot&view=purchaseorderform&layout=edit&id=' . $id, false));

			$this->redirect();
		}

		// Attempt to save the data.
		$return = $model->save($data);

		// Check for errors.
		if ($return === false) {
			// Save the data in the session.
			$this->app->setUserState('com_sot.edit.purchaseorder.data', $data);

			// Redirect back to the edit screen.
			$id = (int) $this->app->getUserState('com_sot.edit.purchaseorder.id');
			$this->setMessage(Text::sprintf('Save failed', $model->getError()), 'warning');
			$this->setRedirect(Route::_('index.php?option=com_sot&view=purchaseorderform&layout=edit&id=' . $id, false));
			$this->redirect();
		}

		// Check in the profile.
		if ($return) {
			$model->checkin($return);
		}

		// Clear the profile id from the session.
		$this->app->setUserState('com_sot.edit.purchaseorder.id', null);

		// Redirect to the list screen.
		if (!empty($return)) {
			$this->setMessage(Text::_('COM_SOT_ITEM_SAVED_SUCCESSFULLY'));

			// $return already IS the record id — the Model's save() returns $table->id directly
			$recordId = (int) $return;

			$url = 'index.php?option=com_sot&view=purchaseorder&id=' . $recordId;
		} else {

			$menu = Factory::getApplication()->getMenu();
			$item = $menu->getActive();
			$url  = (empty($item->link) ? 'index.php?option=com_sot&view=purchaseorders' : $item->link);
		}

		$this->setRedirect(Route::_($url, false));

		// Flush the data from the session.
		$this->app->setUserState('com_sot.edit.purchaseorder.data', null);

		// Invoke the postSave method to allow for the child class to access the model.
		$this->postSaveHook($model, $data);
	}

	/**
	 * Method to abort current operation
	 *
	 * @return void
	 *
	 * @throws \Exception
	 */
	public function cancel($key = NULL)
	{

		// Get the current edit id.
		$editId = (int) $this->app->getUserState('com_sot.edit.purchaseorder.id');

		// Get the model.
		$model = $this->getModel('Purchaseorderform', 'Site');

		// Check in the item
		if ($editId) {
			$model->checkin($editId);
		}

		$menu = Factory::getApplication()->getMenu();
		$item = $menu->getActive();
		$url  = (empty($item->link) ? 'index.php?option=com_sot&view=purchaseorders' : $item->link);
		$this->setRedirect(Route::_($url, false));
	}

	/**
	 * Method to remove data
	 *
	 * @return  void
	 *
	 * @throws  \Exception
	 *
	 * @since   1.0.0
	 */
	public function remove()
	{
		$model = $this->getModel('Purchaseorderform', 'Site');
		$pk    = $this->input->getInt('id');

		// Attempt to save the data
		try {
			// Check in before delete
			$return = $model->checkin($return);
			// Clear id from the session.
			$this->app->setUserState('com_sot.edit.purchaseorder.id', null);

			$menu = $this->app->getMenu();
			$item = $menu->getActive();
			$url = (empty($item->link) ? 'index.php?option=com_sot&view=purchaseorders' : $item->link);

			if ($return) {
				$model->delete($pk);
				$this->setMessage(Text::_('COM_SOT_ITEM_DELETED_SUCCESSFULLY'));
			} else {
				$this->setMessage(Text::_('COM_SOT_ITEM_DELETED_UNSUCCESSFULLY'), 'warning');
			}


			$this->setRedirect(Route::_($url, false));
			// Flush the data from the session.
			$this->app->setUserState('com_sot.edit.purchaseorder.data', null);
		} catch (\Exception $e) {
			$errorType = ($e->getCode() == '404') ? 'error' : 'warning';
			$this->setMessage($e->getMessage(), $errorType);
			$this->setRedirect('index.php?option=com_sot&view=purchaseorders');
		}
	}

	public function getModelsByComponent()
	{
		// Safety check to ensure it's a JSON call
		$this->input->set('format', 'json');

		$componentId = $this->input->getInt('component_id', 0);
		$db = Factory::getDbo();

		$query = $db->getQuery(true)
			->select($db->quoteName('id', 'key'))
			->select($db->quoteName('model_name', 'value')) // Change to your actual column name
			->from($db->quoteName('#__product_catalogs'))     // Change to your actual table name
			->where($db->quoteName('component') . ' = ' . (int) $componentId)
			->where($db->quoteName('state') . ' = 1')
			->order($db->quoteName('model_name') . ' ASC');

		$db->setQuery($query);
		$results = $db->loadObjectList();

		// Output clean JSON back to JavaScript
		echo json_encode([
			'success' => true,
			'data'    => $results
		]);

		Factory::getApplication()->close();
	}


	/**
	 * Function that allows child controller access to model data
	 * after the data has been saved.
	 *
	 * @param   BaseDatabaseModel  $model      The data model object.
	 * @param   array              $validData  The validated data.
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
	protected function postSaveHook(BaseDatabaseModel $model, $validData = array()) {}
}
