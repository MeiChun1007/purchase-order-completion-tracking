<?php

/**
 * @version    CVS: 1.0.3
 * @package    Com_Sot
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Sot\Component\Sot\Site\Helper;

defined('_JEXEC') or die;

/**
 * Pure calculation helpers for the SOT Summary and SOT Daily Tracker views.
 *
 * Nothing in here touches the database or Joomla, so every rule can be unit tested.
 * All dates are 'Y-m-d' strings.
 *
 * @since  1.0.3
 */
final class SotReport
{
	/** #__incoming_orders.remark */
	public const IN_WO = 1;
	public const IN_PR = 2;

	/** #__outgoing_orders.remark */
	public const OUT_SCRAP = 1;
	public const OUT_FG    = 2;
	public const OUT_NC    = 3;

	/** Status keys */
	public const BEHIND   = 'behind';
	public const ON_TRACK = 'on_track';
	public const CLOSED   = 'closed';
	public const NO_PO    = 'no_po';

	/** ISO-8601 weekdays that are never working days (7 = Sunday). Saturday is a working day. */
	public const OFF_WEEKDAYS = [7];

	// carried over
	public const IN_CARRY  = 7;   // #__incoming_orders.remark: carried over
	public const OUT_CARRY = 4;   // #__outgoing_orders.remark: carried over

	/**
	 * Is the date a non-working day (off weekday or a row in #__calendar_holidays)?
	 *
	 * @param   string  $ymd       Date
	 * @param   array   $holidays  Holidays keyed by 'Y-m-d'
	 */
	public static function isOffDay(string $ymd, array $holidays): bool
	{
		if (isset($holidays[$ymd])) {
			return true;
		}

		return in_array((int) (new \DateTimeImmutable($ymd))->format('N'), self::OFF_WEEKDAYS, true);
	}

	/**
	 * Every calendar date of a month.
	 *
	 * @return  string[]
	 */
	public static function monthDates(int $year, int $month): array
	{
		$days = (int) (new \DateTimeImmutable(sprintf('%04d-%02d-01', $year, $month)))->format('t');
		$out  = array();

		for ($d = 1; $d <= $days; $d++) {
			$out[] = sprintf('%04d-%02d-%02d', $year, $month, $d);
		}

		return $out;
	}

	/**
	 * Working dates of a month (not Sunday, not a holiday), in order.
	 *
	 * @return  string[]
	 */
	public static function workingDates(int $year, int $month, array $holidays): array
	{
		return array_values(array_filter(
			self::monthDates($year, $month),
			static function ($d) use ($holidays) {
				return !self::isOffDay($d, $holidays);
			}
		));
	}

	/**
	 * Number of working days a PO runs for. The PO's own working_days wins, but it can never
	 * exceed what the calendar actually offers in that month.
	 */
	public static function effectiveLimit(int $poWorkingDays, int $calendarWorkingDays): int
	{
		return $poWorkingDays > 0 ? min($poWorkingDays, $calendarWorkingDays) : $calendarWorkingDays;
	}

	/**
	 * Planned quantity per date for one PO line.
	 * The daily plan runs on the first N working days of the month and the last day is trimmed,
	 * so the plan always adds up to exactly total_po (daily = ceil(total / N) can overshoot).
	 *
	 * @return  array  date => quantity
	 */
	public static function planSchedule(int $year, int $month, array $holidays, int $totalPo, int $dailyPlan, int $poWorkingDays): array
	{
		$dates = self::workingDates($year, $month, $holidays);
		$limit = self::effectiveLimit($poWorkingDays, count($dates));

		if ($limit <= 0 || $totalPo <= 0) {
			return array();
		}

		if ($dailyPlan <= 0) {
			$dailyPlan = (int) ceil($totalPo / $limit);
		}

		$remaining = $totalPo;
		$plan      = array();

		foreach (array_slice($dates, 0, $limit) as $d) {
			$qty        = min($dailyPlan, $remaining);
			$plan[$d]   = $qty;
			$remaining -= $qty;

			if ($remaining <= 0) {
				break;
			}
		}

		return $plan;
	}

	/**
	 * Add one date => quantity map into another.
	 */
	public static function mergePlan(array $a, array $b): array
	{
		foreach ($b as $d => $q) {
			$a[$d] = ($a[$d] ?? 0) + $q;
		}

		return $a;
	}

	/**
	 * Working days elapsed in a month up to and including $asOf, capped at the PO's limit.
	 */
	public static function elapsedWorkingDays(int $year, int $month, array $holidays, string $asOf, int $poWorkingDays): int
	{
		$dates = self::workingDates($year, $month, $holidays);
		$limit = self::effectiveLimit($poWorkingDays, count($dates));
		$n     = 0;

		foreach (array_slice($dates, 0, $limit) as $d) {
			if ($d > $asOf) {
				break;
			}

			$n++;
		}

		return $n;
	}

	/**
	 * Sum of a date => quantity map up to and including $asOf.
	 */
	public static function sumUpTo(array $byDate, string $asOf): int
	{
		$sum = 0;

		foreach ($byDate as $d => $q) {
			if ($d <= $asOf) {
				$sum += $q;
			}
		}

		return (int) $sum;
	}

	/**
	 * Closed when nothing is left to ship, behind when FG is below plan to date, otherwise on track.
	 */
	public static function status(int $totalPo, int $outgoingFg, int $planToDate): string
	{
		// Nothing ordered this month: movements may still exist, but there is nothing to measure against
		if ($totalPo <= 0) {
			return self::NO_PO;
		}

		if ($outgoingFg >= $totalPo) {
			return self::CLOSED;
		}

		return $outgoingFg < $planToDate ? self::BEHIND : self::ON_TRACK;
	}

	/**
	 * Quantity that must ship every remaining working day to finish the PO, or null when it
	 * does not apply (closed, or no working days left).
	 */
	public static function needPerDay(int $balance, int $daysLeft): ?int
	{
		if ($balance <= 0 || $daysLeft <= 0) {
			return null;
		}

		return (int) ceil($balance / $daysLeft);
	}

	/**
	 * Column buckets for the daily view. Granularity 'day' gives one column per date,
	 * 'month' one column per calendar month (used by the Year period).
	 *
	 * @return  array[]  Each: key, start, end, off, note
	 */
	public static function buckets(string $from, string $to, string $granularity, array $holidays): array
	{
		$out = array();
		$cur = new \DateTimeImmutable($from);
		$end = new \DateTimeImmutable($to);

		if ($granularity === 'month') {
			while ($cur <= $end) {
				$monthEnd = $cur->modify('last day of this month');
				$bucketEnd = $monthEnd > $end ? $end : $monthEnd;

				$out[] = array(
					'key'   => $cur->format('Y-m'),
					'start' => $cur->format('Y-m-d'),
					'end'   => $bucketEnd->format('Y-m-d'),
					'off'   => false,
					'note'  => '',
				);

				$cur = $monthEnd->modify('+1 day');
			}

			return $out;
		}

		while ($cur <= $end) {
			$d = $cur->format('Y-m-d');

			$out[] = array(
				'key'   => $d,
				'start' => $d,
				'end'   => $d,
				'off'   => self::isOffDay($d, $holidays),
				'note'  => isset($holidays[$d]) ? (string) $holidays[$d]['note'] : '',
			);

			$cur = $cur->modify('+1 day');
		}

		return $out;
	}

	/**
	 * Bucket key for a date.
	 */
	public static function bucketKey(string $ymd, string $granularity): string
	{
		return $granularity === 'month' ? substr($ymd, 0, 7) : $ymd;
	}

	/**
	 * Valid 'Y-m-d' date or null.
	 */
	public static function validDate($value): ?string
	{
		if (!is_string($value) || !preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $value, $m)) {
			return null;
		}

		return checkdate((int) $m[2], (int) $m[3], (int) $m[1]) ? $value : null;
	}
}
