<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Outgoing
 * @author     Meichun <qa.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Outgoing\Component\Outgoing\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Table\Table;
use \Joomla\CMS\MVC\Model\FormModel;
use \Joomla\CMS\Object\CMSObject;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\DatabaseInterface;
use \Joomla\Database\ParameterType;
use \Joomla\CMS\Event\Model;
use \Joomla\CMS\Plugin\PluginHelper;
use \Joomla\CMS\Filesystem\File;

/**
 * Outgoing model.
 *
 * @since  1.0.0
 */
class OutgoingorderformModel extends FormModel
{
	private $item = null;

	

	

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 *
	 * @throws  \Exception
	 */
	protected function populateState()
	{
		$app = Factory::getApplication('com_outgoing');

		// Load state from the request userState on edit or from the passed variable on default
		if (Factory::getApplication()->input->get('layout') == 'edit')
		{
			$id = Factory::getApplication()->getUserState('com_outgoing.edit.outgoingorder.id');
		}
		else
		{
			$id = Factory::getApplication()->input->get('id');
			Factory::getApplication()->setUserState('com_outgoing.edit.outgoingorder.id', $id);
		}

		$this->setState('outgoingorder.id', $id);

		// Load the parameters.
		$params       = $app->getParams();
		$params_array = $params->toArray();

		if (isset($params_array['item_id']))
		{
				$this->setState('outgoingorder.id', $params_array['item_id']);
		}

		$this->setState('params', $params);
	}

	/**
	 * Method to get an ojbect.
	 *
	 * @param   integer $id The id of the object to get.
	 *
	 * @return  CMSObject|boolean CMSObject on success, false on failure.
	 *
	 * @throws  \Exception
	 */
	public function getItem($id = null)
	{
		if ($this->item === null)
		{
			$this->item = false;

			if (empty($id))
			{
				$id = $this->getState('outgoingorder.id');
			}

			// Get a level row instance.
			$table = $this->getTable();
			$properties = $table->getProperties();
			$this->item = ArrayHelper::toObject($properties, CMSObject::class);

			if ($table !== false && $table->load($id) && !empty($table->id))
			{
				$user = Factory::getApplication()->getIdentity();
				$id   = $table->id;
				

				$canEdit = $user->authorise('core.edit', 'com_outgoing') || $user->authorise('core.create', 'com_outgoing');

				if (!$canEdit && $user->authorise('core.edit.own', 'com_outgoing'))
				{
					$canEdit = $user->id == $table->created_by;
				}

				if (!$canEdit)
				{
					throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), 403);
				}

				// Check published state.
				if ($published = $this->getState('filter.published'))
				{
					if (isset($table->state) && $table->state != $published)
					{
						return $this->item;
					}
				}

				// Convert the Table to a clean CMSObject.
				$properties = $table->getProperties(1);
				$this->item = ArrayHelper::toObject($properties, CMSObject::class);
				

				
			}
		}

		return $this->item;
	}

	/**
	 * Method to get the table
	 *
	 * @param   string $type   Name of the Table class
	 * @param   string $prefix Optional prefix for the table class name
	 * @param   array  $config Optional configuration array for Table object
	 *
	 * @return  Table|boolean Table if found, boolean false on failure
	 */
	public function getTable($type = 'Outgoingorder', $prefix = 'Administrator', $config = array())
	{
		return parent::getTable($type, $prefix, $config);
	}

	/**
	 * Get an item by alias
	 *
	 * @param   string $alias Alias string
	 *
	 * @return int Element id
	 */
	public function getItemIdByAlias($alias)
	{
		$table      = $this->getTable();
		$properties = $table->getProperties();

		if (!in_array('alias', $properties))
		{
				return null;
		}

		$table->load(array('alias' => $alias));
		$id = $table->id;

		
			return $id;
		
	}

	/**
	 * Method to check in an item.
	 *
	 * @param   integer $id The id of the row to check out.
	 *
	 * @return  boolean True on success, false on failure.
	 *
	 * @since   1.0.0
	 */
	public function checkin($id = null)
	{
		// Get the id.
		$id = (!empty($id)) ? $id : (int) $this->getState('outgoingorder.id');
		
		if ($id)
		{
			// Initialise the table
			$table = $this->getTable();

			// Attempt to check the row in.
			if (method_exists($table, 'checkin'))
			{
				if (!$table->checkin($id))
				{
					return false;
				}
			}
		}

		return true;
		
	}

	/**
	 * Method to check out an item for editing.
	 *
	 * @param   integer $id The id of the row to check out.
	 *
	 * @return  boolean True on success, false on failure.
	 *
	 * @since   1.0.0
	 */
	public function checkout($id = null)
	{
		// Get the user id.
		$id = (!empty($id)) ? $id : (int) $this->getState('outgoingorder.id');
		
		if ($id)
		{
			// Initialise the table
			$table = $this->getTable();

			// Get the current user object.
			$user = Factory::getApplication()->getIdentity();

			// Attempt to check the row out.
			if (method_exists($table, 'checkout'))
			{
				if (!$table->checkout($user->get('id'), $id))
				{
					return false;
				}
			}
		}

		return true;
		
	}

	/**
	 * Method to get the profile form.
	 *
	 * The base form is loaded from XML
	 *
	 * @param   array   $data     An optional array of data for the form to interogate.
	 * @param   boolean $loadData True if the form is to load its own data (default case), false if not.
	 *
	 * @return  \Joomla\CMS\Form\Form|boolean  A Form object on success, false on failure
	 *
	 * @since   1.0.0
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_outgoing.outgoingorder', 'outgoingorderform', array(
						'control'   => 'jform',
						'load_data' => $loadData
				)
		);

		if (empty($form))
		{
				return false;
		}

		return $form;
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return  array  The default data is an empty array.
	 * @since   1.0.0
	 */
	protected function loadFormData()
	{
		$data = Factory::getApplication()->getUserState('com_outgoing.edit.outgoingorder.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}

		if ($data)
		{
			

			return $data;
		}

		return array();
	}

	/**
	 * Method to save the form data.
	 *
	 * @param   array $data The form data
	 *
	 * @return  bool
	 *
	 * @throws  \Exception
	 * @since   1.0.0
	 */
	public function save($data)
	{
		$id    = (!empty($data['id'])) ? $data['id'] : (int) $this->getState('outgoingorder.id');
		$state = (!empty($data['state'])) ? 1 : 0;
		$user  = Factory::getApplication()->getIdentity();
		$isNew = empty($id);

		
		if ($id)
		{
			// Check the user can edit this item
			$authorised = $user->authorise('core.edit', 'com_outgoing') || $authorised = $user->authorise('core.edit.own', 'com_outgoing');
		}
		else
		{
			// Check the user can create new items in this section
			$authorised = $user->authorise('core.create', 'com_outgoing');
		}

		if ($authorised !== true)
		{
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), 403);
		}

		$table = $this->getTable();

		if (!empty($id)) {
			$table->load($id);
		}

		// --- Auto doc no: the remark decides, never the posted value ---
		$prefix     = $this->docNoPrefixFor($data['remark'] ?? null);
		$needsDocNo = false;

		if ($prefix !== null) {
			$current = trim((string) $table->doc_no);

			if ($this->isGeneratedDocNo($current, $prefix)) {
				// Editing a record that already has its number: keep it
				$data['doc_no'] = $current;
			} elseif (!empty($table->id)) {
				// Existing record without a generated number: its id is already known
				$data['doc_no'] = $this->buildDocNo($prefix, $data['date'] ?? $table->date ?? null, $table->id);
			} else {
				// New record: id not known yet, so save with a unique placeholder and fix it after the insert
				$needsDocNo     = true;
				$data['doc_no'] = 'AUTO-' . uniqid();
			}
		}

		try {
			if ($table->save($data) === true) {
				if ($needsDocNo) {
					$docNo  = $this->buildDocNo($prefix, $table->date ?? null, $table->id);
					$db     = Factory::getContainer()->get(DatabaseInterface::class);
					$rowId  = (int) $table->id;

					$db->setQuery(
						$db->getQuery(true)
							->update($db->quoteName($table->getTableName()))
							->set($db->quoteName('doc_no') . ' = :doc')
							->where($db->quoteName($table->getKeyName()) . ' = :id')
							->bind(':doc', $docNo)
							->bind(':id', $rowId, ParameterType::INTEGER)
					)->execute();

					$table->doc_no  = $docNo;
					$data['doc_no'] = $docNo;
				}

				$dispatcher = $this->getDispatcher();

				PluginHelper::importPlugin('content', null, true, $dispatcher);

				$dispatcher->dispatch('onContentAfterSave', new Model\AfterSaveEvent('onContentAfterSave', [
					'context' => 'com_outgoing.outgoingorder',
					'subject' => $table,
					'isNew'   => $isNew,
					'data'    => $data,
				]));

				return $table->id;
			} else {
				Factory::getApplication()->enqueueMessage($table->getError(), 'error');

				return false;
			}
		} catch (\Exception $e) {
			Factory::getApplication()->enqueueMessage($e->getMessage(), 'error');

			return false;
		}
			
	}

	/**
	 * Method to delete data
	 *
	 * @param   int $pk Item primary key
	 *
	 * @return  int  The id of the deleted item
	 *
	 * @throws  \Exception
	 *
	 * @since   1.0.0
	 */
	public function delete($id)
	{
		$user = Factory::getApplication()->getIdentity();

		
		if (empty($id))
		{
			$id = (int) $this->getState('outgoingorder.id');
		}

		if ($id == 0 || $this->getItem($id) == null)
		{
				throw new \Exception(Text::_('COM_OUTGOING_ITEM_DOESNT_EXIST'), 404);
		}

		if ($user->authorise('core.delete', 'com_outgoing') !== true)
		{
				throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), 403);
		}

		$table = $this->getTable();

		

		if ($table->delete($id) !== true)
		{
				throw new \Exception(Text::_('JERROR_FAILED'), 501);
		}

		

		return $id;
		
	}

	/**
	 * Check if data can be saved
	 *
	 * @return bool
	 */
	public function getCanSave()
	{
		$table = $this->getTable();

		return $table !== false;
	}

		/**
	 * Remark key => doc no prefix. A new record with one of these remarks gets its
	 * doc no generated automatically. Add more pairs here later, e.g. '9' => 'XY'.
	 */
	private const DOC_NO_PREFIXES = ['4' => 'AO'];

	/** Digits of the running number after the dash: AO20261102-001, -002 ... */
	private const DOC_NO_DIGITS = 5;


	/**
	 * Prefix for the selected remark, or null when this remark does not auto-generate.
	 */
	protected function docNoPrefixFor($remark)
	{
		if (is_array($remark)) {
			$remark = reset($remark);
		}

		$remark = trim((string) $remark);

		return self::DOC_NO_PREFIXES[$remark] ?? null;
	}

	/**
	 * Is $docNo already a generated number for $prefix?
	 * Accepts AO261102-0042, AO20261102-001 and the old AO00001.
	 */
	protected function isGeneratedDocNo($docNo, $prefix)
	{
		return $docNo !== ''
			&& preg_match('/^' . preg_quote($prefix, '/') . '(\d+|\d{6,8}-\d+)$/', $docNo) === 1;
	}

	/**
	 * prefix + date (ymd) + "-" + record id, e.g. AO261102-0042.
	 * $date is the record's own date; falls back to today (Malaysia time).
	 */
	protected function buildDocNo($prefix, $date, $id)
	{
		$tz = 'Asia/Kuala_Lumpur';

		try {
			$when = Factory::getDate(!empty($date) && strpos((string) $date, '0000') !== 0 ? $date : 'now', $tz);
		} catch (\Exception $e) {
			$when = Factory::getDate('now', $tz);
		}

		return $prefix . $when->format('ymd', true) . '-'
			. str_pad((string) $id, self::DOC_NO_DIGITS, '0', STR_PAD_LEFT);
	}
	/**
	 * The doc no field is read-only (and may arrive empty) when the remark auto-generates it,
	 * so give it a placeholder to get past the form's "required" check.
	 * save() replaces the placeholder with the real number.
	 */
	public function validate($form, $data, $group = null)
	{
		if ($this->docNoPrefixFor($data['remark'] ?? null) !== null && trim((string) ($data['doc_no'] ?? '')) === '') {
			$data['doc_no'] = 'AUTO';
		}

		return parent::validate($form, $data, $group);
	}
	
}
