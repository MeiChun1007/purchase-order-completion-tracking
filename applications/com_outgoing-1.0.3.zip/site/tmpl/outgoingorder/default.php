<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Outgoing
 * @author     Meichun <qa.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Session\Session;
use Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Layout\LayoutHelper;

$canEdit = Factory::getApplication()->getIdentity()->authorise('core.edit', 'com_outgoing');

if (!$canEdit && Factory::getApplication()->getIdentity()->authorise('core.edit.own', 'com_outgoing')) {
	$canEdit = Factory::getApplication()->getIdentity()->id == $this->item->created_by;
}

// Import CSS
$wa = $this->document->getWebAssetManager();

$cssFile = JPATH_ROOT . '/media/com_outgoing/css/list.css';
$wa->registerAndUseStyle(
	'com_outgoing.list',
	Uri::root() . 'media/com_outgoing/css/list.css',
	['version' => (string) @filemtime($cssFile)]
);

?>

<div class="item_fields">
	<?php if ($this->params->get('show_page_heading')) : ?>
		<div class="page-header">
			<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
		</div>
	<?php endif; ?>
	<div class="header mb-4">
		<h1 class="header__title"><?php echo Text::_('COM_OUTGOINGORDER_TITLE'); ?></h1>
	</div>

	<!-- Back button -->
	<div style="display: flex; justify-content: flex-end; margin-bottom: 20px;">
		<a class="btn btn-danger ms-auto" href="<?php echo Route::_('index.php?option=com_outgoing&view=outgoingorders'); ?>">
			<i class="fas fa-angle-left"></i><?php echo Text::_("  Back"); ?>
		</a>
	</div>

	<table class="table">

		<tr>
			<th><?php echo Text::_('COM_OUTGOING_FORM_LBL_OUTGOINGORDER_DOC_NO'); ?></th>
			<td><?php echo $this->item->doc_no; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_OUTGOING_FORM_LBL_OUTGOINGORDER_DATE'); ?></th>
			<td><?php echo $this->item->date; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_OUTGOING_FORM_LBL_OUTGOINGORDER_RAW_MODEL'); ?></th>
			<td><?php echo $this->item->raw_model; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_OUTGOING_FORM_LBL_OUTGOINGORDER_PART'); ?></th>
			<!-- <td><?php echo $this->item->part; ?></td> -->
			<td><?php echo $this->item->part_name; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_OUTGOING_FORM_LBL_OUTGOINGORDER_MODEL'); ?></th>
			<!-- <td><?php echo $this->item->model; ?></td> -->
			<td><?php echo $this->item->model_name; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_OUTGOING_FORM_LBL_OUTGOINGORDER_QUANTITY'); ?></th>
			<td><?php echo $this->item->quantity; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_OUTGOING_FORM_LBL_OUTGOINGORDER_REMARK'); ?></th>
			<!-- <td><?php echo $this->item->remark; ?></td> -->
			<td><?php echo $this->item->remark_name; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_OUTGOING_FORM_LBL_OUTGOINGORDER_TERMS'); ?></th>
			<td><?php echo $this->item->terms; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_OUTGOING_FORM_LBL_OUTGOINGORDER_DESCRIPTION'); ?></th>
			<td><?php echo nl2br($this->item->description); ?></td>
		</tr>

	</table>

</div>
<div class="button d-flex w-100 mb-3" style="padding-top: 10px; gap:3px; justify-content: space-between;">

	<!-- Delete button -->
	<?php if (Factory::getApplication()->getIdentity()->authorise('core.delete', 'com_outgoing.outgoingorder.' . $this->item->id)) : ?>

		<a class="btn btn-danger" rel="noopener noreferrer" href="#deleteModal" role="button" data-bs-toggle="modal">
			<i class="fas fa-trash me-1"></i><?php echo Text::_("COM_OUTGOING_DELETE_ITEM"); ?>
		</a>

		<?php echo HTMLHelper::_(
			'bootstrap.renderModal',
			'deleteModal',
			array(
				'title'  => Text::_('COM_OUTGOING_DELETE_ITEM'),
				'height' => '50%',
				'width'  => '20%',

				'modalWidth'  => '50',
				'bodyHeight'  => '100',
				'footer' => '<button class="btn btn-outline-primary" data-bs-dismiss="modal">Close</button><a href="' . Route::_('index.php?option=com_outgoing&task=outgoingorder.remove&id=' . $this->item->id, false, 2) . '" class="btn btn-danger">' . Text::_('COM_OUTGOING_DELETE_ITEM') . '</a>'
			),
			Text::sprintf('COM_OUTGOING_DELETE_CONFIRM', $this->item->id)
		); ?>

	<?php endif; ?>

	<!-- Edit button -->
	<?php if ($canEdit): ?>
		<a class="btn btn-outline-primary" href="<?php echo Route::_('index.php?option=com_outgoing&task=outgoingorder.edit&id=' . $this->item->id); ?>"><i class="fas fa-pen me-1"></i><?php echo Text::_("COM_OUTGOING_EDIT_ITEM"); ?></a>
	<?php endif; ?>

</div>