<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Outgoing
 * @author     Meichun <qa.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Outgoing\Component\Outgoing\Site\Helper\OutgoingHelper;

$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
	->useScript('form.validate');
HTMLHelper::_('bootstrap.tooltip');

// Load admin language file
$lang = Factory::getLanguage();
$lang->load('com_outgoing', JPATH_SITE);

$user    = Factory::getApplication()->getIdentity();
$canEdit = OutgoingHelper::canUserEdit($this->item, $user);

// Resolve the existing (single) selected IDs for the cascading fields, so we can
// re-populate & re-select the correct dependent options on page load (edit mode).
// component/model/vendor/remark may be stored as arrays (multi-value support),
// so just take the first value for the purpose of driving the cascade.
$existingComponentId = '';
if (isset($this->item->part)) {
	$componentVal = $this->item->part;
	$existingComponentId = is_array($componentVal) ? (reset($componentVal) ?: '') : $componentVal;
}

$existingModelId = '';
if (isset($this->item->model)) {
	$modelVal = $this->item->model;
	$existingModelId = is_array($modelVal) ? (reset($modelVal) ?: '') : $modelVal;
}

?>

<div class="outgoingorder-edit front-end-edit">

	<?php if ($this->params->get('show_page_heading')) : ?>
		<div class="page-header">
			<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
		</div>
	<?php endif; ?>
	<?php if (!$canEdit) : ?>
		<h3>
			<?php throw new \Exception(Text::_('COM_OUTGOING_ERROR_MESSAGE_NOT_AUTHORISED'), 403); ?>
		</h3>
	<?php else : ?>
		<?php if (!empty($this->item->id)): ?>
			<!-- <h1><?php echo Text::sprintf('COM_OUTGOING_EDIT_ITEM_TITLE', $this->item->id); ?></h1> -->
			<h1><?php echo Text::sprintf('COM_OUTGOING_EDIT_ITEM_TITLE', $this->item->doc_no); ?></h1>
		<?php else: ?>
			<h1><?php echo Text::_('COM_OUTGOING_ADD_ITEM_TITLE'); ?></h1>
		<?php endif; ?>

		<form id="form-outgoingorder"
			action="<?php echo Route::_('index.php?option=com_outgoing&task=outgoingorderform.save'); ?>"
			method="post" class="form-validate form-horizontal" enctype="multipart/form-data">

			<input type="hidden" name="jform[id]" value="<?php echo isset($this->item->id) ? $this->item->id : ''; ?>" />

			<input type="hidden" name="jform[state]" value="<?php echo isset($this->item->state) ? $this->item->state : ''; ?>" />

			<?php echo $this->form->getInput('created_by'); ?>
			<?php echo $this->form->getInput('modified_by'); ?>
			<?php echo HTMLHelper::_('uitab.startTabSet', 'myTab', array('active' => 'outgoingorder')); ?>
			<?php echo HTMLHelper::_('uitab.addTab', 'myTab', 'outgoingorder', Text::_('COM_OUTGOING_TAB_OUTGOINGORDER', true)); ?>
			<?php echo $this->form->renderField('remark'); ?>

			<?php echo $this->form->renderField('doc_no'); ?>

			<?php echo $this->form->renderField('date'); ?>

			<!-- <?php echo $this->form->renderField('raw_model'); ?> -->

			<?php echo $this->form->renderField('part'); ?>

			<?php echo $this->form->renderField('model'); ?>

			<?php echo $this->form->renderField('quantity'); ?>

			<?php echo $this->form->renderField('terms'); ?>

			<?php echo $this->form->renderField('description'); ?>

			<?php echo HTMLHelper::_('uitab.endTab'); ?>
			<div class="control-group" style="margin-top: 1rem;">
				<div class="controls d-flex justify-content-end" style="gap: 3px;">

					<a class="btn btn-danger"
						href="<?php echo Route::_('index.php?option=com_outgoing&task=outgoingorderform.cancel'); ?>"
						title="<?php echo Text::_('JCANCEL'); ?>">
						<span class="fas fa-times" aria-hidden="true"></span>
						<?php echo Text::_('JCANCEL'); ?>
					</a>
					<?php if ($this->canSave): ?>
						<button type="submit" class="validate btn btn-primary">
							<span class="fas fa-check" aria-hidden="true"></span>
							<?php echo Text::_('JSUBMIT'); ?>
						</button>
					<?php endif; ?>
				</div>
			</div>

			<input type="hidden" name="option" value="com_outgoing" />
			<input type="hidden" name="task"
				value="outgoingorderform.save" />
			<?php echo HTMLHelper::_('form.token'); ?>
		</form>
	<?php endif; ?>
</div>

<script>
	document.addEventListener('DOMContentLoaded', function() {

		// Existing saved IDs (edit mode) — empty strings on the Add form
		const existingComponentId = <?php echo json_encode((string) $existingComponentId); ?>;
		const existingModelId = <?php echo json_encode((string) $existingModelId); ?>;

		// Debug: confirm the PHP-resolved values are reaching the client correctly
		console.log('existingComponentId:', existingComponentId);
		console.log('existingModelId:', existingModelId);

		/**
		 * Fetch and populate the Model dropdown for a given Component.
		 * If selectedModelId is provided, that option is pre-selected
		 * (used on page load to restore the saved value).
		 */
		function populateModelField(componentId, selectedModelId) {
			selectedModelId = selectedModelId || '';

			const modelField = document.querySelector('select[name="jform[model]"]');
			if (!modelField) {
				console.error("Could not find the model select element by name attribute.");
				return;
			}

			const modelWrapper = modelField.closest('joomla-field-fancy-select');

			modelField.innerHTML = '<option value="">Select Model</option>';

			if (modelWrapper && modelWrapper.choicesInstance) {
				modelWrapper.choicesInstance.clearChoices();
				modelWrapper.choicesInstance.setChoices([{
					value: '',
					label: 'Select Model',
					selected: true
				}], 'value', 'label', true);
			}

			if (!componentId) return;

			fetch(`index.php?option=com_outgoing&task=outgoingorderform.getModelsByComponent&component_id=${componentId}&format=json`)
				.then(response => response.json())
				.then(data => {
					if (data && data.success && data.data) {

						data.data.forEach(model => {
							const option = new Option(model.value, model.key);
							if (String(model.key) === String(selectedModelId)) {
								option.selected = true;
							}
							modelField.add(option);
						});

						if (modelWrapper && modelWrapper.choicesInstance) {
							const newChoices = data.data.map(m => ({
								value: String(m.key),
								label: String(m.value),
								selected: String(m.key) === String(selectedModelId)
							}));

							modelWrapper.choicesInstance.setChoices(newChoices, 'value', 'label', true);
						}
					}
				})
				.catch(error => console.error('Error Syncing JSON payload:', error));
		}


		// --- Component -> Model cascade ---
		const componentField = document.querySelector('select[name="jform[part]"]');

		document.addEventListener('change', function(event) {
			if (componentField && event.target === componentField) {
				populateModelField(componentField.value);
			}

		});

		// --- Initialize on page load (edit mode): restore dependent dropdowns
		// to match the already-saved Component/Vendor selections ---
		if (existingComponentId) {
			populateModelField(existingComponentId, existingModelId);
		}

		// remark key => doc no prefix (keep in step with DOC_NO_PREFIXES in the model)
		const autoDocRemarks = {
			"4": "AO"
		};

		const remarkField = document.querySelector('select[name="jform[remark]"]');
		const docNoField = document.querySelector('[name="jform[doc_no]"]');

		if (!remarkField || !docNoField) {
			return;
		}

		const wasRequired = docNoField.required || docNoField.classList.contains('required');

		function applyDocNoRule() {
			const prefix = autoDocRemarks[String(remarkField.value)];

			if (prefix) {
				const v = docNoField.value;
				const keep = v.indexOf(prefix) === 0 && /^[0-9]+$/.test(v.slice(prefix.length));

				if (!keep) {
					docNoField.value = '';
				}

				docNoField.readOnly = true;
				docNoField.placeholder = prefix + ' number is generated when you save';
				docNoField.style.backgroundColor = '#e9ecef';

				// an empty read-only field must not trip the browser's "required" check
				docNoField.required = false;
				docNoField.classList.remove('required');
				docNoField.removeAttribute('aria-required');
			} else {
				docNoField.readOnly = false;
				docNoField.placeholder = '';
				docNoField.style.backgroundColor = '';

				if (wasRequired) {
					docNoField.required = true;
					docNoField.classList.add('required');
					docNoField.setAttribute('aria-required', 'true');
				}
			}
		}

		// Choices.js / fancy-select fires a normal change event on the <select>
		document.addEventListener('change', function(event) {
			if (event.target === remarkField) {
				applyDocNoRule();
			}
		});

		applyDocNoRule();

	});
</script>