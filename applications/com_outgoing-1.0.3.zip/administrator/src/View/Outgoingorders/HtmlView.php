<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Outgoing
 * @author     Meichun <qa.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Outgoing\Component\Outgoing\Administrator\View\Outgoingorders;
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use \Outgoing\Component\Outgoing\Administrator\Helper\OutgoingHelper;
use \Joomla\CMS\Toolbar\Toolbar;
use \Joomla\CMS\Toolbar\ToolbarHelper;
use \Joomla\CMS\Language\Text;
use \Joomla\Component\Content\Administrator\Extension\ContentComponent;
use \Joomla\CMS\Form\Form;
use \Joomla\CMS\HTML\Helpers\Sidebar;
/**
 * View class for a list of Outgoingorders.
 *
 * @since  1.0.0
 */
class HtmlView extends BaseHtmlView
{
	protected $items;

	protected $pagination;

	protected $state;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return void
	 *
	 * @throws \Exception
	 */
	public function display($tpl = null)
	{
		$this->state = $this->get('State');
		$this->items = $this->get('Items');
		$this->pagination = $this->get('Pagination');
		$this->filterForm = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new \Exception(implode("\n", $errors));
		}

		$this->addToolbar();

		$this->sidebar = Sidebar::render();
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	protected function addToolbar()
	{
		$state = $this->get('State');
		$canDo = OutgoingHelper::getActions();

		ToolbarHelper::title(Text::_('COM_OUTGOING_TITLE_OUTGOINGORDERS'), "generic");

		$toolbar = Toolbar::getInstance('toolbar');

		// Check if the form exists before showing the add/edit buttons
		$formPath = JPATH_COMPONENT_ADMINISTRATOR . '/src/View/Outgoingorders';

		if (file_exists($formPath))
		{
			if ($canDo->get('core.create'))
			{
				$toolbar->addNew('outgoingorder.add');
			}
		}

		if ($canDo->get('core.edit.state'))
		{
			$dropdown = $toolbar->dropdownButton('status-group')
				->text('JTOOLBAR_CHANGE_STATUS')
				->toggleSplit(false)
				->icon('fas fa-ellipsis-h')
				->buttonClass('btn btn-action')
				->listCheck(true);

			$childBar = $dropdown->getChildToolbar();

			if (isset($this->items[0]->state))
			{
				$childBar->publish('outgoingorders.publish')->listCheck(true);
				$childBar->unpublish('outgoingorders.unpublish')->listCheck(true);
				$childBar->archive('outgoingorders.archive')->listCheck(true);
			}
			elseif (isset($this->items[0]))
			{
				// If this component does not use state then show a direct delete button as we can not trash
				$toolbar->delete('outgoingorders.delete')
				->text('JTOOLBAR_EMPTY_TRASH')
				->message('JGLOBAL_CONFIRM_DELETE')
				->listCheck(true);
			}

			$childBar->standardButton('duplicate')
				->text('JTOOLBAR_DUPLICATE')
				->icon('fas fa-copy')
				->task('outgoingorders.duplicate')
				->listCheck(true);

			if (isset($this->items[0]->checked_out))
			{
				$childBar->checkin('outgoingorders.checkin')->listCheck(true);
			}

			if (isset($this->items[0]->state))
			{
				$childBar->trash('outgoingorders.trash')->listCheck(true);
			}
		}

		

		// Show trash and delete for components that uses the state field
		if (isset($this->items[0]->state))
		{

			if ($this->state->get('filter.state') == ContentComponent::CONDITION_TRASHED && $canDo->get('core.delete'))
			{
				$toolbar->delete('outgoingorders.delete')
					->text('JTOOLBAR_EMPTY_TRASH')
					->message('JGLOBAL_CONFIRM_DELETE')
					->listCheck(true);
			}
		}

		if ($canDo->get('core.admin'))
		{
			$toolbar->preferences('com_outgoing');
		}

		// Set sidebar action
		Sidebar::setAction('index.php?option=com_outgoing&view=outgoingorders');
	}
	
	/**
	 * Method to order fields 
	 *
	 * @return void 
	 */
	protected function getSortFields()
	{
		return array(
			'a.`id`' => Text::_('JGRID_HEADING_ID'),
			'a.`state`' => Text::_('JSTATUS'),
			'a.`ordering`' => Text::_('JGRID_HEADING_ORDERING'),
			'a.`doc_no`' => Text::_('COM_OUTGOING_OUTGOINGORDERS_DOC_NO'),
			'a.`date`' => Text::_('COM_OUTGOING_OUTGOINGORDERS_DATE'),
			'a.`raw_model`' => Text::_('COM_OUTGOING_OUTGOINGORDERS_RAW_MODEL'),
			'a.`model`' => Text::_('COM_OUTGOING_OUTGOINGORDERS_MODEL'),
			'a.`remark`' => Text::_('COM_OUTGOING_OUTGOINGORDERS_REMARK'),
			'a.`quantity`' => Text::_('COM_OUTGOING_OUTGOINGORDERS_QUANTITY'),
			'a.`custom_field_1`' => Text::_('COM_OUTGOING_OUTGOINGORDERS_CUSTOM_FIELD_1'),
			'a.`custom_field_2`' => Text::_('COM_OUTGOING_OUTGOINGORDERS_CUSTOM_FIELD_2'),
			'a.`custom_field_3`' => Text::_('COM_OUTGOING_OUTGOINGORDERS_CUSTOM_FIELD_3'),
			'a.`custom_field_4`' => Text::_('COM_OUTGOING_OUTGOINGORDERS_CUSTOM_FIELD_4'),
			'a.`custom_field_5`' => Text::_('COM_OUTGOING_OUTGOINGORDERS_CUSTOM_FIELD_5'),
			'a.`terms`' => Text::_('COM_OUTGOING_OUTGOINGORDERS_TERMS'),
		);
	}

	/**
	 * Check if state is set
	 *
	 * @param   mixed  $state  State
	 *
	 * @return bool
	 */
	public function getState($state)
	{
		return isset($this->state->{$state}) ? $this->state->{$state} : false;
	}
}
