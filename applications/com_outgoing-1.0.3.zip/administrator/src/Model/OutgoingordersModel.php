<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Outgoing
 * @author     Meichun <qa.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Outgoing\Component\Outgoing\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Outgoing\Component\Outgoing\Administrator\Helper\OutgoingHelper;
use \Joomla\Database\DatabaseInterface;

/**
 * Methods supporting a list of Outgoingorders records.
 *
 * @since  1.0.0
 */
class OutgoingordersModel extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see        JController
	 * @since      1.6
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id',
				'a.id',
				'state',
				'a.state',
				'ordering',
				'a.ordering',
				'created_by',
				'a.created_by',
				'modified_by',
				'a.modified_by',
				'doc_no',
				'a.doc_no',
				'date',
				'a.date',
				'raw_model',
				'a.raw_model',
				'part',
				'a.part',
				'model',
				'a.model',
				'remark',
				'a.remark',
				'quantity',
				'a.quantity',
				'custom_field_1',
				'a.custom_field_1',
				'custom_field_2',
				'a.custom_field_2',
				'custom_field_3',
				'a.custom_field_3',
				'custom_field_4',
				'a.custom_field_4',
				'custom_field_5',
				'a.custom_field_5',
				'terms',
				'a.terms',
				'description',
				'a.description',
				'model_name',
				'pm.model_name',
				'part_name',
				'pc.component_name',
				'remark_name',
				'or.remark',
			);
		}

		parent::__construct($config);
	}








	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return void
	 *
	 * @throws \Exception
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState('id', 'DESC');

		$context = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $context);

		// Split context into component and optional section
		if (!empty($context)) {
			$parts = FieldsHelper::extract($context);

			if ($parts) {
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string A store id.
	 *
	 * @since   1.0.0
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');


		return parent::getStoreId($id);
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  \Joomla\Database\DatabaseQuery
	 *
	 * @since   1.0.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select',
				'DISTINCT a.*'
			)
		);
		$query->from('`#__outgoing_orders` AS a');
		$query->select($db->quoteName('pm.model_name', 'model_name'));
		$query->join('LEFT', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'));

		$query->select($db->quoteName('pc.component_name', 'part_name'));
		$query->join('LEFT', $db->quoteName('#__product_components', 'pc') . ' ON ' . $db->quoteName('pc.id') . ' = ' . $db->quoteName('pm.component'));

		$query->select($db->quoteName('or.remark', 'remark_name'));
		$query->join('LEFT', $db->quoteName('#__outgoing_remarks', 'or') . ' ON ' . $db->quoteName('or.id') . ' = ' . $db->quoteName('a.remark'));

		// Join over the users for the checked out user
		$query->select("uc.name AS uEditor");
		$query->join("LEFT", "#__users AS uc ON uc.id=a.checked_out");


		// Filter by published state
		$published = $this->getState('filter.state');

		if (is_numeric($published)) {
			$query->where('a.state = ' . (int) $published);
		} elseif (empty($published)) {
			$query->where('(a.state IN (0, 1))');
		}

		// Filter by year
		$year = $this->getState('filter.year');
		if (!empty($year)) {
			$query->where('YEAR(' . $db->quoteName('a.date') . ') = ' . (int) $year);
		}

		// Filter by month
		$month = $this->getState('filter.month');
		if (!empty($month) && $month !== 'all') {
			$query->where('MONTH(' . $db->quoteName('a.date') . ') = ' . (int) $month);
		}

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search)) {
			if (stripos($search, 'id:') === 0) {
				$query->where('a.id = ' . (int) substr($search, 3));
			} else {
				$search = '%' . $search . '%';
				$query->where('( a.doc_no LIKE :search_0 OR  a.raw_model LIKE :search_1 OR  a.model LIKE :search_2 OR  a.remark LIKE :search_3 OR  a.custom_field_1 LIKE :search_4 OR  a.custom_field_2 LIKE :search_5 OR  a.custom_field_3 LIKE :search_6 OR  a.custom_field_4 LIKE :search_7 OR  a.custom_field_5 LIKE :search_8 OR  a.terms LIKE :search_9 OR  a.part LIKE :search_10)')->bind([':search_0', ':search_1', ':search_2', ':search_3', ':search_4', ':search_5', ':search_6', ':search_7', ':search_8', ':search_9', ':search_10'], $search);
			}
		}

		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', 'id');
		$orderDirn = $this->state->get('list.direction', 'DESC');

		if ($orderCol && $orderDirn) {
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}

	/**
	 * Get an array of data items
	 *
	 * @return mixed Array of data items on success, false on failure.
	 */
	public function getItems()
	{
		$items = parent::getItems();


		return $items;
	}
}
