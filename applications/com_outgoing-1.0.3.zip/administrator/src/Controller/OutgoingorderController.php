<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Outgoing
 * @author     Meichun <qa.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Outgoing\Component\Outgoing\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Versioning\VersionableControllerTrait;

/**
 * Outgoingorder controller class.
 *
 * @since  1.0.0
 */
class OutgoingorderController extends FormController
{
	use VersionableControllerTrait;

	protected $view_list = 'outgoingorders';
}
