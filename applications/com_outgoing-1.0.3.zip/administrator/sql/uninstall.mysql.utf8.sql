DROP TABLE IF EXISTS `#__outgoing_orders`;

DROP TABLE IF EXISTS `#__outgoing_remarks`;

DELETE FROM `#__action_log_config` WHERE (type_alias LIKE 'com_outgoing.%');
DELETE FROM `#__action_logs_extensions` WHERE (extension = 'com_outgoing');